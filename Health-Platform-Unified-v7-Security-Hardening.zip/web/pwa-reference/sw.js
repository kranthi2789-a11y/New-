// OmniDoctor Service Worker v2.0
// Enables offline mode, push notifications, background sync

const CACHE_NAME = 'omnidoctor-v2';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/offline.html',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
];

// ─── INSTALL ───────────────────────────────────────────────────
self.addEventListener('install', (event) => {
  console.log('[SW] Installing OmniDoctor Service Worker...');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    }).then(() => self.skipWaiting())
  );
});

// ─── ACTIVATE ──────────────────────────────────────────────────
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating...');
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

// ─── FETCH (Network-first, cache fallback) ─────────────────────
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Always go to network for API calls
  if (url.pathname.startsWith('/api/') || url.hostname.includes('anthropic.com')) {
    event.respondWith(
      fetch(request).catch(() => {
        return new Response(JSON.stringify({ error: 'Offline - please reconnect' }), {
          headers: { 'Content-Type': 'application/json' }
        });
      })
    );
    return;
  }

  // Cache-first for static assets
  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request).then((response) => {
        if (response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
        }
        return response;
      }).catch(() => {
        if (request.mode === 'navigate') {
          return caches.match('/offline.html');
        }
      });
    })
  );
});

// ─── PUSH NOTIFICATIONS ────────────────────────────────────────
self.addEventListener('push', (event) => {
  const data = event.data?.json() || {};
  const options = {
    body: data.body || 'Time to take your medication',
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-72.png',
    vibrate: [200, 100, 200],
    data: { url: data.url || '/?agent=reminders' },
    actions: [
      { action: 'taken', title: '✅ Taken', icon: '/icons/icon-96.png' },
      { action: 'snooze', title: '⏰ 15 min', icon: '/icons/icon-96.png' }
    ],
    tag: data.tag || 'medication-reminder',
    requireInteraction: true
  };

  event.waitUntil(
    self.registration.showNotification(
      data.title || '💊 OmniDoctor Reminder',
      options
    )
  );
});

// ─── NOTIFICATION CLICK ────────────────────────────────────────
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'taken') {
    // Log medication taken
    event.waitUntil(
      self.clients.matchAll().then(clients => {
        clients.forEach(client => client.postMessage({ type: 'MED_TAKEN', tag: event.notification.tag }));
      })
    );
    return;
  }

  if (event.action === 'snooze') {
    // Re-schedule notification in 15 minutes
    event.waitUntil(
      new Promise(resolve => {
        setTimeout(() => {
          self.registration.showNotification('⏰ Snoozed Reminder', {
            body: event.notification.body,
            icon: '/icons/icon-192.png',
            tag: event.notification.tag + '-snooze'
          });
          resolve();
        }, 15 * 60 * 1000);
      })
    );
    return;
  }

  // Open app on click
  event.waitUntil(
    self.clients.openWindow(event.notification.data?.url || '/')
  );
});

// ─── BACKGROUND SYNC (Offline queue) ──────────────────────────
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-health-data') {
    event.waitUntil(syncHealthData());
  }
  if (event.tag === 'sync-medication-log') {
    event.waitUntil(syncMedicationLog());
  }
});

async function syncHealthData() {
  try {
    const db = await openDB();
    const pending = await db.getAll('pendingSync');
    for (const item of pending) {
      await fetch('/api/v1/health/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(item)
      });
    }
    console.log('[SW] Health data synced successfully');
  } catch (err) {
    console.error('[SW] Sync failed:', err);
  }
}

async function syncMedicationLog() {
  try {
    const db = await openDB();
    const logs = await db.getAll('medicationLogs');
    await fetch('/api/v1/medications/log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ logs })
    });
  } catch (err) {
    console.error('[SW] Med log sync failed:', err);
  }
}

// Simple IndexedDB helper
function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('OmniDoctorDB', 1);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('pendingSync')) db.createObjectStore('pendingSync', { autoIncrement: true });
      if (!db.objectStoreNames.contains('medicationLogs')) db.createObjectStore('medicationLogs', { autoIncrement: true });
    };
  });
}
