# Operations runbook

## Health
GET `/api/health`.

## Authentication
Set `HEALTH_JWT_SECRET` to a random secret of at least 32 bytes. Replace development accounts before any non-development deployment.

## Database
The canonical local runtime uses SQLite for zero-dependency execution. Production should use managed PostgreSQL with migrations and encrypted backups; do not present the SQLite database as a production clinical store.

## AI
If `ANTHROPIC_API_KEY` is absent, the platform still runs deterministic workflows. If configured, model calls remain advisory and are not allowed to commit clinical state by themselves.

## Documents
Uploads are limited to 10MB in the baseline. Production requires malware scanning, object storage, encryption, retention policies and content-disarm/validation appropriate to the deployment.

## Incident response
Disable affected users, preserve audit records, switch to safe mode/manual workflows, investigate model and authorization traces, and restore only after validation.
