---
name: rea-assisted-engineering-audit
version: 1.0.0
description: Evidence-first workflow for using REA (Reverse Engineer Anything) and normal repository analysis to audit, understand, safely reuse, and improve software.
---

# REA-Assisted Engineering Audit Skill

## Purpose
Use REA as an engineering investigation aid when source is incomplete or behavior needs runtime/package/binary evidence. For complete source repositories, use ordinary repository tools and tests first. REA findings are evidence to review, not automatic proof or permission to copy code.

## Safety boundaries
- Analyze only code, packages, applications, and systems the user is authorized to inspect.
- Keep REA in the engineering/development plane; do not put REA or its privileged inspection tools in a patient-facing or production clinical runtime.
- Do not feed real patient/regulated data into reverse-engineering workflows. Use synthetic fixtures and sanitized logs.
- Never copy third-party implementation code into the product without provenance, license, security, and compatibility review.
- Do not run installers or mutate agent configuration without explicit approval. Prefer pinned versions and inspect setup plans first.
- Report observed evidence separately from inference, assumptions, and unknowns.

## Workflow
1. **Inventory the target**: identify repositories, archive versions, languages, entry points, services, routes, data stores, tests, dependencies, licenses, and deployment files. Hash source archives and record the exact version reviewed.
2. **Choose the analysis method**: source available → static source analysis, tests, dependency graph, and route/schema inspection first. Use REA when package/binary/runtime behavior is relevant or the source does not explain behavior.
3. **Establish a baseline**: run existing tests and record exact command, environment, pass/fail count, and skipped tests. Do not call an unexecuted test “passing.”
4. **Trace critical flows**: identity/authentication → authorization → tenant/resource access → persistence → events/integrations → audit. Trace read, write, export, document, AI, and interoperability paths.
5. **Prioritize risks**: P0 cross-tenant exposure, default secrets/demo accounts in production, unsafe authorization, or unvalidated clinical decisions; P1 integration/data correctness and reliability; P2 usability/maintainability. Tie each finding to a file, function, route, test, or REA evidence record.
6. **Propose the smallest safe patch**: preserve existing behavior where appropriate, fail closed on access checks, avoid broad rewrites, add negative tests, and document migration/rollback impact.
7. **Verify**: run focused tests, full tests, static checks, and integration tests available in the environment. If real PostgreSQL, identity provider, FHIR server, broker, or clinical validation infrastructure is absent, state that clearly and do not imply it was tested.
8. **Review reuse candidates**: check source provenance, license and notices, dependencies, vulnerabilities, architecture fit, test coverage, data boundaries, and maintainability before adapting anything.
9. **Package deliverables**: include versioned source, tests, a concise change log, exact validation evidence, known gaps, and next prioritized steps. Never claim a GitHub push/deployment unless it actually happened.

## Health-platform-specific priority order
1. Fail-closed patient/organization isolation across all reads, writes, uploads, exports, AI/CDS, and FHIR routes.
2. Production secret enforcement; disable seeded demo users outside development; add robust identity, rate limiting, MFA/IdP integration.
3. Real PostgreSQL with supported driver and versioned migrations; test against actual PostgreSQL rather than only SQLite.
4. Full SMART on FHIR/OIDC authorization and issuer/audience/signature/scope validation against a real test server.
5. Clinical safety evaluation using synthetic cases, evidence traceability, human review, and validated CDS thresholds.
6. Document storage controls, malware scanning, size/type limits, signed URLs, immutable/tamper-evident audit, broker retries/idempotency.
7. End-to-end workflows, observability, reproducible dependencies/SBOM/license review, deployment and rollback drills.

## Output format for each audit
- Scope/version reviewed
- Evidence and baseline test results
- Findings (severity, location, impact, confidence)
- Changes made (or explicitly “none”)
- Tests run and exact results
- Remaining risks and unverified integrations
- Next step

## REA tool readiness
Check the current REA repository documentation for supported Node/npm versions, target platform, providers, and exact capabilities. Do not install or run setup just to perform ordinary source review. If the environment does not meet REA requirements, proceed with available static analysis and disclose the limitation. REA upstream: https://github.com/morluto/rea
