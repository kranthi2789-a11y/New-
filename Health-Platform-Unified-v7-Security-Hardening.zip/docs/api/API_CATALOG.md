# API catalog

## Control plane
- `GET /api/health`
- `GET /api/readiness`
- `GET /api/roles`
- `POST /api/login`
- `GET /api/me`
- `GET /api/dashboard`
- `GET /api/command-center`
- `GET /api/users`
- `GET /api/organizations`
- `POST /api/organizations`

## Clinical
- `GET/POST /api/patients`
- `GET /api/patients/{pid}`
- `GET /api/patients/{pid}/timeline`
- `GET/POST /api/patients/{pid}/vitals`
- `GET/POST /api/patients/{pid}/labs`
- `GET/POST /api/prescriptions`
- `POST /api/dispensations`
- `GET/POST/PATCH /api/appointments`
- `POST /api/care-tasks`
- `PATCH /api/care-tasks/{id}`

## Operations
- `GET/POST/PATCH /api/inventory`
- `GET/POST/PATCH /api/bills`
- `POST /api/consent`
- `POST /api/documents/upload`
- `GET /api/patients/{pid}/documents`
- `GET/POST /api/notifications`
- `GET /api/audit`

## AI and safety
- `GET /api/agents`
- `POST /api/agents/{agent_id}/run`
- `POST /api/emergency/triage`
- `POST /api/chat`

All sensitive routes require authentication and server-side authorization.
