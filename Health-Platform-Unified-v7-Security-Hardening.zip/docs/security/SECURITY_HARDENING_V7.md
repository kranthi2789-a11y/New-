# v7 Security Hardening — Initial Patch

## Implemented
- Patient resource authorization now fails closed if the patient has no organization mapping.
- Non-admin access now fails closed if the user has no organization membership or no matching organization with the patient.
- Added patient scope checks to appointment, vitals, lab-result, care-task, bill, consent, and patient-linked message creation paths that previously lacked a consistent check.
- Production startup now refuses the default placeholder JWT secret or a secret shorter than 32 bytes when `HEALTH_ENV=production` (or `prod`).
- Added regression tests for unmapped patients and cross-organization patient access.

## Validation
- Baseline v6: 29 tests passed.
- Updated v7 working tree: 31 tests passed.
- Test command: `pytest -q`.

## Important limitations
- This is a targeted first hardening pass, not proof of complete route-by-route authorization. All patient-associated endpoints still require a systematic access-control matrix and negative tests.
- Seeded demo credentials must still be disabled/refused in non-development deployments.
- PostgreSQL compatibility remains unverified against a real PostgreSQL server; current tests use SQLite.
- SMART on FHIR/OIDC remains incomplete until exercised against a real identity provider and FHIR server.
- Clinical decision support remains advisory and requires independent clinical validation.
- REA was not run against this source tree. The current environment reports Node 22.16.0, below the REA README's documented Node 22.19+ requirement; source-level review and tests were used instead.
