# AI Governance Boundary

1. AI outputs are advisory unless a separately authorized workflow explicitly promotes them.
2. AI cannot directly write diagnoses, prescriptions, medication dispensing, or emergency dispositions.
3. Patient access is checked before evidence retrieval and AI execution.
4. AI runs record an input hash, output, patient context, and evidence references.
5. Human approval is mandatory for governed clinical summaries in the current implementation.
6. Model-provider failure falls back to a deterministic non-model response rather than fabricating an answer.
7. External model use must be configured explicitly with `ANTHROPIC_API_KEY`; absence of a key does not imply model availability.
8. Production deployments must define retention, encryption, DLP, prompt-injection defenses, model allowlists, vendor agreements, and clinical validation.
