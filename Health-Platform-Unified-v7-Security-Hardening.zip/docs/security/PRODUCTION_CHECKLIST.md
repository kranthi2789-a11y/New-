# Production security checklist

Before real patient data is enabled:

- [ ] Enterprise OIDC/SAML SSO and MFA
- [ ] Replace demo accounts and secrets
- [ ] Secrets manager / KMS
- [ ] PostgreSQL with encrypted storage and TLS
- [ ] Object storage for documents with malware scanning and signed URLs
- [ ] Tenant/hospital isolation enforced server-side
- [ ] Least-privilege service identities
- [ ] Rate limiting and abuse protection, including emergency endpoints
- [ ] Immutable/retained audit pipeline
- [ ] Backup, restore and disaster-recovery tests
- [ ] Dependency/SBOM/license scanning
- [ ] SAST/DAST and penetration testing
- [ ] FHIR/HL7 integration validation against actual endpoints
- [ ] Clinical evaluation dataset and documented acceptance thresholds
- [ ] Model/prompt/version provenance and rollback
- [ ] Human approval policy for clinical actions
- [ ] Incident response and security monitoring
- [ ] Regulatory/legal review for the deployment jurisdiction
