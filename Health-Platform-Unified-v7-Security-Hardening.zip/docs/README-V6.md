# Health Platform v6 — Interoperability & Intelligence Foundation

This release builds on the tested v5 unified healthcare platform.

## Implemented in this release

- FHIR R4 capability metadata (`/api/fhir/metadata`)
- FHIR resource persistence/search for Patient, Observation, Condition, MedicationRequest, MedicationStatement, AllergyIntolerance, Encounter, DiagnosticReport, ServiceRequest, CarePlan, DocumentReference, Practitioner and Organization
- Patient-scoped FHIR access controls
- SMART-on-FHIR discovery metadata at `/.well-known/smart-configuration`
- Knowledge document store and keyword retrieval baseline
- Notification dispatch and local delivery state machine
- Care-journey step state transitions
- Clinical next-action aggregation
- Local plain-text clinical document extraction into governed evidence
- Evidence provenance and audit records

## Deliberate non-claims

The platform does **not** claim that a live EHR, SMART authorization server, OCR vendor, SMS/email provider, or external FHIR server is connected merely because the corresponding contract/adapter exists.

Those integrations require environment-specific credentials, endpoint configuration and live contract testing.

## Validation

- 29 automated tests passing locally
- Python compile check passing
- Local FastAPI startup/readiness previously validated on the v5 baseline; this release only adds routes/tables and remains compatible with the same startup path.

## Integration promotion path

1. Choose a real FHIR server/EHR test environment.
2. Register the organization and SMART client.
3. Validate authorization scopes and patient context.
4. Run FHIR contract tests against the target server.
5. Enable an OCR/document provider only after security and data-retention review.
6. Enable real notification providers behind the existing delivery interface.
7. Replace the keyword retrieval baseline with a benchmarked clinical retrieval implementation and retain source provenance.
