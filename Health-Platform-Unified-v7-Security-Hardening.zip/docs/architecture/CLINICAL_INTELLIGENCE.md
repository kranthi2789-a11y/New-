# Clinical Intelligence Layer

## Purpose
Provide evidence-grounded assistance without allowing an AI model to silently diagnose, prescribe, or change the clinical record.

## Flow
Patient context -> evidence collection -> governed agent runtime -> result -> human review -> approved workflow action.

## Evidence
Every AI summary stores the patient, source evidence IDs, input hash, model/deterministic mode, output, and audit event. Evidence records retain source type, source ID and provenance metadata.

## CDS
The CDS endpoint is advisory. Current deterministic rules cover configured vital/lab thresholds only. A finding is not a diagnosis and must be reviewed by an authorized clinical user.

## Approval
AI runs create a pending approval record. Doctor, nurse, care coordinator, hospital administrator, or platform administrator can approve/reject according to the current RBAC policy. Approval itself is audited.

## Care journeys
Journeys provide explicit patient goals and steps. Steps can declare an evidence requirement and owner role. This is the foundation for pathway orchestration and future durable workflow integration.

## Production gates
- Replace local SQLite with managed PostgreSQL and row-level tenant controls.
- Configure enterprise OIDC/SMART-on-FHIR identity.
- Use managed object storage with encryption and malware scanning.
- Connect durable workflow/event infrastructure.
- Validate CDS thresholds with an approved clinical governance process before clinical use.
- Run model-specific clinical evaluation and bias/safety testing before enabling external model inference.
