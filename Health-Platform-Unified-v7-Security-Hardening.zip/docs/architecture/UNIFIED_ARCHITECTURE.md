# Unified architecture

## Principle
The platform is one product with separate bounded services. VitalOS is the clinical governance foundation; OmniDoctor supplies healthcare agent capabilities; OmniCare supplies connected-care workflow patterns.

## Digital flow
Patient/Clinician/Operations UI → API Gateway → Identity/RBAC → Workflow → Clinical Rules → Agent Runtime → Evidence/Validation → Human Review → Commit → Audit/Event Bus → EHR/FHIR/Lab/Pharmacy/Claims integrations.

## Agent rule
Agents recommend; deterministic clinical rules and authorized humans commit high-impact clinical actions. Agent outputs must carry patient context, evidence references, confidence/uncertainty and audit identifiers.

## Data rule
The system of record is transactional storage. Retrieval/indexing is an optimization layer, never the authoritative clinical record.
