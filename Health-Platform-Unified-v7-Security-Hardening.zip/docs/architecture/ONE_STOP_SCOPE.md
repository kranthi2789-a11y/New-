# One-stop scope

The platform is intended to provide one shared control plane for:

1. Patient access and records
2. Doctor clinical workspace
3. Nursing workflow
4. Pharmacy and dispensing
5. Laboratory workflow
6. Inventory and procurement foundation
7. Care coordination
8. Reception and appointments
9. Emergency response rail
10. Billing and payer/insurance foundation
11. Consent, privacy and audit
12. AI agent registry and controlled execution
13. Clinical documents and evidence references
14. Hospital administration and command center
15. Medical-college/dean analytics boundary
16. Legacy claims integration boundary
17. FHIR/EHR interoperability boundary

AI outputs remain advisory unless a validated workflow explicitly authorizes an action and the applicable human review requirement is satisfied.
