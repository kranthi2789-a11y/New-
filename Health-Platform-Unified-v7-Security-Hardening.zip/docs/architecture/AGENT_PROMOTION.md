# Agent Promotion Plan

The repository contains prior VitalOS, OmniDoctor, and OmniCare agents under `integrations/`. They are treated as source implementations, not automatically trusted production agents.

Promotion requires:
- canonical input/output contract
- explicit permissions
- patient-scope enforcement
- evidence/provenance support
- deterministic safety checks where applicable
- timeout/retry behavior
- audit events
- human-review policy
- unit, integration, security and clinical evaluation tests

Current canonical runtime: `services/agent_runtime/runtime.py`.
