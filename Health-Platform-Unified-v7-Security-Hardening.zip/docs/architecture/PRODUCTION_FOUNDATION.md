# Production Foundation — v1.2

## Implemented in this release

- Organization membership tables for tenant boundaries.
- Patient-to-organization mapping and API scope enforcement.
- Security response headers and trusted-host control.
- OIDC configuration boundary for enterprise SSO integration.
- Transactional outbox for durable business events.
- Local outbox worker for deterministic development verification.
- Filesystem object-store abstraction; S3-compatible promotion boundary.
- FHIR-shaped Patient and Observation projections.
- PostgreSQL-compatible persistence adapter behind `DATABASE_URL`.
- Production Docker Compose with PostgreSQL and Redis infrastructure.
- 17 automated tests covering functional, security and interoperability paths.

## Not falsely claimed

A PostgreSQL server, OIDC provider, Redis broker, EHR/FHIR server or cloud object store was not reachable from the build environment. Their adapters/configuration are therefore treated as integration boundaries, not as completed external integrations.

Before PHI production use, execute the live integration test plan in `docs/security/PRODUCTION_CHECKLIST.md` and record the target-system versions and evidence.
