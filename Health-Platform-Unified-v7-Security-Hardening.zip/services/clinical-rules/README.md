# clinical-rules

Deterministic clinical safety/rule boundary; AI cannot bypass it.
