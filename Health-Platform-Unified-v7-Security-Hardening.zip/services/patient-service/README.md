# patient-service

Patient identity, demographics, timeline and scoped record access.
