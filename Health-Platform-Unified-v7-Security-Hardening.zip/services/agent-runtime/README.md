# agent-runtime

Controlled agent execution, evidence and human-review boundary.
