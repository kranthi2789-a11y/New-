"""Controlled AI runtime.

The runtime deliberately separates model inference from authorization and clinical state changes.
The supplied OmniDoctor/VitalOS agents remain available under integrations/ for promotion here.
When ANTHROPIC_API_KEY is configured, this module can execute a bounded text inference call;
without it, the platform remains runnable using deterministic safety rails.
"""
import os
from typing import Optional

SYSTEM = """You are a healthcare workflow assistant inside a governed healthcare platform. Do not diagnose or prescribe. Summarize, classify, route, or draft information. State uncertainty. Do not claim an action happened unless the platform confirms it. For emergencies, recommend local emergency services. Outputs are advisory and require appropriate human review for clinical decisions."""

class AgentRuntime:
    @staticmethod
    def available() -> dict:
        return {"provider_configured": bool(os.getenv("ANTHROPIC_API_KEY")), "mode": "model" if os.getenv("ANTHROPIC_API_KEY") else "deterministic"}

    @staticmethod
    def infer(message: str, system: Optional[str]=None) -> dict:
        key=os.getenv("ANTHROPIC_API_KEY")
        if not key:
            return {"mode":"deterministic","response":"No external model provider is configured. The platform can still execute governed workflows and safety rules.","human_review_required":True}
        try:
            import anthropic
            client=anthropic.Anthropic(api_key=key)
            response=client.messages.create(model=os.getenv("ANTHROPIC_MODEL","claude-sonnet-4-20250514"),max_tokens=600,system=system or SYSTEM,messages=[{"role":"user","content":message}])
            return {"mode":"model","response":response.content[0].text,"human_review_required":True}
        except Exception as exc:
            return {"mode":"model_error","error":str(exc),"human_review_required":True}
