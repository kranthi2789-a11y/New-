from pathlib import Path
import os, uuid

class ObjectStore:
    """Local development object store with an S3-compatible configuration boundary."""
    def __init__(self, root):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
    def put(self, data:bytes, filename:str, content_type:str='application/octet-stream'):
        key=f"{uuid.uuid4()}-{Path(filename).name}"
        path=self.root/key; path.write_bytes(data)
        return {"key":key,"size":len(data),"content_type":content_type,"backend":"filesystem"}
    def get(self,key):
        p=self.root/key
        if not p.exists(): return None
        return p.read_bytes()
