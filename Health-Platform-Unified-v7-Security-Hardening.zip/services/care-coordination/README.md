# care-coordination

Care tasks, referrals, follow-up and coordination workflows.
