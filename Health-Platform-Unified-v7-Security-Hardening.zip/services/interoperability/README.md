# Healthcare interoperability

The first canonical boundary is **FHIR R4-shaped resources** exposed by `/api/fhir/*`.

Implemented now:
- Patient resource projection
- Observation Bundle projection for vitals

Next adapters should be tested against an actual FHIR server before production use. The platform does not claim EHR connectivity merely because a FHIR-shaped endpoint exists.
