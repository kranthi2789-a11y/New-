from datetime import datetime, timezone

def patient_resource(patient:dict):
    resource={"resourceType":"Patient","id":patient["id"],"active":True,"name":[{"text":patient["name"]}]}
    if patient.get("dob"): resource["birthDate"]=patient["dob"]
    if patient.get("sex"): resource["gender"]=patient["sex"].lower()
    if patient.get("mobile"): resource["telecom"]= [{"system":"phone","value":patient["mobile"]}]
    return resource

def observation_resource(vital:dict):
    return {"resourceType":"Observation","id":vital["id"],"status":"final","subject":{"reference":f"Patient/{vital['patient_id']}"},"effectiveDateTime":vital["recorded_at"],"code":{"text":"Vital signs"},"component":[x for x in [
      {"code":{"text":"Systolic BP"},"valueQuantity":{"value":vital["bp_sys"],"unit":"mmHg"}} if vital.get("bp_sys") is not None else None,
      {"code":{"text":"Diastolic BP"},"valueQuantity":{"value":vital["bp_dia"],"unit":"mmHg"}} if vital.get("bp_dia") is not None else None,
      {"code":{"text":"Heart rate"},"valueQuantity":{"value":vital["heart_rate"],"unit":"bpm"}} if vital.get("heart_rate") is not None else None,
      {"code":{"text":"SpO2"},"valueQuantity":{"value":vital["spo2"],"unit":"%"}} if vital.get("spo2") is not None else None,
    ] if x is not None]}
