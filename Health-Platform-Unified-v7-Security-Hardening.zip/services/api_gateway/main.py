from __future__ import annotations
import os, sqlite3, uuid, hashlib, hmac, json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional
import jwt
from fastapi import FastAPI, HTTPException, Depends, Header, UploadFile, File, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel, Field
from services.agent_runtime.runtime import AgentRuntime
from services.persistence.tenant import assert_patient_access, user_org_ids
from services.workflow.outbox import publish
from services.storage.object_store import ObjectStore
from services.interoperability.fhir import patient_resource, observation_resource
from services.identity.oidc import config as oidc_config

ROOT = Path(__file__).resolve().parents[2]
DB_PATH = Path(os.getenv("HEALTH_DB", ROOT / "data" / "health.db"))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
JWT_SECRET = os.getenv("HEALTH_JWT_SECRET", "CHANGE-ME-IN-PRODUCTION")
HEALTH_ENV = os.getenv("HEALTH_ENV", "development").lower()

if HEALTH_ENV in {"prod", "production"} and (JWT_SECRET == "CHANGE-ME-IN-PRODUCTION" or len(JWT_SECRET.encode("utf-8")) < 32):
    raise RuntimeError("Production startup refused: set HEALTH_JWT_SECRET to a random secret of at least 32 bytes")
ALGORITHM = "HS256"
TOKEN_HOURS = 8
OBJECT_STORE = ObjectStore(Path(os.getenv("HEALTH_OBJECT_STORE", ROOT / "data" / "objects")))

ROLES = {
    "patient": "Patient", "doctor": "Doctor", "nurse": "Nurse",
    "pharmacist": "Pharmacist", "inventory": "Inventory Manager",
    "lab_technician": "Lab Technician", "care_coordinator": "Care Coordinator",
    "receptionist": "Receptionist", "emergency_responder": "Emergency Responder",
    "finance": "Finance", "dean": "Dean / Medical College Admin",
    "hospital_admin": "Hospital Administrator", "admin": "Platform Administrator"
}
ROLE_PERMISSIONS = {
    "patient": {"self:read","self:write","appointment:create","document:upload","chat:use","care:read"},
    "doctor": {"patient:read","clinical:write","appointment:manage","lab:read","prescription:write","care:manage","inventory:read"},
    "nurse": {"patient:read","vitals:write","care:manage","appointment:manage","inventory:read"},
    "pharmacist": {"prescription:read","medication:dispense","inventory:read","inventory:write","patient:read"},
    "inventory": {"inventory:read","inventory:write","analytics:read"},
    "lab_technician": {"lab:write","lab:read","patient:read"},
    "care_coordinator": {"patient:read","care:manage","appointment:manage","document:read","analytics:read"},
    "receptionist": {"patient:read","patient:write","appointment:manage"},
    "emergency_responder": {"emergency:manage","patient:read","care:manage"},
    "finance": {"billing:read","billing:write","insurance:read","analytics:read"},
    "dean": {"analytics:read","patient:read","care:read","education:read","audit:read"},
    "hospital_admin": {"analytics:read","patient:read","care:read","inventory:read","billing:read","audit:read","user:manage"},
    "admin": {"*"}
}

app = FastAPI(title="Health Platform", version="1.5.0", description="Unified healthcare operating platform")
app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in os.getenv("ALLOWED_ORIGINS","*").split(",")], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])
app.add_middleware(TrustedHostMiddleware, allowed_hosts=[h.strip() for h in os.getenv("ALLOWED_HOSTS","*").split(",")])

@app.middleware("http")
async def security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = "default-src 'self'; frame-ancestors 'none'; object-src 'none'"
    return response


class _CompatRow(dict):
    def __getitem__(self, key):
        if isinstance(key, int): return list(self.values())[key]
        return super().__getitem__(key)

class _CompatCursor:
    def __init__(self, cur): self.cur=cur
    def fetchone(self):
        r=self.cur.fetchone(); return _CompatRow(r) if r is not None else None
    def fetchall(self): return [_CompatRow(r) for r in self.cur.fetchall()]

class _PostgresCompat:
    def __init__(self, dsn):
        import psycopg
        from psycopg.rows import dict_row
        self.con=psycopg.connect(dsn, row_factory=dict_row)
    def _sql(self, sql):
        sql=sql.replace("PRAGMA foreign_keys=ON", "SELECT 1")
        sql=sql.replace("INSERT OR IGNORE INTO", "INSERT INTO")
        if "INSERT INTO user_organizations" in sql or "INSERT INTO patient_organizations" in sql:
            sql += " ON CONFLICT DO NOTHING"
        sql=sql.replace("date(starts_at)=date('now')", "DATE(starts_at)=CURRENT_DATE")
        return sql.replace("?", "%s")
    def execute(self, sql, params=()):
        sql=self._sql(sql)
        if sql.startswith("INSERT INTO") and "ON CONFLICT DO NOTHING" in sql:
            return _CompatCursor(self.con.execute(sql, params))
        return _CompatCursor(self.con.execute(sql, params))
    def executescript(self, script):
        for statement in script.split(';'):
            statement=statement.strip()
            if statement: self.execute(statement)
    def commit(self): self.con.commit()
    def rollback(self): self.con.rollback()
    def close(self): self.con.close()

def db():
    dsn=os.getenv("DATABASE_URL")
    if dsn:
        return _PostgresCompat(dsn)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con

def now(): return datetime.now(timezone.utc).isoformat()
def hash_password(password: str, salt: Optional[bytes]=None):
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 210_000)
    return salt.hex()+":"+digest.hex()
def verify_password(password, stored):
    try:
        s,d=stored.split(":",1); expected=hashlib.pbkdf2_hmac("sha256",password.encode(),bytes.fromhex(s),210_000).hex(); return hmac.compare_digest(expected,d)
    except Exception: return False

def audit(actor, action, resource, resource_id, outcome="success", metadata=None):
    con=db(); con.execute("INSERT INTO audit_events(id,actor_id,actor_role,action,resource,resource_id,outcome,metadata,created_at) VALUES(?,?,?,?,?,?,?,?,?)",(str(uuid.uuid4()),actor.get("sub"),actor.get("role"),action,resource,resource_id,outcome,json.dumps(metadata or {}),now())); con.commit(); con.close()

def init_db():
    con=db()
    con.executescript('''
    CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, name TEXT NOT NULL, role TEXT NOT NULL, password_hash TEXT NOT NULL, patient_id TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS patients(id TEXT PRIMARY KEY, name TEXT NOT NULL, dob TEXT, sex TEXT, mobile TEXT, email TEXT, blood_group TEXT, allergies TEXT NOT NULL DEFAULT '[]', conditions TEXT NOT NULL DEFAULT '[]', emergency_contact TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS appointments(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, clinician_id TEXT, specialty TEXT, starts_at TEXT, status TEXT NOT NULL DEFAULT 'scheduled', reason TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS vitals(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, bp_sys REAL, bp_dia REAL, heart_rate REAL, spo2 REAL, temperature REAL, glucose REAL, weight_kg REAL, recorded_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS medications(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, name TEXT NOT NULL, dose TEXT, frequency TEXT, status TEXT DEFAULT 'active', source TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS lab_results(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, test_name TEXT NOT NULL, value TEXT, unit TEXT, status TEXT, report_text TEXT, reviewed_by TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, filename TEXT NOT NULL, content_type TEXT, content TEXT, evidence_refs TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS inventory(id TEXT PRIMARY KEY, sku TEXT UNIQUE NOT NULL, name TEXT NOT NULL, category TEXT, quantity REAL NOT NULL DEFAULT 0, reorder_level REAL NOT NULL DEFAULT 0, unit TEXT, updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS care_tasks(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, title TEXT NOT NULL, owner_role TEXT, priority TEXT DEFAULT 'normal', status TEXT DEFAULT 'open', due_at TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS bills(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, amount REAL NOT NULL, status TEXT DEFAULT 'unpaid', payer TEXT, description TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS consent(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, purpose TEXT NOT NULL, granted INTEGER NOT NULL, granted_at TEXT NOT NULL, revoked_at TEXT);
    CREATE TABLE IF NOT EXISTS audit_events(id TEXT PRIMARY KEY, actor_id TEXT, actor_role TEXT, action TEXT, resource TEXT, resource_id TEXT, outcome TEXT, metadata TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS agent_runs(id TEXT PRIMARY KEY, agent TEXT NOT NULL, actor_id TEXT, patient_id TEXT, input_hash TEXT, output TEXT, status TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS prescriptions(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, doctor_id TEXT NOT NULL, medication_name TEXT NOT NULL, dose TEXT, frequency TEXT, duration TEXT, instructions TEXT, status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS dispensations(id TEXT PRIMARY KEY, prescription_id TEXT NOT NULL, pharmacist_id TEXT NOT NULL, quantity REAL NOT NULL, dispensed_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS notifications(id TEXT PRIMARY KEY, user_id TEXT, patient_id TEXT, title TEXT NOT NULL, body TEXT NOT NULL, channel TEXT NOT NULL DEFAULT 'in_app', status TEXT NOT NULL DEFAULT 'queued', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS organizations(id TEXT PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS user_organizations(user_id TEXT NOT NULL, organization_id TEXT NOT NULL, PRIMARY KEY(user_id, organization_id));
    CREATE TABLE IF NOT EXISTS patient_organizations(patient_id TEXT NOT NULL, organization_id TEXT NOT NULL, PRIMARY KEY(patient_id, organization_id));
    CREATE TABLE IF NOT EXISTS outbox_events(id TEXT PRIMARY KEY, topic TEXT NOT NULL, event_type TEXT NOT NULL, payload TEXT NOT NULL, organization_id TEXT, status TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS object_metadata(id TEXT PRIMARY KEY, object_key TEXT UNIQUE NOT NULL, patient_id TEXT, filename TEXT NOT NULL, content_type TEXT, size INTEGER NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS clinical_notes(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, author_id TEXT NOT NULL, note_type TEXT NOT NULL, note TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'signed', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS diagnoses(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, code_system TEXT, code TEXT, description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active', recorded_by TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS referrals(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, from_clinician TEXT NOT NULL, specialty TEXT NOT NULL, reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'requested', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS insurance_policies(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, payer TEXT NOT NULL, policy_number TEXT, status TEXT NOT NULL DEFAULT 'active', coverage TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS lab_orders(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, ordered_by TEXT NOT NULL, test_name TEXT NOT NULL, priority TEXT NOT NULL DEFAULT 'routine', status TEXT NOT NULL DEFAULT 'ordered', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS beds(id TEXT PRIMARY KEY, organization_id TEXT NOT NULL, ward TEXT NOT NULL, room TEXT NOT NULL, bed_number TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'available', patient_id TEXT, updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS procurement_requests(id TEXT PRIMARY KEY, organization_id TEXT NOT NULL, requested_by TEXT NOT NULL, item TEXT NOT NULL, quantity REAL NOT NULL, status TEXT NOT NULL DEFAULT 'requested', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, sender_id TEXT NOT NULL, recipient_id TEXT, patient_id TEXT, body TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'sent', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS evidence_items(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, source_type TEXT NOT NULL, source_id TEXT, title TEXT NOT NULL, excerpt TEXT NOT NULL, provenance TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS ai_approvals(id TEXT PRIMARY KEY, run_id TEXT NOT NULL, reviewer_id TEXT, decision TEXT NOT NULL DEFAULT 'pending', comment TEXT, decided_at TEXT);
    CREATE TABLE IF NOT EXISTS cds_assessments(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, assessor_id TEXT NOT NULL, input_snapshot TEXT NOT NULL, findings TEXT NOT NULL, severity TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'advisory', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS care_journeys(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, journey_type TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'active', goal TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS care_journey_steps(id TEXT PRIMARY KEY, journey_id TEXT NOT NULL, title TEXT NOT NULL, owner_role TEXT, status TEXT NOT NULL DEFAULT 'pending', due_at TEXT, evidence_required INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS knowledge_documents(id TEXT PRIMARY KEY, title TEXT NOT NULL, source TEXT NOT NULL, content TEXT NOT NULL, tags TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS notification_deliveries(id TEXT PRIMARY KEY, notification_id TEXT NOT NULL, channel TEXT NOT NULL, status TEXT NOT NULL, provider TEXT NOT NULL, attempt INTEGER NOT NULL DEFAULT 0, error TEXT, delivered_at TEXT);
    CREATE TABLE IF NOT EXISTS fhir_resources(id TEXT PRIMARY KEY, organization_id TEXT, patient_id TEXT, resource_type TEXT NOT NULL, resource_id TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1, body TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, UNIQUE(resource_type, resource_id));
    CREATE TABLE IF NOT EXISTS smart_clients(client_id TEXT PRIMARY KEY, name TEXT NOT NULL, redirect_uris TEXT NOT NULL, scopes TEXT NOT NULL, organization_id TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS smart_authorizations(id TEXT PRIMARY KEY, client_id TEXT NOT NULL, user_id TEXT NOT NULL, patient_id TEXT, scopes TEXT NOT NULL, code_hash TEXT NOT NULL, expires_at TEXT NOT NULL, used_at TEXT, created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_user_org ON user_organizations(user_id, organization_id);
    CREATE INDEX IF NOT EXISTS idx_patient_org ON patient_organizations(patient_id, organization_id);
    CREATE INDEX IF NOT EXISTS idx_outbox_status ON outbox_events(status, created_at);
    ''')
    # deterministic development accounts; never use these in production
    defaults=[
      ("patient.demo","Demo Patient","patient","patient123",None),
      ("doctor.demo","Dr Demo","doctor","doctor123",None),
      ("nurse.demo","Nurse Demo","nurse","nurse123",None),
      ("pharmacy.demo","Pharmacist Demo","pharmacist","pharm123",None),
      ("inventory.demo","Inventory Demo","inventory","inventory123",None),
      ("lab.demo","Lab Demo","lab_technician","lab123",None),
      ("coordinator.demo","Care Coordinator","care_coordinator","care123",None),
      ("reception.demo","Reception Demo","receptionist","reception123",None),
      ("emergency.demo","Emergency Demo","emergency_responder","emergency123",None),
      ("finance.demo","Finance Demo","finance","finance123",None),
      ("dean.demo","Dean Demo","dean","dean123",None),
      ("hospitaladmin.demo","Hospital Admin","hospital_admin","hospital123",None),
      ("admin.demo","Platform Admin","admin","admin123",None),
    ]
    pid="demo-patient"
    if not con.execute("SELECT 1 FROM organizations WHERE id=?",("demo-hospital",)).fetchone():
        con.execute("INSERT INTO organizations VALUES(?,?,?,?,?)",("demo-hospital","Demo Health Network","hospital",1,now()))
    if not con.execute("SELECT 1 FROM patients WHERE id=?",(pid,)).fetchone():
        con.execute("INSERT INTO patients VALUES(?,?,?,?,?,?,?,?,?,?,?)",(pid,"Demo Patient","1988-01-01","U","9999999999","patient@example.test","O+","[\"none\"]","[\"none\"]","9999999998",now()))
    for username,name,role,password,_ in defaults:
        if not con.execute("SELECT 1 FROM users WHERE username=?",(username,)).fetchone():
            con.execute("INSERT INTO users VALUES(?,?,?,?,?,?,?,?)",(str(uuid.uuid4()),username,name,role,hash_password(password),pid if role=="patient" else None,1,now()))
    for r in con.execute("SELECT id FROM users").fetchall():
        con.execute("INSERT OR IGNORE INTO user_organizations(user_id,organization_id) VALUES(?,?)", (r["id"], "demo-hospital"))
    con.execute("INSERT OR IGNORE INTO patient_organizations(patient_id,organization_id) VALUES(?,?)", (pid, "demo-hospital"))
    if con.execute("SELECT COUNT(*) c FROM inventory").fetchone()[0]==0:
        for item in [("MED-001","Paracetamol 500mg","medicine",1000,100,"tablet"),("MED-002","Metformin 500mg","medicine",500,100,"tablet"),("SUP-001","N95 Mask","consumable",250,50,"piece")]:
            con.execute("INSERT INTO inventory VALUES(?,?,?,?,?,?,?,?)",(str(uuid.uuid4()),*item,now()))
    con.commit(); con.close()
init_db()

class Login(BaseModel): username:str; password:str
class AppointmentIn(BaseModel): patient_id:str; clinician_id:Optional[str]=None; specialty:str="General Medicine"; starts_at:str; reason:str=""
class PatientIn(BaseModel): name:str; dob:Optional[str]=None; sex:Optional[str]=None; mobile:Optional[str]=None; email:Optional[str]=None; blood_group:Optional[str]=None; allergies:list[str]=[]; conditions:list[str]=[]; emergency_contact:Optional[str]=None
class VitalIn(BaseModel): patient_id:str; bp_sys:Optional[float]=None; bp_dia:Optional[float]=None; heart_rate:Optional[float]=None; spo2:Optional[float]=None; temperature:Optional[float]=None; glucose:Optional[float]=None; weight_kg:Optional[float]=None
class InventoryIn(BaseModel): sku:str; name:str; category:str="general"; quantity:float=0; reorder_level:float=0; unit:str="unit"
class InventoryAdjust(BaseModel): delta:float
class CareTaskIn(BaseModel): patient_id:str; title:str; owner_role:Optional[str]=None; priority:str="normal"; due_at:Optional[str]=None
class BillIn(BaseModel): patient_id:str; amount:float; payer:Optional[str]=None; description:str=""
class ConsentIn(BaseModel): patient_id:str; purpose:str; granted:bool
class ChatIn(BaseModel): message:str; patient_id:Optional[str]=None; language:str="english"
class LabIn(BaseModel): patient_id:str; test_name:str; value:str; unit:Optional[str]=None; status:Optional[str]=None; report_text:Optional[str]=None
class PrescriptionIn(BaseModel): patient_id:str; medication_name:str; dose:Optional[str]=None; frequency:Optional[str]=None; duration:Optional[str]=None; instructions:Optional[str]=None
class DispenseIn(BaseModel): prescription_id:str; quantity:float=1
class StatusIn(BaseModel): status:str
class NotificationIn(BaseModel): user_id:Optional[str]=None; patient_id:Optional[str]=None; title:str; body:str; channel:str="in_app"
class OrganizationIn(BaseModel): name:str; type:str="hospital"
class ClinicalNoteIn(BaseModel): patient_id:str; note_type:str="progress"; note:str
class DiagnosisIn(BaseModel): patient_id:str; description:str; code_system:Optional[str]=None; code:Optional[str]=None; status:str="active"
class ReferralIn(BaseModel): patient_id:str; specialty:str; reason:str
class InsuranceIn(BaseModel): patient_id:str; payer:str; policy_number:Optional[str]=None; coverage:Optional[str]=None
class LabOrderIn(BaseModel): patient_id:str; test_name:str; priority:str="routine"
class BedIn(BaseModel): ward:str; room:str; bed_number:str
class BedAssignIn(BaseModel): patient_id:str
class ProcurementIn(BaseModel): item:str; quantity:float
class MessageIn(BaseModel): recipient_id:Optional[str]=None; patient_id:Optional[str]=None; body:str
class EmergencyIn(BaseModel): symptoms:str; location:str="unknown"; patient_id:Optional[str]=None


class EvidenceIn(BaseModel):
    patient_id:str
    source_type:str
    source_id:Optional[str]=None
    title:str
    excerpt:str
    provenance:dict = Field(default_factory=dict)

class AISummaryIn(BaseModel):
    patient_id:str
    question:str = "Summarize the recent clinical information and identify items that need clinician review."

class ApprovalIn(BaseModel):
    decision:str
    comment:Optional[str]=None

class CDSIn(BaseModel):
    patient_id:str
    include_labs:bool=True
    include_vitals:bool=True

class JourneyIn(BaseModel):
    patient_id:str
    journey_type:str
    goal:Optional[str]=None

class JourneyStepIn(BaseModel):
    title:str
    owner_role:Optional[str]=None
    due_at:Optional[str]=None
    evidence_required:bool=False
class JourneyStepStatusIn(BaseModel):
    status:str
class KnowledgeIn(BaseModel):
    title:str
    source:str
    content:str
    tags:list[str]=Field(default_factory=list)
class KnowledgeSearchIn(BaseModel):
    query:str
    limit:int=5
class NotificationDispatchIn(BaseModel):
    channel:Optional[str]=None
class FHIRResourceIn(BaseModel):
    resource_type:str
    patient_id:Optional[str]=None
    resource:dict
class SMARTClientIn(BaseModel):
    name:str
    redirect_uris:list[str]
    scopes:list[str]
    organization_id:Optional[str]=None


def token_for(row):
    payload={"sub":row["id"],"username":row["username"],"role":row["role"],"patient_id":row["patient_id"],"exp":datetime.now(timezone.utc)+timedelta(hours=TOKEN_HOURS)}
    return jwt.encode(payload,JWT_SECRET,algorithm=ALGORITHM)
def current_user(authorization: str=Header(default="")):
    if not authorization.startswith("Bearer "): raise HTTPException(401,"Bearer token required")
    try: return jwt.decode(authorization[7:],JWT_SECRET,algorithms=[ALGORITHM])
    except Exception: raise HTTPException(401,"Invalid or expired token")
def require(*permissions):
    def dep(user=Depends(current_user)):
        grants=ROLE_PERMISSIONS.get(user.get("role"),set())
        if "*" not in grants and not set(permissions).issubset(grants): raise HTTPException(403,"Insufficient permissions")
        return user
    return dep

def rowdict(row): return dict(row) if row else None

def scoped_patient(user,pid):
    con=db()
    try:
        assert_patient_access(con,user,pid)
    finally:
        con.close()

@app.get("/api/health")
def health(): return {"status":"ok","platform":"Health Platform","version":"1.5.0","db":str(DB_PATH)}
@app.get("/api/roles")
def roles(): return {"roles":ROLES,"permissions":ROLE_PERMISSIONS}
@app.post("/api/login")
def login(req:Login):
    con=db(); row=con.execute("SELECT * FROM users WHERE username=? AND active=1",(req.username,)).fetchone(); con.close()
    if not row or not verify_password(req.password,row["password_hash"]): raise HTTPException(401,"Invalid credentials")
    tok=token_for(row); audit({"sub":row["id"],"role":row["role"]},"login","user",row["id"])
    return {"access_token":tok,"token_type":"bearer","user":{"id":row["id"],"name":row["name"],"role":row["role"],"patient_id":row["patient_id"]}}

@app.get("/api/me")
def me(user=Depends(current_user)): return user
@app.get("/api/dashboard")
def dashboard(user=Depends(current_user)):
    con=db(); role=user["role"]; data={"role":role,"display_role":ROLES[role]}
    data["patients"]=con.execute("SELECT COUNT(*) c FROM patients").fetchone()[0] if role!="patient" else 1
    data["appointments"]=con.execute("SELECT COUNT(*) c FROM appointments WHERE status='scheduled'").fetchone()[0]
    data["open_care_tasks"]=con.execute("SELECT COUNT(*) c FROM care_tasks WHERE status='open'").fetchone()[0]
    data["inventory_alerts"]=con.execute("SELECT COUNT(*) c FROM inventory WHERE quantity<=reorder_level").fetchone()[0]
    data["unpaid_bills"]=con.execute("SELECT COALESCE(SUM(amount),0) s FROM bills WHERE status='unpaid'").fetchone()[0]
    con.close(); return data

@app.post("/api/patients")
def create_patient(req:PatientIn,user=Depends(require("patient:write"))):
    pid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO patients VALUES(?,?,?,?,?,?,?,?,?,?,?)",(pid,req.name,req.dob,req.sex,req.mobile,req.email,req.blood_group,json.dumps(req.allergies),json.dumps(req.conditions),req.emergency_contact,now()));
    orgs=user_org_ids(con,user["sub"]) or ["demo-hospital"]
    for oid in orgs: con.execute("INSERT OR IGNORE INTO patient_organizations(patient_id,organization_id) VALUES(?,?)",(pid,oid))
    publish(con,"patient-events","patient.created",{"patient_id":pid},orgs[0]); con.commit(); con.close(); audit(user,"patient.create","patient",pid); return {"id":pid,**req.model_dump()}
@app.get("/api/patients")
def list_patients(user=Depends(require("patient:read"))):
    con=db();
    if user.get("role")=="admin": rows=con.execute("SELECT * FROM patients ORDER BY created_at DESC").fetchall()
    else:
        orgs=user_org_ids(con,user["sub"]); rows=con.execute("SELECT p.* FROM patients p JOIN patient_organizations po ON po.patient_id=p.id WHERE po.organization_id IN (%s) ORDER BY p.created_at DESC" % ",".join("?"*len(orgs)), orgs).fetchall() if orgs else []
    con.close(); return {"patients":[rowdict(x) for x in rows]}
@app.get("/api/patients/{pid}")
def get_patient(pid,user=Depends(current_user)):
    scoped_patient(user,pid)
    if user["role"]=="patient" or "patient:read" in ROLE_PERMISSIONS[user["role"]] or "*" in ROLE_PERMISSIONS[user["role"]]:
        con=db(); r=con.execute("SELECT * FROM patients WHERE id=?",(pid,)).fetchone(); con.close()
        if not r: raise HTTPException(404,"Patient not found")
        return rowdict(r)
    raise HTTPException(403,"Insufficient permissions")

@app.post("/api/appointments")
def create_appointment(req:AppointmentIn,user=Depends(current_user)):
    if user["role"] not in ("patient","doctor","nurse","care_coordinator","receptionist","admin"):
        raise HTTPException(403,"Appointment creation denied")
    scoped_patient(user, req.patient_id)
    if user["role"]=="patient" and user.get("patient_id")!=req.patient_id: raise HTTPException(403,"Cannot book for another patient")
    aid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO appointments VALUES(?,?,?,?,?,?,?,?)",(aid,req.patient_id,req.clinician_id,req.specialty,req.starts_at,"scheduled",req.reason,now())); con.commit(); con.close(); audit(user,"appointment.create","appointment",aid); return {"id":aid,**req.model_dump(),"status":"scheduled"}
@app.get("/api/appointments")
def appointments(user=Depends(current_user)):
    con=db(); q="SELECT * FROM appointments"; args=()
    if user["role"]=="patient": q+=" WHERE patient_id=?"; args=(user["patient_id"],)
    elif user["role"] not in ("admin","hospital_admin","dean"): q+=" WHERE clinician_id=? OR clinician_id IS NULL"; args=(user["sub"],)
    rows=con.execute(q+" ORDER BY starts_at",args).fetchall(); con.close(); return {"appointments":[rowdict(x) for x in rows]}

@app.post("/api/vitals")
def add_vitals(req:VitalIn,user=Depends(require("vitals:write"))):
    scoped_patient(user, req.patient_id)
    vid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO vitals VALUES(?,?,?,?,?,?,?,?,?,?)",(vid,req.patient_id,req.bp_sys,req.bp_dia,req.heart_rate,req.spo2,req.temperature,req.glucose,req.weight_kg,now())); con.commit(); con.close(); audit(user,"vitals.create","vitals",vid,metadata={"patient_id":req.patient_id}); return {"id":vid,"status":"recorded"}
@app.get("/api/patients/{pid}/vitals")
def vitals(pid,user=Depends(current_user)):
    scoped_patient(user,pid); con=db(); rows=con.execute("SELECT * FROM vitals WHERE patient_id=? ORDER BY recorded_at DESC",(pid,)).fetchall(); con.close(); return {"vitals":[rowdict(x) for x in rows]}

@app.post("/api/labs")
def add_lab(req:LabIn,user=Depends(require("lab:write"))):
    scoped_patient(user, req.patient_id)
    lid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO lab_results VALUES(?,?,?,?,?,?,?,?,?)",(lid,req.patient_id,req.test_name,req.value,req.unit,req.status,req.report_text,None,now())); con.commit(); con.close(); audit(user,"lab.create","lab",lid); return {"id":lid,"status":"recorded"}
@app.get("/api/patients/{pid}/labs")
def labs(pid,user=Depends(current_user)):
    scoped_patient(user,pid)
    if user["role"] not in ("patient","doctor","nurse","lab_technician","care_coordinator","hospital_admin","admin","dean"): raise HTTPException(403,"Lab access denied")
    con=db(); rows=con.execute("SELECT * FROM lab_results WHERE patient_id=? ORDER BY created_at DESC",(pid,)).fetchall(); con.close(); return {"labs":[rowdict(x) for x in rows]}

@app.post("/api/inventory")
def add_inventory(req:InventoryIn,user=Depends(require("inventory:write"))):
    iid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO inventory VALUES(?,?,?,?,?,?,?,?)",(iid,req.sku,req.name,req.category,req.quantity,req.reorder_level,req.unit,now())); con.commit(); con.close(); audit(user,"inventory.create","inventory",iid); return {"id":iid,**req.model_dump()}
@app.get("/api/inventory")
def inventory(user=Depends(require("inventory:read"))):
    con=db(); rows=con.execute("SELECT * FROM inventory ORDER BY name").fetchall(); con.close(); return {"items":[rowdict(x) for x in rows],"low_stock":[rowdict(x) for x in rows if x["quantity"]<=x["reorder_level"]]}
@app.patch("/api/inventory/{iid}")
def adjust_inventory(iid:str,req:InventoryAdjust,user=Depends(require("inventory:write"))):
    con=db(); r=con.execute("SELECT * FROM inventory WHERE id=?",(iid,)).fetchone()
    if not r: con.close(); raise HTTPException(404,"Inventory item not found")
    newq=r["quantity"]+req.delta
    if newq<0: con.close(); raise HTTPException(400,"Quantity cannot become negative")
    con.execute("UPDATE inventory SET quantity=?,updated_at=? WHERE id=?",(newq,now(),iid)); con.commit(); con.close(); audit(user,"inventory.adjust","inventory",iid,metadata={"delta":req.delta}); return {"id":iid,"quantity":newq}

@app.post("/api/care-tasks")
def create_task(req:CareTaskIn,user=Depends(require("care:manage"))):
    scoped_patient(user, req.patient_id)
    tid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO care_tasks VALUES(?,?,?,?,?,?,?,?)",(tid,req.patient_id,req.title,req.owner_role,req.priority,"open",req.due_at,now())); con.commit(); con.close(); audit(user,"care_task.create","care_task",tid); return {"id":tid,**req.model_dump(),"status":"open"}
@app.get("/api/care-tasks")
def care_tasks(user=Depends(current_user)):
    con=db(); q="SELECT * FROM care_tasks"; args=()
    if user["role"]=="patient": q+=" WHERE patient_id=?"; args=(user["patient_id"],)
    rows=con.execute(q+" ORDER BY created_at DESC",args).fetchall(); con.close(); return {"tasks":[rowdict(x) for x in rows]}

@app.post("/api/bills")
def create_bill(req:BillIn,user=Depends(require("billing:write"))):
    scoped_patient(user, req.patient_id)
    bid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO bills VALUES(?,?,?,?,?,?,?)",(bid,req.patient_id,req.amount,"unpaid",req.payer,req.description,now())); con.commit(); con.close(); audit(user,"bill.create","bill",bid); return {"id":bid,"status":"unpaid"}
@app.get("/api/bills")
def bills(user=Depends(require("billing:read"))):
    con=db(); rows=con.execute("SELECT * FROM bills ORDER BY created_at DESC").fetchall(); con.close(); return {"bills":[rowdict(x) for x in rows]}

@app.post("/api/consent")
def consent(req:ConsentIn,user=Depends(current_user)):
    scoped_patient(user, req.patient_id)
    cid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO consent VALUES(?,?,?,?,?,?)",(cid,req.patient_id,req.purpose,1 if req.granted else 0,now(),None if req.granted else now())); con.commit(); con.close(); audit(user,"consent.change","consent",cid); return {"id":cid,"granted":req.granted}

@app.post("/api/documents/upload")
async def upload_document(patient_id:str,user=Depends(current_user),file:UploadFile=File(...)):
    if user["role"]=="patient" and user.get("patient_id")!=patient_id: raise HTTPException(403,"Scope violation")
    if user["role"] not in ("patient","doctor","nurse","care_coordinator","lab_technician","admin","hospital_admin"): raise HTTPException(403,"Document access denied")
    content=await file.read()
    if len(content)>10*1024*1024: raise HTTPException(413,"File exceeds 10MB limit")
    did=str(uuid.uuid4()); text=content.decode("utf-8",errors="ignore") if (file.content_type or "").startswith("text/") else ""
    obj=OBJECT_STORE.put(content,file.filename or "upload",file.content_type or "application/octet-stream")
    refs=[{"type":"uploaded_file","filename":file.filename,"size":len(content),"object_key":obj["key"]}]
    con=db(); con.execute("INSERT INTO documents VALUES(?,?,?,?,?,?,?)",(did,patient_id,file.filename,file.content_type,text,json.dumps(refs),now())); con.execute("INSERT INTO object_metadata VALUES(?,?,?,?,?,?,?)",(str(uuid.uuid4()),obj["key"],patient_id,file.filename,file.content_type,len(content),now())); publish(con,"document-events","document.uploaded",{"document_id":did,"patient_id":patient_id,"object_key":obj["key"]}); con.commit(); con.close(); audit(user,"document.upload","document",did,metadata={"patient_id":patient_id,"object_key":obj["key"]}); return {"id":did,"filename":file.filename,"evidence_refs":refs}

@app.get("/api/audit")
def audit_log(user=Depends(require("audit:read"))):
    con=db(); rows=con.execute("SELECT * FROM audit_events ORDER BY created_at DESC LIMIT 500").fetchall(); con.close(); return {"events":[rowdict(x) for x in rows]}

@app.get("/api/agent-runtime")
def agent_runtime(user=Depends(current_user)): return AgentRuntime.available()

@app.get("/api/agents")
def agents(user=Depends(current_user)):
    agents=[
      ("chat","Patient Health Companion","patient"),("prescription","Prescription Intelligence","patient"),("lab","Lab Report Interpreter","clinical"),("reminder","Medication Reminder","patient"),("insurance","Insurance Intelligence","finance"),("risk","Health Risk Analysis","clinical"),("hospital","Hospital Discovery","clinical"),("doctor","Doctor Productivity","clinical"),("emergency","Emergency Response","emergency"),("family","Family Health","patient"),("cost","Cost Optimization","finance"),("pharmacy","Pharmacy Availability","patient"),("followup","Follow-up Automation","clinical"),("chronic","Chronic Disease Monitoring","clinical"),("preventive","Preventive Health","patient"),("bill","Medical Bill Analyzer","finance"),("document","Clinical Document Extraction","clinical"),("care","Care Coordination","care")]
    return {"agents":[{"id":a,"name":b,"category":c,"execution":"controlled"} for a,b,c in agents],"total":len(agents)}

# Deterministic safety-first fallback; actual source agents are retained under integrations/.
def run_agent(agent,payload):
    if agent=="emergency":
        s=payload.get("symptoms","").lower(); emergency=any(x in s for x in ["chest pain","not breathing","unconscious","stroke","severe bleeding","anaphylaxis"])
        return {"severity":"life_threatening" if emergency else "needs_assessment","call_ambulance":emergency,"ambulance_number":"108","source":"deterministic safety rail","human_review_required":True}
    if agent=="risk":
        score=0; v=payload.get("vitals") or {}; score+=25 if (v.get("bp_sys") or 0)>=140 else 0; score+=25 if (v.get("glucose") or 0)>=126 else 0; score+=20 if (v.get("spo2") or 100)<94 else 0
        return {"overall_risk_score":min(score,100),"risk_category":"high" if score>=50 else "moderate" if score>=25 else "low","human_review_required":True}
    return {"status":"accepted","agent":agent,"human_review_required":True,"evidence_required":True,"message":"Agent execution boundary reached; connect configured model/integration for inference."}

@app.post("/api/agents/{agent_id}/run")
def run_agent_endpoint(agent_id:str,payload:dict,user=Depends(current_user)):
    allowed={x[0] for x in [("chat",),("prescription",),("lab",),("risk",),("emergency",),("care",),("document",)]}
    if agent_id not in allowed: raise HTTPException(404,"Agent not available")
    if agent_id=="emergency" and user["role"] not in ("patient","doctor","nurse","emergency_responder","admin"): raise HTTPException(403,"Emergency access denied")
    result=run_agent(agent_id,payload); rid=str(uuid.uuid4()); raw=json.dumps(payload,sort_keys=True); ih=hashlib.sha256(raw.encode()).hexdigest()
    con=db(); con.execute("INSERT INTO agent_runs VALUES(?,?,?,?,?,?,?,?)",(rid,agent_id,user["sub"],payload.get("patient_id"),ih,json.dumps(result),"completed",now())); con.commit(); con.close(); audit(user,"agent.run","agent",rid,metadata={"agent":agent_id}); return {"run_id":rid,"agent":agent_id,"result":result}

@app.post("/api/emergency/triage")
def emergency(req:EmergencyIn,user=Depends(current_user)): return run_agent_endpoint("emergency",req.model_dump(),user)
@app.post("/api/chat")
def chat(req:ChatIn,user=Depends(current_user)):
    result=AgentRuntime.infer(req.message) if os.getenv("ANTHROPIC_API_KEY") else run_agent("chat",req.model_dump())
    rid=str(uuid.uuid4()); audit(user,"agent.run","agent",rid,metadata={"agent":"chat","mode":result.get("mode")})
    return {"run_id":rid,"agent":"chat","result":result}


@app.get("/api/auth/config")
def auth_config(): return oidc_config()

@app.get("/api/fhir/Patient/{pid}")
def fhir_patient(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid); con=db(); r=con.execute("SELECT * FROM patients WHERE id=?",(pid,)).fetchone(); con.close()
    if not r: raise HTTPException(404,"Patient not found")
    return patient_resource(rowdict(r))

@app.get("/api/fhir/Observation")
def fhir_observations(patient_id:str,user=Depends(current_user)):
    scoped_patient(user,patient_id); con=db(); rows=con.execute("SELECT * FROM vitals WHERE patient_id=? ORDER BY recorded_at DESC",(patient_id,)).fetchall(); con.close()
    return {"resourceType":"Bundle","type":"searchset","entry":[{"resource":observation_resource(rowdict(r))} for r in rows]}

@app.get("/api/events/outbox")
def outbox_events(user=Depends(require("audit:read"))):
    con=db(); rows=con.execute("SELECT * FROM outbox_events ORDER BY created_at DESC LIMIT 200").fetchall(); con.close(); return {"events":[rowdict(r) for r in rows]}

@app.get("/api/readiness")
def readiness():
    checks={"database":"ok","agent_runtime":"ok","filesystem":"ok","object_store":"ok","outbox":"ok"}
    try:
        con=db(); con.execute("SELECT 1").fetchone(); con.close()
    except Exception:
        checks["database"]="error"
    try: OBJECT_STORE.root.mkdir(parents=True,exist_ok=True)
    except Exception: checks["object_store"]="error"
    try:
        con=db(); con.execute("SELECT COUNT(*) FROM outbox_events").fetchone(); con.close()
    except Exception: checks["outbox"]="error"
    return {"status":"ready" if all(v=="ok" for v in checks.values()) else "degraded","checks":checks,"timestamp":now()}


@app.post("/api/clinical-notes")
def create_clinical_note(req:ClinicalNoteIn,user=Depends(current_user)):
    if user["role"] not in ("doctor","nurse","care_coordinator","emergency_responder","admin","hospital_admin"): raise HTTPException(403,"Clinical note access denied")
    scoped_patient(user,req.patient_id); nid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO clinical_notes VALUES(?,?,?,?,?,?,?)",(nid,req.patient_id,user["sub"],req.note_type,req.note,"signed",now())); con.commit(); con.close(); audit(user,"clinical_note.create","clinical_note",nid,metadata={"patient_id":req.patient_id}); return {"id":nid,"status":"signed"}

@app.get("/api/patients/{pid}/clinical-notes")
def clinical_notes(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid)
    if user["role"] not in ("patient","doctor","nurse","care_coordinator","emergency_responder","hospital_admin","admin","dean"): raise HTTPException(403,"Clinical note access denied")
    con=db(); rows=con.execute("SELECT * FROM clinical_notes WHERE patient_id=? ORDER BY created_at DESC",(pid,)).fetchall(); con.close(); return {"notes":[rowdict(r) for r in rows]}

@app.post("/api/diagnoses")
def create_diagnosis(req:DiagnosisIn,user=Depends(current_user)):
    if user["role"] not in ("doctor","emergency_responder","admin"): raise HTTPException(403,"Diagnosis access denied")
    scoped_patient(user,req.patient_id); did=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO diagnoses VALUES(?,?,?,?,?,?,?,?)",(did,req.patient_id,req.code_system,req.code,req.description,req.status,user["sub"],now())); con.commit(); con.close(); audit(user,"diagnosis.create","diagnosis",did); return {"id":did,"status":req.status}

@app.get("/api/patients/{pid}/diagnoses")
def diagnoses(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid); con=db(); rows=con.execute("SELECT * FROM diagnoses WHERE patient_id=? ORDER BY created_at DESC",(pid,)).fetchall(); con.close(); return {"diagnoses":[rowdict(r) for r in rows]}

@app.post("/api/referrals")
def create_referral(req:ReferralIn,user=Depends(current_user)):
    if user["role"] not in ("doctor","care_coordinator","nurse","admin"): raise HTTPException(403,"Referral access denied")
    scoped_patient(user,req.patient_id); rid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO referrals VALUES(?,?,?,?,?,?,?)",(rid,req.patient_id,user["sub"],req.specialty,req.reason,"requested",now())); con.commit(); con.close(); audit(user,"referral.create","referral",rid); return {"id":rid,"status":"requested"}

@app.get("/api/patients/{pid}/referrals")
def referrals(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid); con=db(); rows=con.execute("SELECT * FROM referrals WHERE patient_id=? ORDER BY created_at DESC",(pid,)).fetchall(); con.close(); return {"referrals":[rowdict(r) for r in rows]}

@app.post("/api/insurance")
def create_insurance(req:InsuranceIn,user=Depends(current_user)):
    if user["role"] not in ("finance","receptionist","hospital_admin","admin"): raise HTTPException(403,"Insurance access denied")
    scoped_patient(user,req.patient_id); iid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO insurance_policies VALUES(?,?,?,?,?,?,?)",(iid,req.patient_id,req.payer,req.policy_number,"active",req.coverage,now())); con.commit(); con.close(); audit(user,"insurance.create","insurance",iid); return {"id":iid,"status":"active"}

@app.get("/api/patients/{pid}/insurance")
def insurance(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid);
    if user["role"] not in ("patient","finance","receptionist","doctor","hospital_admin","admin"): raise HTTPException(403,"Insurance access denied")
    con=db(); rows=con.execute("SELECT * FROM insurance_policies WHERE patient_id=? ORDER BY created_at DESC",(pid,)).fetchall(); con.close(); return {"policies":[rowdict(r) for r in rows]}

@app.post("/api/lab-orders")
def create_lab_order(req:LabOrderIn,user=Depends(current_user)):
    if user["role"] not in ("doctor","nurse","lab_technician","admin"): raise HTTPException(403,"Lab order access denied")
    scoped_patient(user,req.patient_id); lid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO lab_orders VALUES(?,?,?,?,?,?,?)",(lid,req.patient_id,user["sub"],req.test_name,req.priority,"ordered",now())); con.commit(); con.close(); audit(user,"lab_order.create","lab_order",lid); return {"id":lid,"status":"ordered"}

@app.get("/api/lab-orders")
def list_lab_orders(user=Depends(current_user)):
    if user["role"] not in ("doctor","nurse","lab_technician","care_coordinator","hospital_admin","admin"): raise HTTPException(403,"Lab order access denied")
    con=db(); rows=con.execute("SELECT * FROM lab_orders ORDER BY created_at DESC").fetchall(); con.close(); return {"orders":[rowdict(r) for r in rows]}

@app.post("/api/beds")
def create_bed(req:BedIn,user=Depends(require("user:manage"))):
    bid=str(uuid.uuid4()); con=db(); orgs=user_org_ids(con,user["sub"]) or ["demo-hospital"]; con.execute("INSERT INTO beds VALUES(?,?,?,?,?,?,?,?)",(bid,orgs[0],req.ward,req.room,req.bed_number,"available",None,now())); con.commit(); con.close(); audit(user,"bed.create","bed",bid); return {"id":bid,"status":"available"}

@app.get("/api/beds")
def beds(user=Depends(current_user)):
    if user["role"] not in ("nurse","doctor","receptionist","hospital_admin","admin","emergency_responder"): raise HTTPException(403,"Bed access denied")
    con=db(); rows=con.execute("SELECT * FROM beds ORDER BY ward,room,bed_number").fetchall(); con.close(); return {"beds":[rowdict(r) for r in rows]}

@app.patch("/api/beds/{bid}")
def assign_bed(bid:str,req:BedAssignIn,user=Depends(current_user)):
    if user["role"] not in ("nurse","receptionist","hospital_admin","admin"): raise HTTPException(403,"Bed assignment denied")
    scoped_patient(user,req.patient_id); con=db(); r=con.execute("SELECT * FROM beds WHERE id=?",(bid,)).fetchone();
    if not r: con.close(); raise HTTPException(404,"Bed not found")
    if r["status"]!="available": con.close(); raise HTTPException(409,"Bed is not available")
    con.execute("UPDATE beds SET status='occupied',patient_id=?,updated_at=? WHERE id=?",(req.patient_id,now(),bid)); con.commit(); con.close(); audit(user,"bed.assign","bed",bid,metadata={"patient_id":req.patient_id}); return {"id":bid,"status":"occupied","patient_id":req.patient_id}

@app.post("/api/procurement")
def procurement(req:ProcurementIn,user=Depends(current_user)):
    if user["role"] not in ("inventory","hospital_admin","admin"): raise HTTPException(403,"Procurement denied")
    orgs=user_org_ids(db(),user["sub"]) or ["demo-hospital"]; rid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO procurement_requests VALUES(?,?,?,?,?,?,?)",(rid,orgs[0],user["sub"],req.item,req.quantity,"requested",now())); con.commit(); con.close(); audit(user,"procurement.create","procurement",rid); return {"id":rid,"status":"requested"}

@app.get("/api/procurement")
def procurement_list(user=Depends(current_user)):
    if user["role"] not in ("inventory","hospital_admin","admin","finance"): raise HTTPException(403,"Procurement denied")
    con=db(); rows=con.execute("SELECT * FROM procurement_requests ORDER BY created_at DESC").fetchall(); con.close(); return {"requests":[rowdict(r) for r in rows]}

@app.post("/api/messages")
def send_message(req:MessageIn,user=Depends(current_user)):
    if req.patient_id: scoped_patient(user, req.patient_id)
    if not req.recipient_id and not req.patient_id: raise HTTPException(400,"recipient_id or patient_id required")
    mid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO messages VALUES(?,?,?,?,?,?,?)",(mid,user["sub"],req.recipient_id,req.patient_id,req.body,"sent",now())); con.commit(); con.close(); audit(user,"message.send","message",mid); return {"id":mid,"status":"sent"}

@app.get("/api/messages")
def messages(user=Depends(current_user)):
    con=db(); rows=con.execute("SELECT * FROM messages WHERE sender_id=? OR recipient_id=? OR patient_id=? ORDER BY created_at DESC LIMIT 200",(user["sub"],user["sub"],user.get("patient_id"))).fetchall(); con.close(); return {"messages":[rowdict(r) for r in rows]}

@app.get("/api/patients/{pid}/summary")
def patient_summary(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid); con=db(); patient=con.execute("SELECT * FROM patients WHERE id=?",(pid,)).fetchone();
    if not patient: con.close(); raise HTTPException(404,"Patient not found")
    summary={"patient":rowdict(patient),"vitals":rowdict(con.execute("SELECT * FROM vitals WHERE patient_id=? ORDER BY recorded_at DESC LIMIT 1",(pid,)).fetchone()),"labs":rowdict(con.execute("SELECT * FROM lab_results WHERE patient_id=? ORDER BY created_at DESC LIMIT 1",(pid,)).fetchone()),"medications": [rowdict(x) for x in con.execute("SELECT * FROM prescriptions WHERE patient_id=? AND status!='cancelled' ORDER BY created_at DESC",(pid,)).fetchall()],"diagnoses":[rowdict(x) for x in con.execute("SELECT * FROM diagnoses WHERE patient_id=? ORDER BY created_at DESC",(pid,)).fetchall()]}; con.close(); return summary

@app.get("/api/organizations")
def organizations(user=Depends(require("user:manage"))):
    con=db(); rows=con.execute("SELECT * FROM organizations ORDER BY name").fetchall(); con.close(); return {"organizations":[rowdict(x) for x in rows]}

@app.post("/api/organizations")
def create_organization(req:OrganizationIn,user=Depends(require("user:manage"))):
    oid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO organizations VALUES(?,?,?,?,?)",(oid,req.name,req.type,1,now())); con.commit(); con.close(); audit(user,"organization.create","organization",oid); return {"id":oid,**req.model_dump(),"active":1}

@app.get("/api/users")
def users(user=Depends(require("user:manage"))):
    con=db(); rows=con.execute("SELECT id,username,name,role,patient_id,active,created_at FROM users ORDER BY name").fetchall(); con.close(); return {"users":[rowdict(x) for x in rows]}

@app.post("/api/prescriptions")
def create_prescription(req:PrescriptionIn,user=Depends(require("prescription:write"))):
    pid=req.patient_id
    con_check=db(); exists=con_check.execute("SELECT 1 FROM patients WHERE id=?",(pid,)).fetchone(); con_check.close()
    if not exists:
        raise HTTPException(404,"Patient not found")
    rid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO prescriptions VALUES(?,?,?,?,?,?,?,?,?,?)",(rid,pid,user["sub"],req.medication_name,req.dose,req.frequency,req.duration,req.instructions,"active",now())); con.commit(); con.close(); audit(user,"prescription.create","prescription",rid,metadata={"patient_id":pid}); return {"id":rid,**req.model_dump(),"status":"active"}

@app.get("/api/patients/{pid}/prescriptions")
def prescriptions(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid)
    if user["role"] not in ("patient","doctor","nurse","pharmacist","care_coordinator","hospital_admin","admin"): raise HTTPException(403,"Prescription access denied")
    con=db(); rows=con.execute("SELECT * FROM prescriptions WHERE patient_id=? ORDER BY created_at DESC",(pid,)).fetchall(); con.close(); return {"prescriptions":[rowdict(x) for x in rows]}

@app.post("/api/dispensations")
def dispense(req:DispenseIn,user=Depends(require("medication:dispense"))):
    con=db(); rx=con.execute("SELECT * FROM prescriptions WHERE id=?",(req.prescription_id,)).fetchone(); con.close()
    if not rx: raise HTTPException(404,"Prescription not found")
    did=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO dispensations VALUES(?,?,?,?,?)",(did,req.prescription_id,user["sub"],req.quantity,now())); con.execute("UPDATE prescriptions SET status='dispensed' WHERE id=?",(req.prescription_id,)); con.commit(); con.close(); audit(user,"medication.dispense","dispensation",did,metadata={"prescription_id":req.prescription_id}); return {"id":did,"status":"dispensed"}

@app.patch("/api/appointments/{aid}")
def update_appointment(aid:str,req:StatusIn,user=Depends(require("appointment:manage"))):
    allowed={"scheduled","confirmed","checked_in","completed","cancelled","no_show"}
    if req.status not in allowed: raise HTTPException(400,"Invalid appointment status")
    con=db(); r=con.execute("SELECT * FROM appointments WHERE id=?",(aid,)).fetchone()
    if not r: con.close(); raise HTTPException(404,"Appointment not found")
    con.execute("UPDATE appointments SET status=? WHERE id=?",(req.status,aid)); con.commit(); con.close(); audit(user,"appointment.status","appointment",aid,metadata={"status":req.status}); return {"id":aid,"status":req.status}

@app.patch("/api/care-tasks/{tid}")
def update_task(tid:str,req:StatusIn,user=Depends(require("care:manage"))):
    allowed={"open","in_progress","blocked","completed","cancelled"}
    if req.status not in allowed: raise HTTPException(400,"Invalid task status")
    con=db(); r=con.execute("SELECT * FROM care_tasks WHERE id=?",(tid,)).fetchone()
    if not r: con.close(); raise HTTPException(404,"Care task not found")
    con.execute("UPDATE care_tasks SET status=? WHERE id=?",(req.status,tid)); con.commit(); con.close(); audit(user,"care_task.status","care_task",tid,metadata={"status":req.status}); return {"id":tid,"status":req.status}

@app.patch("/api/bills/{bid}")
def update_bill(bid:str,req:StatusIn,user=Depends(require("billing:write"))):
    allowed={"unpaid","pending","paid","cancelled"}
    if req.status not in allowed: raise HTTPException(400,"Invalid bill status")
    con=db(); r=con.execute("SELECT 1 FROM bills WHERE id=?",(bid,)).fetchone()
    if not r: con.close(); raise HTTPException(404,"Bill not found")
    con.execute("UPDATE bills SET status=? WHERE id=?",(req.status,bid)); con.commit(); con.close(); audit(user,"bill.status","bill",bid,metadata={"status":req.status}); return {"id":bid,"status":req.status}

@app.get("/api/patients/{pid}/documents")
def patient_documents(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid)
    if user["role"] not in ("patient","doctor","nurse","care_coordinator","lab_technician","hospital_admin","admin"): raise HTTPException(403,"Document access denied")
    con=db(); rows=con.execute("SELECT id,patient_id,filename,content_type,evidence_refs,created_at FROM documents WHERE patient_id=? ORDER BY created_at DESC",(pid,)).fetchall(); con.close(); return {"documents":[rowdict(x) for x in rows]}

@app.get("/api/patients/{pid}/timeline")
def patient_timeline(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid)
    con=db(); events=[]
    for table,kind,datecol in [("appointments","appointment","created_at"),("vitals","vital", "recorded_at"),("lab_results","lab","created_at"),("prescriptions","prescription","created_at"),("care_tasks","care_task","created_at"),("bills","bill","created_at")]:
        rows=con.execute(f"SELECT * FROM {table} WHERE patient_id=? ORDER BY {datecol} DESC LIMIT 100",(pid,)).fetchall()
        for r in rows: events.append({"type":kind,"timestamp":r[datecol],"data":rowdict(r)})
    con.close(); events.sort(key=lambda x:x["timestamp"],reverse=True); return {"patient_id":pid,"events":events[:300]}

@app.get("/api/notifications")
def notifications(user=Depends(current_user)):
    con=db(); rows=con.execute("SELECT * FROM notifications WHERE user_id=? OR patient_id=? ORDER BY created_at DESC LIMIT 100",(user["sub"],user.get("patient_id"))).fetchall(); con.close(); return {"notifications":[rowdict(x) for x in rows]}

@app.post("/api/notifications")
def create_notification(req:NotificationIn,user=Depends(current_user)):
    if user["role"] not in ("doctor","nurse","pharmacist","care_coordinator","receptionist","emergency_responder","hospital_admin","admin"): raise HTTPException(403,"Notification creation denied")
    if req.patient_id: scoped_patient(user,req.patient_id)
    nid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO notifications VALUES(?,?,?,?,?,?,?,?)",(nid,req.user_id,req.patient_id,req.title,req.body,req.channel,"queued",now())); con.commit(); con.close(); audit(user,"notification.create","notification",nid); return {"id":nid,"status":"queued"}

@app.get("/api/command-center")
def command_center(user=Depends(require("analytics:read"))):
    con=db()
    def count(table,where="",args=()): return con.execute(f"SELECT COUNT(*) FROM {table} {where}",args).fetchone()[0]
    data={"patients":count("patients"),"appointments_today":count("appointments","WHERE date(starts_at)=date('now')"),"open_care_tasks":count("care_tasks","WHERE status IN ('open','in_progress')"),"low_stock":count("inventory","WHERE quantity<=reorder_level"),"unpaid_bills":count("bills","WHERE status='unpaid'"),"active_prescriptions":count("prescriptions","WHERE status='active'"),"pending_labs":count("lab_results","WHERE status IN ('pending','ordered')")}
    con.close(); return data


# ---------------------- interoperability, knowledge and notifications ----------------------

FHIR_RESOURCE_TYPES={"Patient","Observation","Condition","MedicationRequest","MedicationStatement","AllergyIntolerance","Encounter","DiagnosticReport","ServiceRequest","CarePlan","DocumentReference","Practitioner","Organization"}

def _fhir_upsert(con, resource_type, resource, patient_id=None, organization_id=None):
    rid=resource.get("id") or str(uuid.uuid4()); resource=dict(resource); resource["resourceType"]=resource_type; resource["id"]=rid
    existing=con.execute("SELECT version FROM fhir_resources WHERE resource_type=? AND resource_id=?",(resource_type,rid)).fetchone()
    version=(existing["version"]+1) if existing else 1
    if existing:
        con.execute("UPDATE fhir_resources SET body=?,version=?,updated_at=?,patient_id=COALESCE(?,patient_id),organization_id=COALESCE(?,organization_id) WHERE resource_type=? AND resource_id=?",(json.dumps(resource,sort_keys=True),version,now(),patient_id,organization_id,resource_type,rid))
    else:
        con.execute("INSERT INTO fhir_resources VALUES(?,?,?,?,?,?,?,?,?)",(str(uuid.uuid4()),organization_id,patient_id,resource_type,rid,version,json.dumps(resource,sort_keys=True),now(),now()))
    return resource,version


@app.post("/api/documents/{did}/extract")
async def extract_document(did:str,user=Depends(current_user)):
    con=db(); doc=con.execute("SELECT * FROM documents WHERE id=?",(did,)).fetchone()
    if not doc: con.close(); raise HTTPException(404,"Document not found")
    scoped_patient(user,doc["patient_id"])
    if user["role"] not in ("patient","doctor","nurse","lab_technician","care_coordinator","hospital_admin","admin"): con.close(); raise HTTPException(403,"Document extraction denied")
    text=doc["content"] or ""
    # Provider-neutral extraction baseline: plain text is extracted locally; PDF/OCR adapters are explicit future providers.
    if not text:
        text="Binary document stored; text extraction provider is not configured for this file type."
    excerpt=text[:4000]
    eid=str(uuid.uuid4())
    con.execute("INSERT INTO evidence_items VALUES(?,?,?,?,?,?,?,?)",(eid,doc["patient_id"],"clinical_document",did,doc["filename"],excerpt,json.dumps({"method":"local-text-baseline","object_metadata":True}),now()))
    refs=json.loads(doc["evidence_refs"] or "[]"); refs.append({"evidence_id":eid,"extraction":"local-text-baseline"})
    con.execute("UPDATE documents SET evidence_refs=? WHERE id=?",(json.dumps(refs),did)); con.commit(); con.close()
    audit(user,"document.extract","document",did,metadata={"evidence_id":eid,"method":"local-text-baseline"})
    return {"document_id":did,"evidence_id":eid,"status":"extracted","method":"local-text-baseline","provider_required_for_ocr":not bool(doc["content"]),"excerpt":excerpt}

@app.get("/api/fhir/metadata")
def fhir_capability():
    return {"resourceType":"CapabilityStatement","status":"active","kind":"instance","fhirVersion":"4.0.1","format":["json"],"rest":[{"mode":"server","resource":[{"type":x,"interaction":[{"code":"read"},{"code":"search-type"},{"code":"create"}] } for x in sorted(FHIR_RESOURCE_TYPES)]}]}

@app.get("/.well-known/smart-configuration")
def smart_configuration(request:Request):
    base=str(request.base_url).rstrip('/')
    return {"issuer":base,"authorization_endpoint":base+"/api/smart/authorize","token_endpoint":base+"/api/smart/token","capabilities":["launch-ehr","client-public","client-confidential-symmetric","permission-v1"],"scopes_supported":["openid","fhirUser","launch","patient/*.read","patient/*.write","user/*.read","user/*.write"]}

@app.post("/api/fhir/resources")
def create_fhir_resource(req:FHIRResourceIn,user=Depends(current_user)):
    if req.resource_type not in FHIR_RESOURCE_TYPES: raise HTTPException(400,"Unsupported FHIR resource type")
    if req.patient_id: scoped_patient(user,req.patient_id)
    if user["role"] not in ("doctor","nurse","lab_technician","care_coordinator","hospital_admin","admin"): raise HTTPException(403,"FHIR write requires clinical/admin role")
    con=db(); orgs=user_org_ids(con,user["sub"]); resource,version=_fhir_upsert(con,req.resource_type,req.resource,req.patient_id,orgs[0] if orgs else None); con.commit(); con.close(); audit(user,"fhir.create","fhir_resource",resource["id"],metadata={"resource_type":req.resource_type}); return {"resource":resource,"version":version}

@app.get("/api/fhir/{resource_type}/{resource_id}")
def get_fhir_resource(resource_type:str,resource_id:str,user=Depends(current_user)):
    if resource_type not in FHIR_RESOURCE_TYPES: raise HTTPException(400,"Unsupported FHIR resource type")
    con=db(); row=con.execute("SELECT * FROM fhir_resources WHERE resource_type=? AND resource_id=?",(resource_type,resource_id)).fetchone(); con.close()
    if not row: raise HTTPException(404,"FHIR resource not found")
    if row["patient_id"]: scoped_patient(user,row["patient_id"])
    return json.loads(row["body"])

@app.get("/api/fhir/{resource_type}")
def search_fhir(resource_type:str,patient_id:Optional[str]=None,limit:int=50,user=Depends(current_user)):
    if resource_type not in FHIR_RESOURCE_TYPES: raise HTTPException(400,"Unsupported FHIR resource type")
    con=db()
    if patient_id:
        scoped_patient(user,patient_id); rows=con.execute("SELECT body FROM fhir_resources WHERE resource_type=? AND patient_id=? ORDER BY updated_at DESC LIMIT ?",(resource_type,patient_id,min(limit,100))).fetchall()
    else:
        rows=con.execute("SELECT body FROM fhir_resources WHERE resource_type=? ORDER BY updated_at DESC LIMIT ?",(resource_type,min(limit,100))).fetchall()
    con.close(); return {"resourceType":"Bundle","type":"searchset","total":len(rows),"entry":[{"resource":json.loads(x["body"])} for x in rows]}

@app.post("/api/knowledge")
def add_knowledge(req:KnowledgeIn,user=Depends(require("analytics:read"))):
    if user["role"] not in ("doctor","care_coordinator","hospital_admin","dean","admin"): raise HTTPException(403,"Knowledge management denied")
    kid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO knowledge_documents VALUES(?,?,?,?,?,?)",(kid,req.title,req.source,req.content,json.dumps(req.tags),now())); con.commit(); con.close(); audit(user,"knowledge.create","knowledge_document",kid); return {"id":kid,"status":"indexed"}

@app.post("/api/knowledge/search")
def search_knowledge(req:KnowledgeSearchIn,user=Depends(current_user)):
    terms=[x.lower() for x in req.query.split() if len(x)>2][:12]
    con=db(); rows=con.execute("SELECT * FROM knowledge_documents ORDER BY created_at DESC").fetchall(); con.close()
    scored=[]
    for r in rows:
        hay=(r["title"]+' '+r["content"]+' '+r["source"]).lower(); score=sum(hay.count(t) for t in terms)
        if score: scored.append((score,rowdict(r)))
    scored.sort(key=lambda x:(x[0],x[1]["created_at"]),reverse=True)
    return {"query":req.query,"results":[dict(x[1],score=x[0]) for x in scored[:max(1,min(req.limit,20))]],"retrieval":"keyword-baseline","model_claim":False}

@app.post("/api/notifications/{nid}/dispatch")
def dispatch_notification(nid:str,req:NotificationDispatchIn,user=Depends(current_user)):
    if user["role"] not in ("doctor","nurse","care_coordinator","pharmacist","receptionist","emergency_responder","hospital_admin","admin"): raise HTTPException(403,"Notification dispatch denied")
    con=db(); n=con.execute("SELECT * FROM notifications WHERE id=?",(nid,)).fetchone()
    if not n: con.close(); raise HTTPException(404,"Notification not found")
    channel=req.channel or n["channel"]
    did=str(uuid.uuid4()); con.execute("INSERT INTO notification_deliveries VALUES(?,?,?,?,?,?,?,?)",(did,nid,channel,"queued","local",0,None,None)); con.execute("UPDATE notifications SET status='queued' WHERE id=?",(nid,)); con.commit(); con.close(); audit(user,"notification.dispatch","notification",nid,metadata={"channel":channel}); return {"notification_id":nid,"delivery_id":did,"status":"queued","provider":"local"}

@app.post("/api/notifications/{nid}/deliver-local")
def deliver_notification_local(nid:str,user=Depends(require("audit:read"))):
    con=db(); d=con.execute("SELECT * FROM notification_deliveries WHERE notification_id=? ORDER BY attempt DESC LIMIT 1",(nid,)).fetchone()
    if not d: con.close(); raise HTTPException(404,"Delivery not found")
    con.execute("UPDATE notification_deliveries SET status='delivered',attempt=attempt+1,delivered_at=? WHERE id=?",(now(),d["id"])); con.execute("UPDATE notifications SET status='delivered' WHERE id=?",(nid,)); con.commit(); con.close(); audit(user,"notification.deliver","notification",nid); return {"notification_id":nid,"status":"delivered","provider":"local"}

@app.patch("/api/care-journeys/{jid}/steps/{sid}")
def update_journey_step(jid:str,sid:str,req:JourneyStepStatusIn,user=Depends(current_user)):
    if req.status not in ("pending","in_progress","completed","blocked","skipped"): raise HTTPException(400,"Invalid step status")
    if user["role"] not in ("doctor","nurse","care_coordinator","hospital_admin","admin"): raise HTTPException(403,"Journey management denied")
    con=db(); j=con.execute("SELECT * FROM care_journeys WHERE id=?",(jid,)).fetchone(); step=con.execute("SELECT * FROM care_journey_steps WHERE id=? AND journey_id=?",(sid,jid)).fetchone()
    if not j or not step: con.close(); raise HTTPException(404,"Journey step not found")
    scoped_patient(user,j["patient_id"]); con.execute("UPDATE care_journey_steps SET status=? WHERE id=?",(req.status,sid)); con.execute("UPDATE care_journeys SET updated_at=? WHERE id=?",(now(),jid)); con.commit(); con.close(); audit(user,"journey.step.update","care_journey_step",sid,metadata={"status":req.status}); return {"id":sid,"status":req.status}

@app.get("/api/clinical/next-actions/{pid}")
def clinical_next_actions(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid)
    con=db(); tasks=con.execute("SELECT * FROM care_tasks WHERE patient_id=? AND status NOT IN ('completed','cancelled') ORDER BY due_at,created_at LIMIT 20",(pid,)).fetchall(); appts=con.execute("SELECT * FROM appointments WHERE patient_id=? AND status IN ('scheduled','confirmed') ORDER BY starts_at LIMIT 10",(pid,)).fetchall(); cons=con.execute("SELECT * FROM consent WHERE patient_id=? AND granted=0 ORDER BY granted_at DESC",(pid,)).fetchall(); con.close()
    actions=[]
    actions += [{"type":"care_task","id":x["id"],"title":x["title"],"priority":x["priority"]} for x in tasks]
    actions += [{"type":"appointment","id":x["id"],"starts_at":x["starts_at"],"status":x["status"]} for x in appts]
    actions += [{"type":"consent","id":x["id"],"purpose":x["purpose"],"action":"review"} for x in cons]
    return {"patient_id":pid,"actions":actions}

@app.get("/portal")
def portal(): return FileResponse(ROOT/"web"/"portal.html")

@app.get("/")
def home(): return FileResponse(ROOT/"web"/"index.html")


# ---------------------- governed clinical intelligence ----------------------

def _hash_input(value:str)->str:
    return hashlib.sha256(value.encode()).hexdigest()

def _evidence_for_patient(con, pid, limit=40):
    rows=con.execute("SELECT * FROM evidence_items WHERE patient_id=? ORDER BY created_at DESC LIMIT ?",(pid,limit)).fetchall()
    return [rowdict(r) for r in rows]

@app.post("/api/ai/evidence")
def add_evidence(req:EvidenceIn,user=Depends(current_user)):
    scoped_patient(user,req.patient_id)
    allowed={"patient","doctor","nurse","lab_technician","care_coordinator","emergency_responder","hospital_admin","admin"}
    if user["role"] not in allowed: raise HTTPException(403,"Evidence access denied")
    eid=str(uuid.uuid4()); con=db()
    con.execute("INSERT INTO evidence_items VALUES(?,?,?,?,?,?,?,?)",(eid,req.patient_id,req.source_type,req.source_id,req.title,req.excerpt,json.dumps(req.provenance,sort_keys=True),now()))
    con.commit(); con.close(); audit(user,"evidence.create","evidence",eid,metadata={"patient_id":req.patient_id,"source_type":req.source_type})
    return {"id":eid,"status":"stored","provenance":req.provenance}

@app.get("/api/patients/{pid}/evidence")
def list_evidence(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid)
    con=db(); rows=_evidence_for_patient(con,pid); con.close()
    return {"evidence":rows}

@app.post("/api/ai/summarize")
def governed_summary(req:AISummaryIn,user=Depends(current_user)):
    scoped_patient(user,req.patient_id)
    if user["role"] not in ("patient","doctor","nurse","care_coordinator","emergency_responder","hospital_admin","admin"): raise HTTPException(403,"AI summary access denied")
    con=db()
    patient=con.execute("SELECT * FROM patients WHERE id=?",(req.patient_id,)).fetchone()
    vitals=con.execute("SELECT * FROM vitals WHERE patient_id=? ORDER BY recorded_at DESC LIMIT 5",(req.patient_id,)).fetchall()
    labs=con.execute("SELECT * FROM lab_results WHERE patient_id=? ORDER BY created_at DESC LIMIT 10",(req.patient_id,)).fetchall()
    notes=con.execute("SELECT * FROM clinical_notes WHERE patient_id=? ORDER BY created_at DESC LIMIT 5",(req.patient_id,)).fetchall()
    evidence=_evidence_for_patient(con,req.patient_id)
    context={"patient":rowdict(patient),"vitals":[rowdict(x) for x in vitals],"labs":[rowdict(x) for x in labs],"notes":[rowdict(x) for x in notes],"evidence":evidence}
    context_text=json.dumps(context,sort_keys=True,default=str)
    result=AgentRuntime.infer(req.question+"\nUse only the supplied record context. Identify evidence and uncertainty.\n"+context_text)
    run_id=str(uuid.uuid4()); input_hash=_hash_input(req.question+context_text)
    output=result.get("response") if result.get("response") else json.dumps(result)
    con.execute("INSERT INTO agent_runs VALUES(?,?,?,?,?,?,?,?)",(run_id,"evidence-grounded-summary",user["sub"],req.patient_id,input_hash,output,"completed",now()))
    approval_id=str(uuid.uuid4())
    con.execute("INSERT INTO ai_approvals VALUES(?,?,?,?,?,?)",(approval_id,run_id,None,"pending",None,None))
    con.commit(); con.close(); audit(user,"ai.summary","agent_run",run_id,metadata={"patient_id":req.patient_id,"evidence_count":len(evidence)})
    return {"run_id":run_id,"approval_id":approval_id,"status":"completed","human_review_required":True,"evidence_ids":[x["id"] for x in evidence],"result":result}

@app.get("/api/ai/runs/{run_id}")
def ai_run(run_id:str,user=Depends(current_user)):
    con=db(); run=con.execute("SELECT * FROM agent_runs WHERE id=?",(run_id,)).fetchone()
    approval=con.execute("SELECT * FROM ai_approvals WHERE run_id=?",(run_id,)).fetchone(); con.close()
    if not run: raise HTTPException(404,"AI run not found")
    if run["patient_id"]: scoped_patient(user,run["patient_id"])
    return {"run":rowdict(run),"approval":rowdict(approval)}

@app.post("/api/ai/runs/{run_id}/approval")
def approve_ai(run_id:str,req:ApprovalIn,user=Depends(current_user)):
    if user["role"] not in ("doctor","nurse","care_coordinator","hospital_admin","admin"): raise HTTPException(403,"AI approval requires authorized reviewer")
    if req.decision not in ("approved","rejected"): raise HTTPException(400,"Decision must be approved or rejected")
    con=db(); run=con.execute("SELECT * FROM agent_runs WHERE id=?",(run_id,)).fetchone()
    if not run: con.close(); raise HTTPException(404,"AI run not found")
    if run["patient_id"]: scoped_patient(user,run["patient_id"])
    con.execute("UPDATE ai_approvals SET reviewer_id=?,decision=?,comment=?,decided_at=? WHERE run_id=?",(user["sub"],req.decision,req.comment,now(),run_id)); con.commit(); con.close()
    audit(user,"ai.approval","agent_run",run_id,metadata={"decision":req.decision})
    return {"run_id":run_id,"decision":req.decision,"status":"recorded"}

@app.post("/api/cds/assess")
def cds_assess(req:CDSIn,user=Depends(current_user)):
    scoped_patient(user,req.patient_id)
    if user["role"] not in ("doctor","nurse","emergency_responder","care_coordinator","hospital_admin","admin"): raise HTTPException(403,"CDS access denied")
    con=db(); findings=[]; snapshot={}
    if req.include_vitals:
        v=con.execute("SELECT * FROM vitals WHERE patient_id=? ORDER BY recorded_at DESC LIMIT 1",(req.patient_id,)).fetchone()
        snapshot["vitals"]=rowdict(v)
        if v:
            if v["spo2"] is not None and v["spo2"] < 92: findings.append({"type":"oxygenation","severity":"high","message":"Latest recorded SpO2 is below 92%; clinician assessment is required."})
            if v["heart_rate"] is not None and (v["heart_rate"] > 120 or v["heart_rate"] < 45): findings.append({"type":"heart_rate","severity":"moderate","message":"Latest heart rate is outside the configured advisory range."})
            if v["temperature"] is not None and v["temperature"] >= 39: findings.append({"type":"temperature","severity":"moderate","message":"Latest temperature is elevated; clinician assessment is required."})
    if req.include_labs:
        ls=con.execute("SELECT * FROM lab_results WHERE patient_id=? ORDER BY created_at DESC LIMIT 10",(req.patient_id,)).fetchall(); snapshot["labs"]=[rowdict(x) for x in ls]
        for l in ls:
            if str(l["status"] or "").lower() in ("critical","panic"): findings.append({"type":"lab","severity":"high","message":f"Lab result {l['test_name']} is marked {l['status']}; review required.","source_id":l["id"]})
    severity="high" if any(x["severity"]=="high" for x in findings) else ("moderate" if findings else "none")
    aid=str(uuid.uuid4()); con.execute("INSERT INTO cds_assessments VALUES(?,?,?,?,?,?,?,?)",(aid,req.patient_id,user["sub"],json.dumps(snapshot,sort_keys=True,default=str),json.dumps(findings,sort_keys=True),severity,"advisory",now())); con.commit(); con.close()
    audit(user,"cds.assess","cds_assessment",aid,metadata={"patient_id":req.patient_id,"severity":severity})
    return {"assessment_id":aid,"severity":severity,"findings":findings,"status":"advisory","human_review_required":True}

@app.get("/api/patients/{pid}/cds")
def cds_history(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid); con=db(); rows=con.execute("SELECT * FROM cds_assessments WHERE patient_id=? ORDER BY created_at DESC LIMIT 50",(pid,)).fetchall(); con.close(); return {"assessments":[rowdict(x) for x in rows]}

@app.post("/api/care-journeys")
def create_journey(req:JourneyIn,user=Depends(current_user)):
    scoped_patient(user,req.patient_id)
    if user["role"] not in ("doctor","nurse","care_coordinator","hospital_admin","admin"): raise HTTPException(403,"Journey management denied")
    jid=str(uuid.uuid4()); con=db(); con.execute("INSERT INTO care_journeys VALUES(?,?,?,?,?,?,?)",(jid,req.patient_id,req.journey_type,"active",req.goal,now(),now())); con.commit(); con.close(); audit(user,"journey.create","care_journey",jid,metadata={"patient_id":req.patient_id}); return {"id":jid,"status":"active"}

@app.post("/api/care-journeys/{jid}/steps")
def add_journey_step(jid:str,req:JourneyStepIn,user=Depends(current_user)):
    if user["role"] not in ("doctor","nurse","care_coordinator","hospital_admin","admin"): raise HTTPException(403,"Journey management denied")
    con=db(); journey=con.execute("SELECT * FROM care_journeys WHERE id=?",(jid,)).fetchone()
    if not journey: con.close(); raise HTTPException(404,"Journey not found")
    scoped_patient(user,journey["patient_id"])
    sid=str(uuid.uuid4()); con.execute("INSERT INTO care_journey_steps VALUES(?,?,?,?,?,?,?,?)",(sid,jid,req.title,req.owner_role,"pending",req.due_at,1 if req.evidence_required else 0,now())); con.execute("UPDATE care_journeys SET updated_at=? WHERE id=?",(now(),jid)); con.commit(); con.close(); audit(user,"journey.step.create","care_journey_step",sid,metadata={"journey_id":jid}); return {"id":sid,"status":"pending"}

@app.get("/api/patients/{pid}/care-journeys")
def list_journeys(pid:str,user=Depends(current_user)):
    scoped_patient(user,pid); con=db(); journeys=[rowdict(x) for x in con.execute("SELECT * FROM care_journeys WHERE patient_id=? ORDER BY updated_at DESC",(pid,)).fetchall()]
    for j in journeys: j["steps"]=[rowdict(x) for x in con.execute("SELECT * FROM care_journey_steps WHERE journey_id=? ORDER BY created_at",(j["id"],)).fetchall()]
    con.close(); return {"journeys":journeys}
