# Agent Runtime

This is the promotion boundary for the supplied OmniDoctor and VitalOS agent implementations.

- Authorization is enforced by the API gateway before execution.
- High-impact clinical actions are not committed by the model.
- Evidence and audit IDs should be attached to promoted agent contracts.
- If no model key is configured, deterministic safety workflows remain available.
- The copied source agents are under `integrations/omnidoctor` and `integrations/vitalos-engine`.
