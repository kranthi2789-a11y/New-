# notification-service

In-app notification and outbound channel abstraction.
