"""Local durable-outbox worker.

Production deployments can replace the sink with Kafka/Redis Streams/Temporal/NATS.
This worker proves the transactional outbox can be drained without losing events.
"""
import json, os, time
from pathlib import Path
from services.api_gateway.main import db

def run_once(limit=50):
    con=db(); rows=con.execute("SELECT * FROM outbox_events WHERE status='pending' ORDER BY created_at LIMIT ?",(limit,)).fetchall()
    sink=Path(os.getenv("EVENT_SINK", "data/events.jsonl")); sink.parent.mkdir(parents=True,exist_ok=True)
    count=0
    for r in rows:
        try:
            with sink.open("a",encoding="utf-8") as f:
                f.write(json.dumps({"id":r["id"],"topic":r["topic"],"event_type":r["event_type"],"payload":json.loads(r["payload"]),"organization_id":r["organization_id"]})+"\n")
            con.execute("UPDATE outbox_events SET status='published', last_error=NULL WHERE id=?",(r["id"],)); count+=1
        except Exception as exc:
            con.execute("UPDATE outbox_events SET status='pending', last_error=? WHERE id=?",(str(exc),r["id"]))
    con.commit(); con.close(); return count

if __name__ == '__main__':
    while True:
        n=run_once()
        if n==0: time.sleep(float(os.getenv("OUTBOX_POLL_SECONDS","2")))
