import json, uuid
from datetime import datetime, timezone

def utcnow(): return datetime.now(timezone.utc).isoformat()

def publish(con, topic, event_type, payload, organization_id=None):
    eid=str(uuid.uuid4())
    con.execute("INSERT INTO outbox_events(id,topic,event_type,payload,organization_id,status,attempts,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (eid,topic,event_type,json.dumps(payload,sort_keys=True),organization_id,"pending",0,utcnow()))
    return eid

def claim(con, limit=50):
    rows=con.execute("SELECT * FROM outbox_events WHERE status='pending' ORDER BY created_at LIMIT ?",(limit,)).fetchall()
    for r in rows:
        con.execute("UPDATE outbox_events SET status='processing', attempts=attempts+1 WHERE id=?",(r['id'],))
    return rows

def complete(con,event_id,success=True,error=None):
    con.execute("UPDATE outbox_events SET status=?, last_error=? WHERE id=?",('published' if success else 'pending',error,event_id))
