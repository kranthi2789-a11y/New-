# Durable workflow boundary

The platform uses a transactional **outbox** in the application database. Business events are committed with the originating transaction, preventing the classic "database write succeeded but event publish failed" gap.

`outbox_events` is intentionally provider-neutral. A production deployment can attach Kafka, Redis Streams, NATS, Temporal or another approved workflow/event service without changing clinical transaction code.

Required worker behavior:
1. claim `pending` events;
2. publish to the configured broker/workflow system;
3. mark `published` only after broker acknowledgement;
4. retry transient failures with backoff;
5. retain payload and error history for operational audit.
