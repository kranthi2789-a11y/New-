from fastapi import HTTPException


def ensure_user_org(con, user_id, organization_id):
    con.execute("INSERT OR IGNORE INTO user_organizations(user_id, organization_id) VALUES(?,?)", (user_id, organization_id))


def user_org_ids(con, user_id):
    return [r[0] for r in con.execute("SELECT organization_id FROM user_organizations WHERE user_id=?", (user_id,)).fetchall()]


def patient_org_ids(con, patient_id):
    return [r[0] for r in con.execute("SELECT organization_id FROM patient_organizations WHERE patient_id=?", (patient_id,)).fetchall()]


def assert_patient_access(con, user, patient_id):
    """Fail-closed resource authorization. Unknown/unmapped records are never implicitly public."""
    if user.get("role") == "admin":
        return
    if user.get("role") == "patient" and user.get("patient_id") != patient_id:
        raise HTTPException(403, "Patient scope violation")
    uorg = set(user_org_ids(con, user["sub"]))
    porg = set(patient_org_ids(con, patient_id))
    if not porg:
        raise HTTPException(403, "Patient has no organization mapping")
    if not uorg or not (uorg & porg):
        raise HTTPException(403, "Organization scope violation")
