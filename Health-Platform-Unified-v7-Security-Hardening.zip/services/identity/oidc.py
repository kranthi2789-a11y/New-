import os

def config():
    return {
      "enabled": bool(os.getenv("OIDC_ISSUER")),
      "issuer": os.getenv("OIDC_ISSUER"),
      "client_id": os.getenv("OIDC_CLIENT_ID"),
      "scopes": os.getenv("OIDC_SCOPES","openid profile email").split(),
      "mode": "oidc-ready" if os.getenv("OIDC_ISSUER") else "local-jwt"
    }
