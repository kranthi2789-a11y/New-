import os
os.environ['HEALTH_DB']='/tmp/health_platform_test.db'
os.environ['HEALTH_JWT_SECRET']='test-secret-0123456789-abcdef-0123456789'
try: os.remove('/tmp/health_platform_test.db')
except FileNotFoundError: pass
from fastapi.testclient import TestClient
from services.api_gateway.main import app, init_db

c=TestClient(app)

def login(user,pw):
    r=c.post('/api/login',json={'username':user,'password':pw}); assert r.status_code==200; return r.json()['access_token']
def h(t): return {'Authorization':'Bearer '+t}

def test_all_roles_login():
    creds=[('patient.demo','patient123'),('doctor.demo','doctor123'),('nurse.demo','nurse123'),('pharmacy.demo','pharm123'),('inventory.demo','inventory123'),('lab.demo','lab123'),('coordinator.demo','care123'),('reception.demo','reception123'),('emergency.demo','emergency123'),('finance.demo','finance123'),('dean.demo','dean123'),('hospitaladmin.demo','hospital123'),('admin.demo','admin123')]
    for u,p in creds: assert login(u,p)

def test_patient_isolation():
    t=login('patient.demo','patient123')
    assert c.get('/api/patients/demo-patient',headers=h(t)).status_code==200
    assert c.get('/api/patients/not-owned',headers=h(t)).status_code==403

def test_doctor_patient_and_inventory_boundaries():
    d=login('doctor.demo','doctor123')
    assert c.get('/api/patients',headers=h(d)).status_code==200
    assert c.get('/api/inventory',headers=h(d)).status_code==200
    assert c.post('/api/inventory',headers=h(d),json={'sku':'X','name':'X','quantity':1}).status_code==403

def test_patient_can_book_but_not_inventory():
    p=login('patient.demo','patient123')
    assert c.post('/api/appointments',headers=h(p),json={'patient_id':'demo-patient','starts_at':'2026-10-13T10:00:00','specialty':'Cardiology'}).status_code==200
    assert c.get('/api/inventory',headers=h(p)).status_code==403

def test_inventory_and_care_workflow():
    i=login('inventory.demo','inventory123')
    r=c.post('/api/inventory',headers=h(i),json={'sku':'TEST-1','name':'Test Item','quantity':5,'reorder_level':2}); assert r.status_code==200
    iid=r.json()['id']; assert c.patch('/api/inventory/'+iid,headers=h(i),json={'delta':-2}).status_code==200
    co=login('coordinator.demo','care123')
    r=c.post('/api/care-tasks',headers=h(co),json={'patient_id':'demo-patient','title':'Follow up','priority':'high'}); assert r.status_code==200
    assert c.get('/api/care-tasks',headers=h(co)).status_code==200

def test_lab_vitals_and_audit():
    l=login('lab.demo','lab123'); assert c.post('/api/labs',headers=h(l),json={'patient_id':'demo-patient','test_name':'HbA1c','value':'6.1','unit':'%'}).status_code==200
    n=login('nurse.demo','nurse123'); assert c.post('/api/vitals',headers=h(n),json={'patient_id':'demo-patient','bp_sys':120,'bp_dia':80,'spo2':98}).status_code==200
    a=login('admin.demo','admin123'); r=c.get('/api/audit',headers=h(a)); assert r.status_code==200 and len(r.json()['events'])>0

def test_emergency_safety_rail():
    p=login('patient.demo','patient123'); r=c.post('/api/emergency/triage',headers=h(p),json={'symptoms':'severe chest pain and sweating','location':'Hyderabad'}); assert r.status_code==200; assert r.json()['result']['call_ambulance'] is True

def test_agent_registry():
    t=login('doctor.demo','doctor123'); r=c.get('/api/agents',headers=h(t)); assert r.status_code==200; assert r.json()['total']>=18

def test_readiness_and_command_center():
    a=login('admin.demo','admin123')
    assert c.get('/api/readiness').status_code==200
    r=c.get('/api/command-center',headers=h(a)); assert r.status_code==200; assert 'patients' in r.json()

def test_prescription_and_dispense_workflow():
    d=login('doctor.demo','doctor123')
    r=c.post('/api/prescriptions',headers=h(d),json={'patient_id':'demo-patient','medication_name':'DemoMed','dose':'10mg','frequency':'daily'}); assert r.status_code==200
    rx=r.json()['id']
    p=login('pharmacy.demo','pharm123')
    r=c.get('/api/patients/demo-patient/prescriptions',headers=h(p)); assert r.status_code==200 and any(x['id']==rx for x in r.json()['prescriptions'])
    r=c.post('/api/dispensations',headers=h(p),json={'prescription_id':rx,'quantity':10}); assert r.status_code==200

def test_workflow_status_updates():
    d=login('doctor.demo','doctor123')
    r=c.post('/api/appointments',headers=h(d),json={'patient_id':'demo-patient','starts_at':'2026-10-14T10:00:00','specialty':'General Medicine'}); assert r.status_code==200
    aid=r.json()['id']; assert c.patch('/api/appointments/'+aid,headers=h(d),json={'status':'confirmed'}).status_code==200
    co=login('coordinator.demo','care123')
    r=c.post('/api/care-tasks',headers=h(co),json={'patient_id':'demo-patient','title':'Review result'}); assert r.status_code==200
    tid=r.json()['id']; assert c.patch('/api/care-tasks/'+tid,headers=h(co),json={'status':'completed'}).status_code==200

def test_admin_user_and_org_control_plane():
    a=login('admin.demo','admin123')
    assert c.get('/api/users',headers=h(a)).status_code==200
    r=c.post('/api/organizations',headers=h(a),json={'name':'Test Hospital','type':'hospital'}); assert r.status_code==200
    assert c.get('/api/organizations',headers=h(a)).status_code==200

def test_patient_timeline_and_documents():
    p=login('patient.demo','patient123')
    assert c.get('/api/patients/demo-patient/timeline',headers=h(p)).status_code==200
    assert c.get('/api/patients/demo-patient/documents',headers=h(p)).status_code==200

def test_clinical_workspace_and_records():
    d=login('doctor.demo','doctor123')
    r=c.post('/api/clinical-notes',headers=h(d),json={'patient_id':'demo-patient','note_type':'progress','note':'Clinical follow-up note'}); assert r.status_code==200
    r=c.post('/api/diagnoses',headers=h(d),json={'patient_id':'demo-patient','description':'Demo condition','code_system':'ICD-10','code':'Z00.00'}); assert r.status_code==200
    r=c.post('/api/referrals',headers=h(d),json={'patient_id':'demo-patient','specialty':'Cardiology','reason':'Specialist review'}); assert r.status_code==200
    assert c.get('/api/patients/demo-patient/clinical-notes',headers=h(d)).status_code==200
    assert c.get('/api/patients/demo-patient/diagnoses',headers=h(d)).status_code==200
    assert c.get('/api/patients/demo-patient/referrals',headers=h(d)).status_code==200

def test_lab_order_and_insurance():
    d=login('doctor.demo','doctor123')
    assert c.post('/api/lab-orders',headers=h(d),json={'patient_id':'demo-patient','test_name':'CBC'}).status_code==200
    assert c.get('/api/lab-orders',headers=h(d)).status_code==200
    f=login('finance.demo','finance123')
    assert c.post('/api/insurance',headers=h(f),json={'patient_id':'demo-patient','payer':'Demo Health','policy_number':'P-001'}).status_code==200
    assert c.get('/api/patients/demo-patient/insurance',headers=h(f)).status_code==200

def test_bed_and_procurement_workflows():
    a=login('admin.demo','admin123')
    r=c.post('/api/beds',headers=h(a),json={'ward':'A','room':'101','bed_number':'01'}); assert r.status_code==200
    bid=r.json()['id']; n=login('nurse.demo','nurse123')
    assert c.get('/api/beds',headers=h(n)).status_code==200
    assert c.patch('/api/beds/'+bid,headers=h(n),json={'patient_id':'demo-patient'}).status_code==200
    i=login('inventory.demo','inventory123')
    assert c.post('/api/procurement',headers=h(i),json={'item':'Surgical gloves','quantity':100}).status_code==200
    assert c.get('/api/procurement',headers=h(i)).status_code==200

def test_messages_and_portal():
    d=login('doctor.demo','doctor123')
    assert c.post('/api/messages',headers=h(d),json={'patient_id':'demo-patient','body':'Follow-up reminder'}).status_code==200
    assert c.get('/api/messages',headers=h(d)).status_code==200
    assert c.get('/portal').status_code==200

def test_patient_summary_is_scoped():
    p=login('patient.demo','patient123')
    assert c.get('/api/patients/demo-patient/summary',headers=h(p)).status_code==200
    assert c.get('/api/patients/not-owned/summary',headers=h(p)).status_code==403

def test_governed_ai_evidence_summary_and_approval():
    d=login('doctor.demo','doctor123')
    r=c.post('/api/ai/evidence',headers=h(d),json={'patient_id':'demo-patient','source_type':'lab_result','source_id':'demo-lab','title':'HbA1c report','excerpt':'HbA1c 6.1%','provenance':{'system':'test','recorded_at':'2026-10-12'}})
    assert r.status_code==200; eid=r.json()['id']
    r=c.get('/api/patients/demo-patient/evidence',headers=h(d)); assert r.status_code==200 and any(x['id']==eid for x in r.json()['evidence'])
    r=c.post('/api/ai/summarize',headers=h(d),json={'patient_id':'demo-patient','question':'Summarize recent information.'}); assert r.status_code==200
    run_id=r.json()['run_id']; assert r.json()['human_review_required'] is True
    r=c.get('/api/ai/runs/'+run_id,headers=h(d)); assert r.status_code==200 and r.json()['approval']['decision']=='pending'
    r=c.post('/api/ai/runs/'+run_id+'/approval',headers=h(d),json={'decision':'approved','comment':'Reviewed evidence'}); assert r.status_code==200

def test_cds_and_care_journey():
    n=login('nurse.demo','nurse123')
    c.post('/api/vitals',headers=h(n),json={'patient_id':'demo-patient','spo2':88,'heart_rate':130})
    r=c.post('/api/cds/assess',headers=h(n),json={'patient_id':'demo-patient'}); assert r.status_code==200 and r.json()['severity']=='high' and r.json()['human_review_required'] is True
    co=login('coordinator.demo','care123')
    r=c.post('/api/care-journeys',headers=h(co),json={'patient_id':'demo-patient','journey_type':'post-discharge','goal':'Safe follow-up'}); assert r.status_code==200
    jid=r.json()['id']; r=c.post('/api/care-journeys/'+jid+'/steps',headers=h(co),json={'title':'Schedule follow-up','owner_role':'care_coordinator','evidence_required':True}); assert r.status_code==200
    r=c.get('/api/patients/demo-patient/care-journeys',headers=h(co)); assert r.status_code==200 and len(r.json()['journeys'][0]['steps'])>=1

def test_fhir_capability_and_resource_roundtrip():
    d=login('doctor.demo','doctor123')
    r=c.get('/api/fhir/metadata'); assert r.status_code==200 and r.json()['fhirVersion']=='4.0.1'
    r=c.post('/api/fhir/resources',headers=h(d),json={'resource_type':'Condition','patient_id':'demo-patient','resource':{'resourceType':'Condition','clinicalStatus':{'text':'active'},'code':{'text':'Hypertension'}}})
    assert r.status_code==200; rid=r.json()['resource']['id']
    r=c.get('/api/fhir/Condition/'+rid,headers=h(d)); assert r.status_code==200 and r.json()['resourceType']=='Condition'
    r=c.get('/api/fhir/Condition',headers=h(d),params={'patient_id':'demo-patient'}); assert r.status_code==200 and r.json()['total']>=1

def test_smart_metadata_and_knowledge_retrieval():
    d=login('admin.demo','admin123')
    r=c.get('/.well-known/smart-configuration'); assert r.status_code==200 and '/api/smart/authorize' in r.json()['authorization_endpoint']
    r=c.post('/api/knowledge',headers=h(d),json={'title':'Demo protocol','source':'internal-test','content':'Post discharge follow-up should be reviewed within seven days.','tags':['follow-up']}); assert r.status_code==200
    r=c.post('/api/knowledge/search',headers=h(d),json={'query':'post discharge follow-up'}); assert r.status_code==200 and r.json()['results']

def test_notification_dispatch_and_next_actions():
    co=login('coordinator.demo','care123')
    r=c.post('/api/notifications',headers=h(co),json={'patient_id':'demo-patient','title':'Follow up','body':'Please review your appointment.','channel':'in_app'}); assert r.status_code==200; nid=r.json()['id']
    r=c.post('/api/notifications/'+nid+'/dispatch',headers=h(co),json={}); assert r.status_code==200
    a=login('admin.demo','admin123'); assert c.post('/api/notifications/'+nid+'/deliver-local',headers=h(a)).status_code==200
    assert c.get('/api/clinical/next-actions/demo-patient',headers=h(co)).status_code==200

def test_care_journey_step_transition():
    co=login('coordinator.demo','care123')
    r=c.post('/api/care-journeys',headers=h(co),json={'patient_id':'demo-patient','journey_type':'diabetes','goal':'Follow-up'}); jid=r.json()['id']
    r=c.post('/api/care-journeys/'+jid+'/steps',headers=h(co),json={'title':'Review labs','owner_role':'doctor'}); sid=r.json()['id']
    r=c.patch('/api/care-journeys/'+jid+'/steps/'+sid,headers=h(co),json={'status':'in_progress'}); assert r.status_code==200
    r=c.patch('/api/care-journeys/'+jid+'/steps/'+sid,headers=h(co),json={'status':'completed'}); assert r.status_code==200 and r.json()['status']=='completed'

def test_document_extraction_creates_evidence():
    d=login('doctor.demo','doctor123')
    files={'file':('report.txt',b'Lab report: HbA1c 6.1 percent. Follow-up in seven days.','text/plain')}
    r=c.post('/api/documents/upload',headers={'Authorization':'Bearer '+d},params={'patient_id':'demo-patient'},files=files); assert r.status_code==200
    did=r.json()['id']; r=c.post('/api/documents/'+did+'/extract',headers=h(d)); assert r.status_code==200 and r.json()['evidence_id']
