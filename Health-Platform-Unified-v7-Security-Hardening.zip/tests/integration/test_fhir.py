import os
os.environ['HEALTH_DB']='/tmp/health_platform_fhir.db'
os.environ['HEALTH_JWT_SECRET']='test-secret-0123456789-abcdef-0123456789'
try: os.remove('/tmp/health_platform_fhir.db')
except FileNotFoundError: pass
from fastapi.testclient import TestClient
from services.api_gateway.main import app
c=TestClient(app)
def login(u,p): return c.post('/api/login',json={'username':u,'password':p}).json()['access_token']
def h(t): return {'Authorization':'Bearer '+t}
def test_fhir_patient_and_observation():
    t=login('doctor.demo','doctor123')
    p=c.get('/api/fhir/Patient/demo-patient',headers=h(t)); assert p.status_code==200 and p.json()['resourceType']=='Patient'
    v=c.post('/api/vitals',headers=h(login('nurse.demo','nurse123')),json={'patient_id':'demo-patient','bp_sys':120,'bp_dia':80}); assert v.status_code==200
    obs=c.get('/api/fhir/Observation?patient_id=demo-patient',headers=h(t)); assert obs.status_code==200 and obs.json()['resourceType']=='Bundle'
