import os
os.environ['HEALTH_DB']='/tmp/health_platform_security.db'
os.environ['HEALTH_JWT_SECRET']='test-secret-0123456789-abcdef-0123456789'
try: os.remove('/tmp/health_platform_security.db')
except FileNotFoundError: pass
from fastapi.testclient import TestClient
from services.api_gateway.main import app, init_db
init_db()
c=TestClient(app)
def login(u,p): return c.post('/api/login',json={'username':u,'password':p}).json()['access_token']
def h(t): return {'Authorization':'Bearer '+t}
def test_org_boundary_for_patient_records():
    p=login('patient.demo','patient123')
    assert c.get('/api/patients/demo-patient',headers=h(p)).status_code==200
    assert c.get('/api/patients/unknown',headers=h(p)).status_code==403

def test_security_headers():
    r=c.get('/api/health')
    assert r.headers.get('x-content-type-options')=='nosniff'
    assert 'frame-ancestors' in r.headers.get('content-security-policy','')

def test_oidc_boundary():
    r=c.get('/api/auth/config')
    assert r.status_code==200 and r.json()['mode'] in ('local-jwt','oidc-ready')


def test_unmapped_patient_is_denied_to_non_admin():
    from services.persistence.tenant import assert_patient_access
    from services.api_gateway.main import db
    from fastapi import HTTPException
    con=db()
    # Existing demo user has an organization, but this patient deliberately has none.
    con.execute("INSERT OR IGNORE INTO patients(id,name,created_at) VALUES(?,?,?)", ('unmapped-security-test','Unmapped','2026-10-13T00:00:00Z'))
    con.commit()
    row=con.execute("SELECT id FROM users WHERE username='doctor.demo'").fetchone()
    try:
        assert_patient_access(con, {"sub":row['id'],"role":"doctor"}, 'unmapped-security-test')
        assert False, 'unmapped patient should be denied'
    except HTTPException as exc:
        assert exc.status_code == 403
    finally:
        con.close()

def test_cross_organization_patient_is_denied():
    from services.persistence.tenant import assert_patient_access
    from services.api_gateway.main import db
    from fastapi import HTTPException
    con=db()
    con.execute("INSERT OR IGNORE INTO patients(id,name,created_at) VALUES(?,?,?)", ('other-org-security-test','Other Org','2026-10-13T00:00:00Z'))
    con.execute("INSERT OR IGNORE INTO organizations(id,name,type,created_at) VALUES(?,?,?,?)", ('isolated-org','Isolated','hospital','2026-10-13T00:00:00Z'))
    con.execute("INSERT OR IGNORE INTO patient_organizations(patient_id,organization_id) VALUES(?,?)", ('other-org-security-test','isolated-org'))
    con.commit()
    row=con.execute("SELECT id FROM users WHERE username='doctor.demo'").fetchone()
    try:
        assert_patient_access(con, {"sub":row['id'],"role":"doctor"}, 'other-org-security-test')
        assert False, 'cross-organization patient should be denied'
    except HTTPException as exc:
        assert exc.status_code == 403
    finally:
        con.close()
