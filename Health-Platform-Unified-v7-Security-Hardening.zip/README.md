# Health Platform — Unified Healthcare Operating Platform

## What this is
A runnable healthcare platform assembled from the strongest implementation patterns and source capabilities found across the supplied VitalOS, OmniDoctor, OmniCare and legacy claims packages.

**Canonical runtime:** `services/api_gateway/main.py` + `web/index.html`.

The source implementations are preserved under `integrations/` so they can be progressively promoted into the canonical services without losing provenance.

## Included capabilities
- Role-based login and server-side authorization
- Patient registry and patient-scoped access
- Appointment workflow
- Vitals and lab results
- Clinical documents with evidence references
- Care tasks / care coordination
- Inventory and low-stock monitoring
- Billing records
- Consent records
- Immutable-by-append audit event trail (application-level)
- AI agent registry and controlled execution boundary
- Safety-first emergency triage rail
- VitalOS clinical engine source, governance, orchestration, audit-chain and resilience components
- OmniDoctor 16-agent source library
- OmniCare agent library and working UI reference
- Prescription, lab, risk, emergency, pharmacy, insurance, chronic-care and preventive-care capabilities retained for integration
- Legacy COBOL/JCL/DB2 claims assets retained as a separate integration boundary
- PWA reference assets

## Roles
Patient, Doctor, Nurse, Pharmacist, Inventory Manager, Lab Technician, Care Coordinator, Receptionist, Emergency Responder, Finance, Dean / Medical College Admin, Hospital Administrator, Platform Administrator.

The server enforces permissions. The browser only presents a role workspace; it is not a security boundary.

## Run locally

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export HEALTH_JWT_SECRET="replace-with-a-long-random-secret"
uvicorn services.api_gateway.main:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000`.

### Development accounts

These are generated automatically only for local development:

| Role | Username | Password |
|---|---|---|
| Patient | patient.demo | patient123 |
| Doctor | doctor.demo | doctor123 |
| Nurse | nurse.demo | nurse123 |
| Pharmacist | pharmacy.demo | pharm123 |
| Inventory | inventory.demo | inventory123 |
| Lab | lab.demo | lab123 |
| Care Coordinator | coordinator.demo | care123 |
| Reception | reception.demo | reception123 |
| Emergency | emergency.demo | emergency123 |
| Finance | finance.demo | finance123 |
| Dean | dean.demo | dean123 |
| Hospital Admin | hospitaladmin.demo | hospital123 |
| Platform Admin | admin.demo | admin123 |

**Never use these credentials outside local development.**

## Tests

```bash
pytest -q
```

The test suite covers authentication, every role's login, authorization boundaries, patient isolation, appointments, inventory, care tasks, lab/vitals, audit and emergency safety behavior.

## Architecture direction

```text
                         HEALTH PLATFORM
                                |
          +---------------------+----------------------+
          |                     |                      |
     Patient Apps         Clinical Apps          Operations Apps
          |                     |                      |
          +---------------------+----------------------+
                                |
                         API / Identity
                                |
       +------------------------+-------------------------+
       |                        |                         |
 Clinical Rules           Workflow / Care          Agent Runtime
       |                        |                         |
       +------------------------+-------------------------+
                                |
              Evidence + Audit + Consent + Policy
                                |
       +-------------+----------+----------+-------------+
       |             |                     |             |
      EHR/FHIR     Labs                 Pharmacy       Claims
       |             |                     |             |
    PostgreSQL / enterprise storage / event infrastructure
```

## Source strategy

- **VitalOS v4:** primary source for clinical governance, orchestration, roles, consent, privacy, CDSS, billing, FHIR, offline queue, audit and resilience.
- **OmniDoctor:** primary source for patient-facing healthcare agents and India-specific workflows.
- **OmniCare Continuum:** primary source/reference for care missions, wearable events, consent, evidence traces and working workspace UX.
- **INMED CORE:** retained for legacy claims/eligibility/rating integration patterns; not mixed into the clinical domain model.
- **Campus360:** not copied into the clinical runtime because it is an education-domain product. Its generic dashboard/agent patterns can be referenced separately if a medical-college module is later enabled.

## Production boundary
This repository is runnable and testable, but it is **not a claim of regulatory certification or clinical production readiness**. Before real patient data: replace demo auth with enterprise identity/SSO, use managed PostgreSQL/object storage, secrets management, encryption, formal audit retention, tenant isolation, FHIR/HL7 validation, clinical evaluation datasets, model governance, penetration testing, backup/restore testing, observability and deployment-specific regulatory controls.

## No-mockup rule
Any feature shown as implemented in the canonical runtime must have executable code and tests. Where an integration is only preserved from a source package or requires a vendor account/EHR connection, it is explicitly labeled as an integration boundary rather than presented as connected.


## Enterprise clinical workspace
The shared `/portal` application provides role-specific workspaces for patient, clinician, nursing, pharmacy, inventory, laboratory, care coordination, front desk, emergency, finance, dean, hospital admin and platform admin roles. The API remains the security boundary.

### Additional transactional domains
Clinical notes, diagnoses, referrals, insurance policies, lab orders, bed management, procurement, messaging and patient summaries are included in the canonical API.

### Validation
The current local test suite is 22/22 passing. The application was also started over HTTP and `/api/health` and `/api/readiness` returned healthy/ready.

### Production boundary
PostgreSQL, Redis, OIDC, object storage and external FHIR/EHR services remain configurable integration dependencies. They are not represented as live validated connections in this local build.

## v6 additions

See `docs/README-V6.md` for the interoperability and intelligence layer added after the v5 foundation.
