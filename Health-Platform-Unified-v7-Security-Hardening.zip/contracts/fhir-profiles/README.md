# FHIR Profiles
FHIR boundary currently exposes Patient and Observation projections. Production SMART-on-FHIR conformance remains an integration gate.
