# Agent Contracts
Agent input/output must identify evidence, confidence/uncertainty where applicable, human review requirements, and patient scope.
