# API Contracts
Canonical REST endpoints are exposed by `services/api_gateway`. Sensitive resources require JWT + RBAC + patient/organization scope.
