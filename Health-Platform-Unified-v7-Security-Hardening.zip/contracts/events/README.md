# Event Contracts
Events use the transactional outbox. Consumers must be idempotent using event id.
