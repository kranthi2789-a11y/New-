      * 6. ELG-COPY
       01  ELIG-RECORD.
           05 ELIGIBILITY-ID        PIC X(10).
           05 ELIGIBILITY-STATUS    PIC X(1).
           05 ELIG-START-DATE       PIC X(10).
           05 ELIG-END-DATE         PIC X(10).
           05 PROGRAM-CODE          PIC X(3).
           05 COUNTY-CODE           PIC X(3).
