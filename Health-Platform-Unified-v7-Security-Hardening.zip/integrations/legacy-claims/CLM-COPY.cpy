      * 8. CLM-COPY
       01  CLAIM-RECORD.
           05 CLAIM-ID              PIC X(15).
           05 MEMBER-ID             PIC X(10).
           05 PROVIDER-ID           PIC X(10).
           05 SERVICE-CODE          PIC X(5).
           05 SERVICE-DATE          PIC X(10).
           05 UNITS                 PIC 9(3).
           05 BILLED-AMOUNT         PIC S9(7)V99 COMP-3.
           05 ALLOWED-AMOUNT        PIC S9(7)V99 COMP-3.
           05 CALCULATED-RATE       PIC S9(7)V99 COMP-3.
           05 CLAIM-STATUS          PIC X(2).
           05 DENIAL-CODE           PIC X(3).
           05 CLM-PROGRAM-CODE      PIC X(3).
