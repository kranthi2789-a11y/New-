       IDENTIFICATION DIVISION.
       PROGRAM-ID. RATECALC1.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT RATE-VSAM ASSIGN TO RATVSAM
               ORGANIZATION IS INDEXED
               ACCESS IS DYNAMIC
               RECORD KEY IS VSAM-RATE-KEY.
       DATA DIVISION.
       FILE SECTION.
       FD  RATE-VSAM.
       01  VSAM-RATE-REC.
           05 VSAM-RATE-KEY.
              10 V-PROV-ID          PIC X(10).
              10 V-SRV-CD           PIC X(5).
              10 V-EFF-DT           PIC X(10).
           05 VSAM-CALC-RATE        PIC S9(7)V99 COMP-3.
       WORKING-STORAGE SECTION.
           EXEC SQL INCLUDE SQLCA END-EXEC.
           COPY RATE-COPY.
           COPY RULE-COPY.
           01 WS-DB2-NETWORK-IND    PIC X(1).
       LINKAGE SECTION.
       01  LS-PROV-ID               PIC X(10).
       01  LS-SRV-CD                PIC X(5).
       01  LS-SRV-DT                PIC X(10).
       01  LS-CALC-RATE             PIC S9(7)V99 COMP-3.
       01  LS-RATE-FOUND            PIC X(1).
       PROCEDURE DIVISION USING LS-PROV-ID LS-SRV-CD LS-SRV-DT 
                                LS-CALC-RATE LS-RATE-FOUND.
       0000-MAIN.
           MOVE 'N' TO LS-RATE-FOUND.
           MOVE 0 TO LS-CALC-RATE.
           PERFORM 1000-GET-RATE.
           GOBACK.

       1000-GET-RATE.
      * BREX TEST: IN-RATE-001 & IN-RATE-002 (Effective Date Check)
      * BREX TEST: IN-DATE-001 (Service Date vs Process Date)
           EXEC SQL
               SELECT BASE_RATE, RATE_PERCENT, NETWORK_IND, EFFECTIVE_DATE
               INTO :BASE-RATE, :RATE-PERCENT, :WS-DB2-NETWORK-IND, :RATE-EFFECTIVE-DATE
               FROM INMED.PRVRATE
               WHERE PROVIDER_ID = :LS-PROV-ID
                 AND SERVICE_CODE = :LS-SRV-CD
                 AND EFFECTIVE_DATE <= :LS-SRV-DT
                 AND (END_DATE >= :LS-SRV-DT OR END_DATE IS NULL)
           END-EXEC.
           IF SQLCODE = 0
               MOVE 'Y' TO LS-RATE-FOUND
               PERFORM 2000-CALCULATE
               PERFORM 3000-WRITE-STAGING
           END-IF.

       2000-CALCULATE.
      * BREX TEST: IN-RATE-003 (Out of network synthetic adjustment)
           IF WS-DB2-NETWORK-IND = 'N'
               COMPUTE LS-CALC-RATE = BASE-RATE * (DEFAULT-RATE-PERCENT / 100)
           ELSE
               COMPUTE LS-CALC-RATE = BASE-RATE * (RATE-PERCENT / 100)
           END-IF.

       3000-WRITE-STAGING.
           MOVE LS-PROV-ID TO V-PROV-ID.
           MOVE LS-SRV-CD TO V-SRV-CD.
           MOVE RATE-EFFECTIVE-DATE TO V-EFF-DT.
           MOVE LS-CALC-RATE TO VSAM-CALC-RATE.
           WRITE VSAM-RATE-REC.
