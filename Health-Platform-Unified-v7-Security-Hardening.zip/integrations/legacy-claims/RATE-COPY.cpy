      * 7. RATE-COPY
       01  RATE-RECORD.
           05 PROVIDER-ID           PIC X(10).
           05 SERVICE-CODE          PIC X(5).
           05 RATE-TYPE             PIC X(2).
           05 BASE-RATE             PIC S9(7)V99 COMP-3.
           05 RATE-PERCENT          PIC S9(3)V99 COMP-3.
           05 RATE-EFFECTIVE-DATE   PIC X(10).
           05 RATE-END-DATE         PIC X(10).
           05 RATE-STATUS           PIC X(1).
