      * 5. MBR-COPY
       01  MEMBER-RECORD.
           05 MEMBER-ID             PIC X(10).
           05 MEDICAID-ID           PIC X(12).
           05 MEMBER-DOB            PIC X(10).
           05 MEMBER-STATUS         PIC X(1).
           05 PLAN-ID               PIC X(5).
           05 COUNTY-CODE           PIC X(3).
           05 MEMBER-EFFECTIVE-DATE PIC X(10).
           05 MEMBER-TERM-DATE      PIC X(10).
