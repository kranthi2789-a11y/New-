      * 9. RULE-COPY (SYNTHETIC PARAMETERS - TEST ONLY)
       01  RULE-CONTROL-BLOCK.
           05 STATE-CODE            PIC X(2) VALUE 'IN'.
           05 PROGRAM-CODE          PIC X(3) VALUE 'MED'.
           05 MIN-AGE               PIC 9(3) VALUE 000.
           05 MAX-AGE               PIC 9(3) VALUE 120.
           05 LOOKBACK-DAYS         PIC 9(3) VALUE 090.
           05 DEFAULT-RATE-PERCENT  PIC S9(3)V99 COMP-3 VALUE 50.00.
           05 EFFECTIVE-DATE        PIC X(10) VALUE '2024-01-01'.
           05 RULE-VERSION          PIC X(4) VALUE 'V1.0'.
           05 ELIGIBILITY-REQUIRED  PIC X(1) VALUE 'Y'.
           05 NETWORK-REQUIRED      PIC X(1) VALUE 'N'.
           05 TEST-ONLY-FLAG        PIC X(9) VALUE 'TEST_ONLY'.
