       IDENTIFICATION DIVISION.
       PROGRAM-ID. CLAIMPROC.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
           EXEC SQL INCLUDE SQLCA END-EXEC.
           COPY CLM-COPY.
           COPY MBR-COPY.
           COPY ELG-COPY.
           COPY RULE-COPY.
           01 WS-MEMELG-STATUS      PIC X(1).
           01 WS-RATE-FOUND         PIC X(1).
           01 WS-TEMP-RATE          PIC S9(7)V99 COMP-3.
           01 WS-DB2-PROG-CODE      PIC X(3).
       PROCEDURE DIVISION.
       0000-PROCESS-CLAIM.
      * BREX TEST: IN-CLM-001 (Valid member before pricing)
           EXEC SQL
               SELECT PROGRAM_CODE INTO :WS-DB2-PROG-CODE
               FROM INMED.MBRMAST WHERE MEMBER_ID = :MEMBER-ID
           END-EXEC.
           IF SQLCODE NOT = 0
               MOVE 'DN1' TO DENIAL-CODE
               MOVE 'RE' TO CLAIM-STATUS
               PERFORM 9000-INSERT-TXN
               GOBACK
           END-IF.

      * BREX TEST: IN-ELG-003 (Program Code Match)
           IF WS-DB2-PROG-CODE NOT = CLM-PROGRAM-CODE
               MOVE 'DN2' TO DENIAL-CODE
               MOVE 'RE' TO CLAIM-STATUS
               PERFORM 9000-INSERT-TXN
               GOBACK
           END-IF.

      * BREX TEST: IN-CLM-002 (Eligible service date)
           CALL 'MEMELG01' USING MEMBER-ID, SERVICE-DATE, WS-MEMELG-STATUS.
           IF WS-MEMELG-STATUS = 'N'
               MOVE 'DN3' TO DENIAL-CODE
               MOVE 'RE' TO CLAIM-STATUS
               PERFORM 9000-INSERT-TXN
               GOBACK
           END-IF.

      * BREX TEST: IN-CLM-004 (Reject if no rate exists)
           CALL 'RATECALC1' USING PROVIDER-ID, SERVICE-CODE, SERVICE-DATE, 
                                  WS-TEMP-RATE, WS-RATE-FOUND.
           IF WS-RATE-FOUND = 'N'
               MOVE 'DN4' TO DENIAL-CODE
               MOVE 'RE' TO CLAIM-STATUS
               PERFORM 9000-INSERT-TXN
               GOBACK
           END-IF.

      * BREX TEST: IN-CLM-003 (Allowed Amount Calculation)
           MOVE WS-TEMP-RATE TO CALCULATED-RATE.
           COMPUTE ALLOWED-AMOUNT = CALCULATED-RATE * UNITS.
           MOVE 'PD' TO CLAIM-STATUS.
           PERFORM 9000-INSERT-TXN.
           GOBACK.

       9000-INSERT-TXN.
           EXEC SQL
               INSERT INTO INMED.CLAIMTXN 
               (CLAIM_ID, MEMBER_ID, PROVIDER_ID, SERVICE_CODE, SERVICE_DATE,
                UNITS, BILLED_AMOUNT, ALLOWED_AMOUNT, CALCULATED_RATE, 
                CLAIM_STATUS, DENIAL_CODE)
               VALUES (:CLAIM-ID, :MEMBER-ID, :PROVIDER-ID, :SERVICE-CODE, 
                       :SERVICE-DATE, :UNITS, :BILLED-AMOUNT, :ALLOWED-AMOUNT, 
                       :CALCULATED-RATE, :CLAIM-STATUS, :DENIAL-CODE)
           END-EXEC.
