"""
VitalOS AI Agents — Main FastAPI Application v4
The Python "Counsel" — stateless inference + all provider-grade layers.

New in v4:
  Clinical Protocols    → /api/v1/protocols/*
  Clinical Specialties  → /api/v1/specialty/*
  CDSS                  → /api/v1/cdss/*
  Orders                → /api/v1/orders/*
  SLA Monitor           → /api/v1/sla/*
  Legal + Signatures    → /api/v1/legal/*
  EHR Timeline          → /api/v1/ehr/*
  Consent (DPDP)        → /api/v1/consent/*
  Human Override        → /api/v1/override/*
  Billing Engine        → /api/v1/billing/*
  FHIR/HL7              → /api/v1/integrations/*
  Analytics             → /api/v1/analytics/*
  Privacy (DPDP)        → /api/v1/privacy/*
  Offline Queue         → /api/v1/offline/*
"""

import os, jwt, logging, uuid
from contextlib import asynccontextmanager
from datetime import datetime
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from core.config   import settings
from core.database import init_db
from core.rag      import init_rag
from agents.orchestrator import AgentOrchestrator

# ── v3 routers ────────────────────────────────────────────────
from auth.router            import router as auth_router
from api.routes             import router as agents_router
from roles.patient.router   import router as patient_router
from roles.doctor.router    import router as doctor_router
from roles.nurse.router     import router as nurse_router
from roles.admin.router     import router as admin_router
from roles.emergency.router import router as emergency_router

# ── v4 new routers ─────────────────────────────────────────────
from orders.order_service    import router as orders_router
from sla.sla_engine          import sla_router
from legal.legal_service     import legal_router
from ehr.ehr_service         import ehr_router
from consent.consent_service import consent_router
from override.override_service import override_router
from billing.billing_engine  import billing_router
from integrations.fhir_adapter import integrations_router
from analytics.analytics_engine import analytics_router
from privacy.privacy_service import privacy_router
from offline.offline_queue   import offline_router

# ── SLA background job ────────────────────────────────────────
from sla.sla_engine import sla_check_job
from offline.offline_queue import OfflineQueue

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("vitalos.main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("VitalOS AI Agents v4 starting up...")
    await init_db()
    await init_rag()
    await AgentOrchestrator.init()

    # Start SLA background monitor (every 30 seconds)
    import asyncio
    async def sla_loop():
        while True:
            await asyncio.sleep(30)
            await sla_check_job()
    asyncio.create_task(sla_loop())

    # Start offline queue retry loop
    asyncio.create_task(OfflineQueue.get().start_retry_loop())

    logger.info(
        "✅ v4 online | 16 agents | 5 roles | 17 new modules | "
        "CDSS | Protocols | FHIR | SLA | Legal | EHR | DPDP"
    )
    yield
    # Shutdown
    from core.kafka_helper import shutdown_producer
    await shutdown_producer()
    logger.info("VitalOS AI Agents v4 shutdown complete")


app = FastAPI(
    title="VitalOS Clinical AI v4 — The Counsel",
    description=(
        "16 AI agents + provider-grade clinical layers.\n\n"
        "**New in v4**: CDSS · Protocols · Specialties · Orders · "
        "SLA · Legal/Signatures · EHR Timeline · DPDP Consent · "
        "Override · Billing · FHIR/HL7 · Analytics · Privacy · Offline Mode\n\n"
        "**Auth**: POST /auth/login/otp/send (patient) | "
        "POST /auth/login/password (staff)\n\n"
        "**Emergency triage**: /api/v1/emergency/triage — NO auth (life-critical)"
    ),
    version="4.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def verify_token(request: Request) -> dict:
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(401, "MISSING_AUTH_TOKEN")
    token = auth.split(" ", 1)[1]
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=["HS256"])
        if payload.get("type") != "access":
            raise HTTPException(401, "INVALID_TOKEN_TYPE")
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "TOKEN_EXPIRED")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "INVALID_TOKEN")


@app.middleware("http")
async def inject_trace_id(request: Request, call_next):
    trace_id = request.headers.get("x-trace-id", str(uuid.uuid4()))
    request.state.trace_id = trace_id
    response = await call_next(request)
    response.headers["x-trace-id"] = trace_id
    return response


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled: {type(exc).__name__}: {exc} | path={request.url.path}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error",
                 "trace_id": getattr(request.state, "trace_id", "?")}
    )


# ── v3 routers ─────────────────────────────────────────────────
app.include_router(auth_router)
app.include_router(agents_router,    prefix="/api/v1")
app.include_router(patient_router,   prefix="/api/v1")
app.include_router(doctor_router,    prefix="/api/v1")
app.include_router(nurse_router,     prefix="/api/v1")
app.include_router(admin_router,     prefix="/api/v1")
app.include_router(emergency_router, prefix="/api/v1")

# ── v4 routers ─────────────────────────────────────────────────
app.include_router(orders_router,       prefix="/api/v1")
app.include_router(sla_router,          prefix="/api/v1")
app.include_router(legal_router,        prefix="/api/v1")
app.include_router(ehr_router,          prefix="/api/v1")
app.include_router(consent_router,      prefix="/api/v1")
app.include_router(override_router,     prefix="/api/v1")
app.include_router(billing_router,      prefix="/api/v1")
app.include_router(integrations_router, prefix="/api/v1")
app.include_router(analytics_router,    prefix="/api/v1")
app.include_router(privacy_router,      prefix="/api/v1")
app.include_router(offline_router,      prefix="/api/v1")


@app.get("/health", tags=["system"])
async def health():
    return {
        "status": "healthy",
        "service": "vitalos-ai-agents",
        "version": "4.0.0",
        "schema_version": settings.EVENT_SCHEMA_VERSION,
        "agents_online": 16,
        "roles": ["patient", "doctor", "nurse", "emergency_responder", "admin"],
        "v4_modules": [
            "cdss", "clinical_protocols", "clinical_specialties",
            "orders", "sla", "legal", "ehr", "consent", "override",
            "billing", "integrations_fhir_hl7", "analytics",
            "privacy_dpdp", "offline_queue",
        ],
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.get("/", tags=["system"])
async def root():
    return {
        "name": "VitalOS Clinical AI v4 — The Counsel",
        "tagline": "The Judge is TypeScript. The Counsel is Python. Clinical Truth is deterministic.",
        "version": "4.0.0",
        "docs": "/docs",
        "auth": {
            "patient_login":  "POST /auth/login/otp/send",
            "staff_login":    "POST /auth/login/password",
            "register_staff": "POST /auth/register/staff (admin only)",
        },
        "new_in_v4": {
            "clinical_protocols": "/api/v1/protocols/",
            "cdss":               "/api/v1/cdss/",
            "orders":             "/api/v1/orders/",
            "ehr_timeline":       "/api/v1/ehr/patient/{id}/timeline",
            "consent_dpdp":       "/api/v1/consent/",
            "legal_signatures":   "/api/v1/legal/sign",
            "sla_monitor":        "/api/v1/sla/breaches",
            "human_override":     "/api/v1/override/apply",
            "billing":            "/api/v1/billing/generate",
            "fhir_r4":            "/api/v1/integrations/fhir/patient/{id}",
            "analytics":          "/api/v1/analytics/escalation-rate",
            "privacy":            "/api/v1/privacy/compliance-report",
            "offline_mode":       "/api/v1/offline/status",
        },
    }
