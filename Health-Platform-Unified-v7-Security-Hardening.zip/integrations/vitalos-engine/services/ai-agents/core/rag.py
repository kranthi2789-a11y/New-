"""
core/rag.py — RAG pipeline: medical knowledge base → ChromaDB
"""

import os
import logging
from typing import List
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_core.documents import Document
from core.config import settings

logger = logging.getLogger("vitalos.rag")

_vectorstore: Chroma | None = None
_embeddings: HuggingFaceEmbeddings | None = None

SEED_KNOWLEDGE = [
    "Metformin 500mg/850mg/1000mg: Type 2 diabetes. Take with meals. Side effects: nausea, diarrhea. Contraindicated eGFR<30. Check HbA1c every 3 months.",
    "Amlodipine 5mg/10mg: Hypertension and angina. Once daily. Side effects: ankle swelling, flushing. Don't stop suddenly.",
    "Pantoprazole 40mg: GERD, ulcers. 30 min before breakfast. Long-term: monitor magnesium, B12. Available at Jan Aushadhi.",
    "Atorvastatin 10/20/40mg: High cholesterol. Take at night. Side effects: muscle pain. Avoid grapefruit. LFT every 6 months.",
    "Azithromycin 500mg: Z-pack 500mg day1, 250mg days 2-5. Empty stomach. Complete full course.",
    "Paracetamol 500mg: Max 4g/day adults. Reduce in liver disease. First-line for fever in India.",
    "Losartan 50mg: Hypertension. Once daily. Avoid pregnancy. Monitor potassium, creatinine.",
    "Glimepiride 1/2mg: Type 2 diabetes with first meal. Risk of hypoglycemia.",
    "Levothyroxine 25/50/100mcg: Hypothyroidism. Empty stomach 30-60min before food. Avoid calcium/iron within 4 hours.",
    "Omeprazole 20mg: PPI for acidity. Available OTC India. Take before meals.",
    "HbA1c: Normal <5.7%, Prediabetes 5.7-6.4%, Diabetes ≥6.5%. Target managed: <7%.",
    "Fasting glucose: Normal 70-99 mg/dL. Prediabetes 100-125. Diabetes ≥126 on two occasions.",
    "Lipid panel: Total cholesterol <200 desirable. LDL <100 optimal. HDL >60 protective.",
    "CBC: Hemoglobin Men 13.5-17.5 g/dL, Women 12.0-15.5. WBC 4.5-11.0. Platelets 150-400k. Low Hb = anemia common in Indian women.",
    "Thyroid: TSH 0.4-4.0 mIU/L. Free T4 0.8-1.8 ng/dL. High TSH+low T4=hypothyroid. Low TSH+high T4=hyperthyroid.",
    "Kidney: Creatinine Men 0.7-1.2, Women 0.5-1.0 mg/dL. eGFR >60 normal. BUN 10-20.",
    "Liver: ALT 7-40 U/L. AST 10-40. Bilirubin <1.2 mg/dL. Elevated = fatty liver/hepatitis.",
    "Uric acid: Men 3.4-7.0, Women 2.4-6.0 mg/dL. Elevated causes gout. Reduce purines. Treat with allopurinol.",
    "PM-JAY: ₹5L per family per year. 1393+ procedures. BPL families. Cashless at empaneled hospitals. pmjay.gov.in",
    "CGHS: Central government employees. Cashless at empaneled hospitals. Fixed CGHS rates.",
    "ESI: Organized sector <₹21,000/month. Free treatment. Family coverage. Sickness+maternity+disability.",
    "Pre-authorization: Planned surgeries, ICU, transplants. Submit to TPA. Approved 24-48hrs. Emergency: notify TPA within 24hrs.",
    "Heart attack: Chest pain/pressure, left arm/jaw pain, sweating. Call 108. Chew aspirin 325mg. Don't drive.",
    "Stroke FAST: Face drooping, Arm weakness, Speech difficulty, Time to call 108. Note symptom onset time.",
    "Hypoglycemia: Shaking, sweating, confusion. Give 15g fast carbs: juice/glucose. Recheck 15min. Unconscious→108.",
    "Anaphylaxis: Hives, throat swelling, breathing difficulty. Epinephrine if available. Call 108. Lay flat legs elevated.",
    "Diabetes management: Daily glucose monitoring. HbA1c 3-monthly. Annual eye exam. Foot exam every visit. BP target <130/80.",
    "Hypertension: Home BP twice daily. Salt <5g/day. Exercise 150min/week. Medication adherence critical.",
    "Asthma: Avoid triggers. Preventer inhaler daily even when well. Reliever for acute. Annual flu vaccine.",
    "PMBJP Jan Aushadhi: Generic medicines 50-90% cheaper. 9000+ stores. Same efficacy. Ask doctor for generics.",
    "ABHA ID: 14-digit health ID. Links all records. Register healthid.ndhm.gov.in or Aarogya Setu.",
    "e-Sanjeevani: Free government telemedicine 24/7. Video consults. esanjeevani.mohfw.gov.in",
    "108 Ambulance: Free across most Indian states. GPS-tracked. Average 15-20min cities. 24/7.",
    "COPD: Bronchodilators LABA/LAMA. Quit smoking most important. Flu+pneumococcal vaccines. Monitor SpO2.",
    "Pre-diabetes: Lifestyle intervention reduces progression 58%. 150min/week moderate exercise. 7% weight loss target.",
]


async def init_rag():
    global _vectorstore, _embeddings
    logger.info("🧠 Initializing VitalOS RAG medical knowledge base...")

    _embeddings = HuggingFaceEmbeddings(
        model_name=settings.EMBEDDING_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )

    kb_docs: List[Document] = []
    kb_dir = settings.KNOWLEDGE_BASE_DIR
    if os.path.exists(kb_dir):
        for fname in os.listdir(kb_dir):
            if fname.endswith(".txt"):
                with open(os.path.join(kb_dir, fname), encoding="utf-8") as f:
                    kb_docs.append(Document(page_content=f.read(), metadata={"source": fname}))
        if kb_docs:
            logger.info(f"📚 Loaded {len(kb_docs)} documents from knowledge_base/")

    seed_docs = [Document(page_content=t, metadata={"source": "seed"}) for t in SEED_KNOWLEDGE]
    all_docs = seed_docs + kb_docs

    _vectorstore = Chroma.from_documents(
        all_docs, _embeddings, persist_directory=settings.CHROMA_PERSIST_DIR,
    )
    logger.info(f"✅ RAG ready — {len(all_docs)} knowledge chunks indexed")


def get_vectorstore() -> Chroma:
    if _vectorstore is None:
        raise RuntimeError("RAG not initialized. Call init_rag() first.")
    return _vectorstore


def retrieve_medical_context(query: str, k: int = 4) -> str:
    vs = get_vectorstore()
    docs = vs.similarity_search(query, k=k)
    if not docs:
        return "No relevant medical context found."
    return "\n\n---\n\n".join([
        f"[{doc.metadata.get('source', 'knowledge')}]\n{doc.page_content}"
        for doc in docs
    ])
