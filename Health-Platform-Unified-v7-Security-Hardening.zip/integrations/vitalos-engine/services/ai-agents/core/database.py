"""
core/database.py — Async SQLAlchemy ORM for VitalOS AI Agents data plane
Note: The TS Clinical Engine owns the control plane (case_state_machine, audit trail).
      This layer owns the data plane (patients, prescriptions, lab reports, agent logs).
"""

import logging
from datetime import datetime
from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String, Text, DateTime, JSON, Integer, Float, Boolean, Index

from core.config import settings

logger = logging.getLogger("vitalos.db")

engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,
    future=True,
    pool_pre_ping=True,
)

AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


class Base(DeclarativeBase):
    pass


# ── ORM Models — Data Plane (Python owns these) ───────────────

class Patient(Base):
    __tablename__ = "patients"

    id: Mapped[int]         = mapped_column(Integer, primary_key=True)
    name: Mapped[str]       = mapped_column(String(100))
    mobile: Mapped[str]     = mapped_column(String(15), unique=True, index=True)
    age: Mapped[int]        = mapped_column(Integer, default=0)
    gender: Mapped[str]     = mapped_column(String(10), default="unknown")
    blood_group: Mapped[str] = mapped_column(String(5), default="")
    abha_id: Mapped[str]    = mapped_column(String(50), default="", index=True)
    conditions: Mapped[list] = mapped_column(JSON, default=list)
    allergies: Mapped[list]  = mapped_column(JSON, default=list)
    medications: Mapped[list] = mapped_column(JSON, default=list)
    schema_version: Mapped[str] = mapped_column(String(10), default="1.0.0")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Prescription(Base):
    __tablename__ = "prescriptions"

    id: Mapped[int]              = mapped_column(Integer, primary_key=True)
    patient_mobile: Mapped[str]  = mapped_column(String(15), index=True)
    doctor_name: Mapped[str]     = mapped_column(String(100), default="")
    clinic_name: Mapped[str]     = mapped_column(String(100), default="")
    raw_text: Mapped[str]        = mapped_column(Text, default="")
    medications: Mapped[list]    = mapped_column(JSON, default=list)
    interaction_warnings: Mapped[list] = mapped_column(JSON, default=list)
    diagnosis: Mapped[str]       = mapped_column(String(200), default="")
    follow_up_days: Mapped[int]  = mapped_column(Integer, default=0)
    trace_id: Mapped[str]        = mapped_column(String(100), default="")
    schema_version: Mapped[str]  = mapped_column(String(10), default="1.0.0")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class MedicationReminder(Base):
    __tablename__ = "reminders"

    id: Mapped[int]              = mapped_column(Integer, primary_key=True)
    patient_mobile: Mapped[str]  = mapped_column(String(15), index=True)
    drug_name: Mapped[str]       = mapped_column(String(100))
    dosage: Mapped[str]          = mapped_column(String(50), default="")
    frequency: Mapped[str]       = mapped_column(String(50), default="")
    schedule_times: Mapped[list] = mapped_column(JSON, default=list)
    active: Mapped[bool]         = mapped_column(Boolean, default=True)
    streak_days: Mapped[int]     = mapped_column(Integer, default=0)
    critical: Mapped[bool]       = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class LabReport(Base):
    __tablename__ = "lab_reports"

    id: Mapped[int]               = mapped_column(Integer, primary_key=True)
    patient_mobile: Mapped[str]   = mapped_column(String(15), index=True)
    report_type: Mapped[str]      = mapped_column(String(100), default="")
    raw_text: Mapped[str]         = mapped_column(Text, default="")
    extracted_values: Mapped[dict] = mapped_column(JSON, default=dict)
    flags: Mapped[list]           = mapped_column(JSON, default=list)
    follow_up_urgency: Mapped[str] = mapped_column(String(20), default="routine")
    ai_explanation: Mapped[str]   = mapped_column(Text, default="")
    trace_id: Mapped[str]         = mapped_column(String(100), default="")
    schema_version: Mapped[str]   = mapped_column(String(10), default="1.0.0")
    created_at: Mapped[datetime]  = mapped_column(DateTime, default=datetime.utcnow)


class AgentLog(Base):
    """Observability log — every AI inference recorded with trace_id for full traceability."""
    __tablename__ = "agent_logs"
    __table_args__ = (
        Index("ix_agent_logs_trace", "trace_id"),
        Index("ix_agent_logs_agent_created", "agent_name", "created_at"),
    )

    id: Mapped[int]           = mapped_column(Integer, primary_key=True)
    agent_name: Mapped[str]   = mapped_column(String(50), index=True)
    session_id: Mapped[str]   = mapped_column(String(100), index=True)
    trace_id: Mapped[str]     = mapped_column(String(100), default="")
    input_hash: Mapped[str]   = mapped_column(String(64), default="")  # SHA-256 of input — not raw PII
    output_text: Mapped[str]  = mapped_column(Text, default="")
    tokens_used: Mapped[int]  = mapped_column(Integer, default=0)
    latency_ms: Mapped[float] = mapped_column(Float, default=0.0)
    success: Mapped[bool]     = mapped_column(Boolean, default=True)
    agent_version: Mapped[str] = mapped_column(String(10), default="1.0.0")
    schema_version: Mapped[str] = mapped_column(String(10), default="1.0.0")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def init_db():
    """Create all data-plane tables on startup."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("✅ VitalOS data-plane database initialized")
