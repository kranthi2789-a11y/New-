"""
core/kafka_helper.py — Kafka publish helper for Python services

A thin async wrapper around the existing Python event publishing
that new modules (orders, sla, override, offline) use.

This does NOT duplicate or modify the TypeScript Kafka config.
This is the Python-side publisher for Python-originated events only.
"""

import os
import json
import logging
from datetime import datetime
from typing import Any, Dict, Optional

logger = logging.getLogger("vitalos.kafka_helper")

_producer = None


async def get_producer():
    """Lazy-init aiokafka producer (optional dep — graceful fallback)."""
    global _producer
    if _producer:
        return _producer
    try:
        from aiokafka import AIOKafkaProducer
        brokers = os.getenv("KAFKA_BROKERS", "localhost:9092")
        _producer = AIOKafkaProducer(
            bootstrap_servers=brokers,
            value_serializer=lambda v: json.dumps(v, default=str).encode(),
            key_serializer=lambda k: k.encode() if k else None,
            enable_idempotence=True,
            acks="all",
            max_in_flight_requests_per_connection=1,
        )
        await _producer.start()
        logger.info("aiokafka producer started")
        return _producer
    except ImportError:
        logger.warning("aiokafka not installed — Kafka publish from Python disabled")
        return None
    except Exception as e:
        logger.error(f"Kafka producer start failed: {e}")
        return None


async def publish_to_kafka(
    topic: str,
    key: str,
    value: Dict[str, Any],
    headers: Optional[Dict] = None,
) -> bool:
    """
    Publish a message to Kafka.
    Returns True on success, False on failure (caller handles fallback).
    """
    producer = await get_producer()
    if not producer:
        logger.warning(f"Kafka unavailable — message not published: topic={topic} key={key[:16]}")
        return False

    try:
        await producer.send_and_wait(topic, key=key, value=value)
        return True
    except Exception as e:
        logger.error(f"Kafka publish error: topic={topic} error={e}")
        return False


async def publish_governance_event(mode: str, reason: str = "") -> bool:
    """Publish Safe Mode governance trigger (used by admin/router.py)."""
    return await publish_to_kafka(
        "vitalos.governance.trigger",
        "python-admin",
        {
            "action": f"ENABLE_{mode}" if mode != "NORMAL" else "DISABLE_SAFE_MODE",
            "reason": reason,
            "timestamp": int(datetime.utcnow().timestamp() * 1000),
            "schema_version": "1.0.0",
            "origin": "python-admin-service",
        }
    )


async def publish_sos_event(patient_name: str, patient_mobile: str, location: str) -> bool:
    """Publish SOS emergency event (used by services/sos.py)."""
    return await publish_to_kafka(
        "vitalos.emergency.dispatch",
        patient_mobile,
        {
            "action": "SOS_TRIGGERED",
            "patient_name": patient_name,
            "location": location,
            "ambulance_number": "108",
            "timestamp": int(datetime.utcnow().timestamp() * 1000),
        }
    )


async def shutdown_producer():
    """Call on app shutdown."""
    global _producer
    if _producer:
        try:
            await _producer.stop()
        except Exception:
            pass
        _producer = None
