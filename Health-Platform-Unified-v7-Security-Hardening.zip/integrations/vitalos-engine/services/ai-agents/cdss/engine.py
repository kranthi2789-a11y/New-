"""
cdss/engine.py — Clinical Decision Support System

Runs BEFORE orchestrator commits any prescription-bearing transition.
Three safety layers:
  1. Drug-drug interactions
  2. Contraindications (disease-drug)
  3. Duplicate/redundant therapy detection

Returns blocking errors (REJECT) or warnings (WARN) with explanations.
The TypeScript orchestrator reads the CDSS result from the agent payload
and can block the transition if severity == "REJECT".
"""

from __future__ import annotations
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple

logger = logging.getLogger("vitalos.cdss")


@dataclass
class CDSSAlert:
    severity: str          # "REJECT" | "WARN" | "INFO"
    category: str          # "INTERACTION" | "CONTRAINDICATION" | "DUPLICATE"
    drug_a: str
    drug_b: Optional[str]  # None for contraindications
    message: str
    recommendation: str
    evidence_level: str    # "A" | "B" | "C"


@dataclass
class CDSSResult:
    safe_to_proceed: bool
    alerts: List[CDSSAlert] = field(default_factory=list)
    block_reason: Optional[str] = None


# ══════════════════════════════════════════════════
#  DRUG-DRUG INTERACTION DATABASE (India-relevant)
# ══════════════════════════════════════════════════
# Format: (drug_a_pattern, drug_b_pattern, severity, message, recommendation, evidence)
DRUG_INTERACTIONS: List[Tuple] = [
    # Cardiovascular
    ("warfarin",    "aspirin",      "REJECT", "Major bleeding risk: warfarin + aspirin",
     "Avoid combination; if essential, use with PPI + INR monitoring", "A"),
    ("warfarin",    "nsaid",        "REJECT", "Major bleeding risk: warfarin + NSAID",
     "Contraindicated. Use paracetamol for analgesia", "A"),
    ("metformin",   "contrast",     "WARN",   "Lactic acidosis risk: metformin + iodine contrast",
     "Hold metformin 48hr before and after contrast", "B"),
    ("ace inhibitor","arb",         "WARN",   "Dual renin-angiotensin blockade: ACEi + ARB",
     "Avoid combination — hyperkalaemia + AKI risk", "A"),
    ("digoxin",     "amiodarone",   "REJECT", "Digoxin toxicity: amiodarone increases digoxin levels 2x",
     "Reduce digoxin dose by 50%; monitor levels", "A"),
    ("statins",     "clarithromycin","WARN",  "Myopathy risk: statin + clarithromycin (CYP3A4)",
     "Temporarily hold statin during clarithromycin course", "B"),
    # Diabetes
    ("sulphonylurea","fluconazole",  "WARN",  "Hypoglycaemia risk: sulphonylurea + fluconazole",
     "Monitor blood glucose closely", "B"),
    ("insulin",     "beta blocker", "WARN",   "Hypoglycaemia masking: insulin + beta-blocker",
     "Use cardioselective beta-blocker; educate on non-adrenergic hypoglycaemia signs", "B"),
    # Antibiotics
    ("metronidazole","alcohol",     "REJECT", "Disulfiram reaction: metronidazole + alcohol",
     "Strict alcohol avoidance during and 48hr after metronidazole", "A"),
    ("fluoroquinolone","antacid",   "WARN",   "Absorption reduced: fluoroquinolone + antacid",
     "Separate by 2 hours", "B"),
    # Psychiatry
    ("ssri",        "tramadol",     "REJECT", "Serotonin syndrome risk: SSRI + tramadol",
     "Contraindicated. Use alternative analgesia", "A"),
    ("maoi",        "ssri",         "REJECT", "Fatal serotonin syndrome: MAOI + SSRI",
     "Never combine. Washout 14 days after MAOI, 5 weeks after fluoxetine", "A"),
    # Pain
    ("opioid",      "benzodiazepine","WARN",  "Respiratory depression: opioid + benzodiazepine",
     "Use lowest effective doses; have naloxone available", "A"),
]

# ══════════════════════════════════════════════════
#  CONTRAINDICATIONS (disease-drug)
# ══════════════════════════════════════════════════
# Format: (condition_pattern, drug_pattern, severity, message, recommendation, evidence)
CONTRAINDICATIONS: List[Tuple] = [
    ("renal failure",    "nsaid",         "REJECT", "NSAID contraindicated in CKD/AKI",
     "Use paracetamol. Avoid NSAIDs — nephrotoxic", "A"),
    ("liver failure",    "paracetamol",   "WARN",   "Hepatotoxicity risk in liver disease",
     "Max 2g/day in mild hepatic impairment; avoid in severe", "A"),
    ("liver failure",    "metformin",     "REJECT", "Lactic acidosis risk in hepatic failure",
     "Contraindicated. Use insulin for diabetes management", "A"),
    ("heart failure",    "nsaid",         "REJECT", "NSAID worsens heart failure: fluid retention",
     "Absolutely contraindicated. Use paracetamol", "A"),
    ("heart failure",    "thiazolidinedione","REJECT","Fluid retention worsens heart failure",
     "Pioglitazone/rosiglitazone contraindicated in heart failure", "A"),
    ("asthma",           "aspirin",       "WARN",   "Aspirin-exacerbated respiratory disease",
     "Check aspirin sensitivity. Use paracetamol if uncertain", "B"),
    ("asthma",           "beta blocker",  "REJECT", "Beta-blocker contraindicated in asthma",
     "Use cardioselective (bisoprolol) only with extreme caution", "A"),
    ("pregnancy",        "warfarin",      "REJECT", "Warfarin teratogenic (warfarin embryopathy)",
     "Use LMWH throughout pregnancy", "A"),
    ("pregnancy",        "ace inhibitor", "REJECT", "ACE inhibitor: foetal renal toxicity",
     "Switch to labetalol or methyldopa in pregnancy", "A"),
    ("pregnancy",        "statin",        "REJECT", "Statins: foetal harm, teratogenic",
     "Discontinue statins in pregnancy", "A"),
    ("hyperkalaemia",    "ace inhibitor", "WARN",   "ACE inhibitor increases K+ — worsens hyperkalaemia",
     "Monitor K+ closely; consider dose reduction or alternative", "B"),
    ("bleeding disorder","anticoagulant", "WARN",   "Anticoagulant: major bleeding risk in coagulopathy",
     "Haematology input required before prescribing", "B"),
]


class CDSSEngine:
    """
    Main CDSS evaluation engine.
    Called from prescription scan, doctor prescribe, and orchestrator hook.
    """

    @classmethod
    def evaluate(
        cls,
        medications: List[Dict],
        conditions: List[str] = None,
        pregnancy_weeks: int = 0,
        renal_function: Optional[str] = None,
        liver_function: Optional[str] = None,
    ) -> CDSSResult:
        """
        Full CDSS evaluation.
        medications: [{"drug_name": str, "drug_class": str, ...}]
        conditions: ["diabetes", "heart failure", ...]
        """
        conditions = [c.lower() for c in (conditions or [])]
        if pregnancy_weeks and pregnancy_weeks > 0:
            conditions.append("pregnancy")
        if renal_function in ("CKD", "AKI", "ESRD"):
            conditions.append("renal failure")
        if liver_function in ("cirrhosis", "liver failure"):
            conditions.append("liver failure")

        alerts: List[CDSSAlert] = []

        # 1. Drug-drug interactions
        drug_names = [
            (m.get("drug_name") or "").lower()
            for m in medications
        ]
        drug_classes = [
            (m.get("drug_class") or "").lower()
            for m in medications
        ]
        all_drug_terms = drug_names + drug_classes

        for i, term_a in enumerate(all_drug_terms):
            for j, term_b in enumerate(all_drug_terms):
                if i >= j:
                    continue
                for da, db, sev, msg, rec, ev in DRUG_INTERACTIONS:
                    if da in term_a and db in term_b:
                        alerts.append(CDSSAlert(
                            severity=sev, category="INTERACTION",
                            drug_a=term_a, drug_b=term_b,
                            message=msg, recommendation=rec, evidence_level=ev,
                        ))

        # 2. Contraindications
        for condition in conditions:
            for drug_term in all_drug_terms:
                for cond_pat, drug_pat, sev, msg, rec, ev in CONTRAINDICATIONS:
                    if cond_pat in condition and drug_pat in drug_term:
                        alerts.append(CDSSAlert(
                            severity=sev, category="CONTRAINDICATION",
                            drug_a=drug_term, drug_b=None,
                            message=f"{msg} (condition: {condition})",
                            recommendation=rec, evidence_level=ev,
                        ))

        # 3. Duplicate therapy detection
        duplicates = cls._check_duplicates(medications)
        alerts.extend(duplicates)

        rejections = [a for a in alerts if a.severity == "REJECT"]
        safe = len(rejections) == 0

        if not safe:
            logger.warning(
                f"CDSS REJECT: {len(rejections)} blocking alerts — "
                f"{[a.message[:40] for a in rejections]}"
            )

        return CDSSResult(
            safe_to_proceed=safe,
            alerts=alerts,
            block_reason=rejections[0].message if rejections else None,
        )

    @classmethod
    def _check_duplicates(cls, medications: List[Dict]) -> List[CDSSAlert]:
        """Detect same drug class prescribed twice."""
        alerts = []
        seen_classes: Dict[str, str] = {}
        for med in medications:
            drug_class = (med.get("drug_class") or "").lower()
            drug_name = med.get("drug_name") or ""
            if drug_class and drug_class in seen_classes:
                alerts.append(CDSSAlert(
                    severity="WARN",
                    category="DUPLICATE",
                    drug_a=drug_name,
                    drug_b=seen_classes[drug_class],
                    message=f"Duplicate therapy: two drugs from class '{drug_class}'",
                    recommendation="Review — likely only one needed",
                    evidence_level="B",
                ))
            elif drug_class:
                seen_classes[drug_class] = drug_name
        return alerts

    @classmethod
    def to_audit_payload(cls, result: CDSSResult) -> Dict:
        return {
            "cdss_safe": result.safe_to_proceed,
            "cdss_block_reason": result.block_reason,
            "cdss_alerts": [
                {
                    "severity": a.severity,
                    "category": a.category,
                    "drug_a": a.drug_a,
                    "drug_b": a.drug_b,
                    "message": a.message[:80],
                    "evidence": a.evidence_level,
                }
                for a in result.alerts
            ],
        }
