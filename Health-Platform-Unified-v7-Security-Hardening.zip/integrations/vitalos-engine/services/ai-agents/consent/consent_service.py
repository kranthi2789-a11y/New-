"""
consent/consent_service.py — Patient Consent Management (India DPDP 2023)

Tracks:
  - Purpose-based consent (treatment, research, sharing)
  - Data sharing authorisations
  - Consent revocation
  - Access audit log per consent

Every consent action is timestamped and audit-logged.
"""

from __future__ import annotations
import logging
import uuid
from datetime import datetime
from typing import Optional, List, Dict

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from main import verify_token

logger = logging.getLogger("vitalos.consent")
consent_router = APIRouter(prefix="/consent", tags=["consent"])

CONSENT_PURPOSES = [
    "treatment",              # Core clinical care
    "billing",                # Insurance / payment processing
    "research_anonymised",    # De-identified research
    "data_sharing_doctor",    # Share with treating doctor
    "data_sharing_specialist",# Share with referred specialist
    "whatsapp_reminders",     # Twilio WhatsApp notifications
    "family_access",          # Family health dashboard
    "analytics",              # Hospital analytics (aggregated)
]


class ConsentGrant(BaseModel):
    purposes: List[str]
    valid_until: Optional[str] = None   # ISO date, None = indefinite
    notes: Optional[str] = None


class ConsentRevoke(BaseModel):
    purposes: List[str]
    reason: Optional[str] = None


# ── Grant consent ─────────────────────────────────────────────

@consent_router.post("/grant", summary="Patient grants consent for specific purposes")
async def grant_consent(
    req: ConsentGrant,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    invalid = [p for p in req.purposes if p not in CONSENT_PURPOSES]
    if invalid:
        raise HTTPException(400, f"Invalid purposes: {invalid}. Valid: {CONSENT_PURPOSES}")

    granted = []
    for purpose in req.purposes:
        consent_id = str(uuid.uuid4())
        await db.execute(text("""
            INSERT INTO patient_consents
            (id, patient_id, purpose, granted, valid_until, notes, created_at)
            VALUES (:id, :pid, :purpose, TRUE, :vu, :notes, NOW())
            ON CONFLICT (patient_id, purpose)
            DO UPDATE SET granted=TRUE, valid_until=:vu, updated_at=NOW()
        """), {
            "id": consent_id, "pid": me["sub"],
            "purpose": purpose, "vu": req.valid_until, "notes": req.notes,
        })
        granted.append(purpose)

    await db.commit()
    logger.info(f"Consent granted: patient={me['sub']} purposes={granted}")
    return {
        "granted": granted,
        "patient_id": me["sub"],
        "granted_at": datetime.utcnow().isoformat(),
        "dpdp_notice": "Consent recorded per DPDP Act 2023 (India). You may revoke at any time.",
    }


# ── Revoke consent ────────────────────────────────────────────

@consent_router.post("/revoke", summary="Patient revokes consent")
async def revoke_consent(
    req: ConsentRevoke,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    for purpose in req.purposes:
        await db.execute(text("""
            UPDATE patient_consents
            SET granted=FALSE, revoked_at=NOW(), revoke_reason=:reason, updated_at=NOW()
            WHERE patient_id=:pid AND purpose=:purpose
        """), {"pid": me["sub"], "purpose": purpose, "reason": req.reason})
    await db.commit()
    logger.info(f"Consent revoked: patient={me['sub']} purposes={req.purposes}")
    return {
        "revoked": req.purposes,
        "revoked_at": datetime.utcnow().isoformat(),
        "message": "Consent revoked. Data processing for these purposes will cease within 24 hours.",
    }


# ── Get my consents ───────────────────────────────────────────

@consent_router.get("/my", summary="Get patient's current consents")
async def my_consents(me=Depends(verify_token), db: AsyncSession = Depends(get_db)):
    result = await db.execute(text("""
        SELECT purpose, granted, valid_until, created_at, revoked_at
        FROM patient_consents WHERE patient_id=:pid
    """), {"pid": me["sub"]})
    rows = result.fetchall()
    return {
        "consents": [dict(r._mapping) for r in rows],
        "available_purposes": CONSENT_PURPOSES,
        "dpdp_rights": [
            "Right to access your data",
            "Right to correct inaccurate data",
            "Right to erasure (subject to legal retention requirements)",
            "Right to withdraw consent at any time",
            "Right to grievance redressal",
        ],
    }


# ── Check if consent exists (used internally) ─────────────────

async def has_consent(patient_id: str, purpose: str, db: AsyncSession) -> bool:
    result = await db.execute(text("""
        SELECT granted FROM patient_consents
        WHERE patient_id=:pid AND purpose=:purpose
          AND granted=TRUE
          AND (valid_until IS NULL OR valid_until > NOW())
        LIMIT 1
    """), {"pid": patient_id, "purpose": purpose})
    row = result.fetchone()
    return bool(row and row.granted)


# ── Admin: view consents for patient ─────────────────────────

@consent_router.get("/admin/{patient_id}", summary="Admin views patient consents")
async def admin_view_consents(
    patient_id: str,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if me["role"] != "admin":
        raise HTTPException(403, "Admin only")
    result = await db.execute(text(
        "SELECT * FROM patient_consents WHERE patient_id=:pid ORDER BY created_at DESC"
    ), {"pid": patient_id})
    rows = result.fetchall()
    return {"consents": [dict(r._mapping) for r in rows]}
