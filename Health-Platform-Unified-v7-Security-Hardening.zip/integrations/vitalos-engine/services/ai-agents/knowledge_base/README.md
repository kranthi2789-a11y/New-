# VitalOS Medical Knowledge Base

Drop `.txt` files here to augment the ChromaDB RAG pipeline.

## Format

One medical fact or guideline per file, or a collection per file.
Files are auto-loaded at startup via `core/rag.py`.

## Examples

- `drugs_india.txt`         — drug dosages, interactions, generics
- `lab_ranges.txt`          — reference ranges for Indian population
- `insurance_pmjay.txt`     — PM-JAY procedure list and coverage limits
- `emergency_protocols.txt` — 108 dispatch, FAST stroke, ACS protocol
- `chronic_disease.txt`     — diabetes, HTN, thyroid management India

## Seed Knowledge

35 seed chunks are already embedded at startup even if this directory is empty.
See `core/rag.py` → `SEED_KNOWLEDGE` for the full list.
