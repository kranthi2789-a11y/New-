"""
offline/offline_queue.py — Offline / Resilience Mode

In-memory fallback queue when Kafka is unavailable.
Marks events as "delayed" in DB.
Retries sync when Kafka comes back.

Architecture:
  Normal mode:  event → Kafka → Orchestrator
  Offline mode: event → local_queue (memory) → retry when Kafka OK → Kafka → Orchestrator

The DB is ALWAYS written (even in offline mode).
Kafka is the delivery mechanism — not the source of truth.
"""

from __future__ import annotations
import asyncio
import logging
from collections import deque
from datetime import datetime
from typing import Optional, Dict, Any, Deque
from dataclasses import dataclass, field

logger = logging.getLogger("vitalos.offline")

MAX_QUEUE_SIZE = 1000
RETRY_INTERVAL_SECONDS = 30


@dataclass
class QueuedEvent:
    topic: str
    key: str
    value: Dict[str, Any]
    queued_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    retry_count: int = 0
    max_retries: int = 5


class OfflineQueue:
    """
    Thread-safe in-memory event queue for Kafka outage resilience.
    Singleton — one queue per process.
    """
    _instance: Optional["OfflineQueue"] = None
    _queue: Deque[QueuedEvent] = deque(maxlen=MAX_QUEUE_SIZE)
    _kafka_available: bool = True
    _retry_task: Optional[asyncio.Task] = None

    @classmethod
    def get(cls) -> "OfflineQueue":
        if not cls._instance:
            cls._instance = cls()
        return cls._instance

    def enqueue(self, topic: str, key: str, value: Dict) -> None:
        event = QueuedEvent(topic=topic, key=key, value=value)
        self._queue.appendleft(event)
        logger.warning(
            f"Event queued offline: topic={topic} key={key[:16]} "
            f"queue_size={len(self._queue)}"
        )

    def mark_kafka_down(self) -> None:
        if self._kafka_available:
            logger.error("Kafka UNAVAILABLE — switching to offline queue mode")
            self._kafka_available = False

    def mark_kafka_up(self) -> None:
        if not self._kafka_available:
            logger.info("Kafka AVAILABLE — resuming normal mode")
            self._kafka_available = True

    @property
    def is_kafka_available(self) -> bool:
        return self._kafka_available

    @property
    def queue_size(self) -> int:
        return len(self._queue)

    async def drain_to_kafka(self) -> int:
        """Attempt to flush queued events to Kafka. Returns count flushed."""
        from core.kafka_helper import publish_to_kafka

        flushed = 0
        failed_events = []

        while self._queue:
            event = self._queue.pop()
            try:
                await publish_to_kafka(event.topic, event.key, event.value)
                flushed += 1
                logger.info(f"Offline event flushed: topic={event.topic} key={event.key[:16]}")
            except Exception as e:
                event.retry_count += 1
                if event.retry_count < event.max_retries:
                    failed_events.append(event)
                else:
                    logger.error(
                        f"Event dropped after {event.max_retries} retries: "
                        f"topic={event.topic} key={event.key[:16]}"
                    )

        # Re-queue failed events
        for ev in failed_events:
            self._queue.appendleft(ev)

        if flushed:
            logger.info(f"Drained {flushed} offline events to Kafka")
        return flushed

    async def start_retry_loop(self) -> None:
        """Background task to periodically retry Kafka when offline."""
        while True:
            await asyncio.sleep(RETRY_INTERVAL_SECONDS)
            if self._queue and not self._kafka_available:
                # Try a test publish
                try:
                    from core.kafka_helper import publish_to_kafka
                    await publish_to_kafka("vitalos.health.ping", "offline-queue", {
                        "type": "CONNECTIVITY_CHECK",
                        "timestamp": datetime.utcnow().isoformat(),
                        "queued_events": len(self._queue),
                    })
                    self.mark_kafka_up()
                    await self.drain_to_kafka()
                except Exception:
                    logger.debug("Kafka still unavailable — retry next cycle")

    def status(self) -> Dict:
        return {
            "kafka_available": self._kafka_available,
            "queued_events": len(self._queue),
            "mode": "ONLINE" if self._kafka_available else "OFFLINE_QUEUE",
            "oldest_event": self._queue[-1].queued_at if self._queue else None,
        }


# ── Resilient publish helper (use this everywhere instead of raw Kafka) ──

async def resilient_publish(topic: str, key: str, value: Dict) -> bool:
    """
    Publish to Kafka with offline fallback.
    Returns True if published to Kafka, False if queued locally.
    """
    queue = OfflineQueue.get()
    if not queue.is_kafka_available:
        queue.enqueue(topic, key, value)
        return False

    try:
        from core.kafka_helper import publish_to_kafka
        await publish_to_kafka(topic, key, value)
        return True
    except Exception as e:
        logger.error(f"Kafka publish failed: {e} — queuing offline")
        queue.mark_kafka_down()
        queue.enqueue(topic, key, value)
        return False


# ── Router ────────────────────────────────────────────────────
from fastapi import APIRouter, Depends
from main import verify_token
from fastapi import HTTPException

offline_router = APIRouter(prefix="/offline", tags=["offline"])


@offline_router.get("/status", summary="Offline queue status")
async def offline_status(me=Depends(verify_token)):
    if me["role"] != "admin":
        raise HTTPException(403, "Admin only")
    return OfflineQueue.get().status()


@offline_router.post("/flush", summary="Force flush offline queue to Kafka")
async def flush_queue(me=Depends(verify_token)):
    if me["role"] != "admin":
        raise HTTPException(403, "Admin only")
    queue = OfflineQueue.get()
    queue.mark_kafka_up()
    flushed = await queue.drain_to_kafka()
    return {"flushed": flushed, "remaining": queue.queue_size}
