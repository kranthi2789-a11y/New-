# VitalOS roles/emergency package
