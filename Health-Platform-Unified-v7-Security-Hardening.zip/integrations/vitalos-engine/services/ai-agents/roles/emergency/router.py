"""
roles/emergency/router.py — Emergency responder endpoints

Features:
  - Live active emergency cases list
  - Claim a case (responder assigns self)
  - Paramedic intake form (vitals on arrival)
  - Update case status (en-route, on-scene, hospital)
  - 108 dispatch confirmation
"""

from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Body
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from main import verify_token
import logging

logger = logging.getLogger("vitalos.emergency")
router = APIRouter(prefix="/emergency", tags=["emergency"])


def responder_only(token=Depends(verify_token)):
    if token["role"] not in ("emergency_responder", "admin", "doctor"):
        raise HTTPException(403, "Emergency responder access only")
    return token


# ══════════════════════════════════════════
#  ACTIVE EMERGENCY CASES
# ══════════════════════════════════════════

@router.get("/cases", summary="All active emergency cases")
async def active_emergency_cases(
    me=Depends(responder_only),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(text("""
        SELECT c.case_id, c.current_state, c.risk_level, c.priority_score,
               c.updated_at, c.is_locked,
               p.name as patient_name, p.mobile as patient_mobile,
               p.conditions, p.blood_group
        FROM case_state_machine c
        LEFT JOIN patients p ON p.mobile = (
            SELECT u.mobile FROM users u WHERE u.id::text = c.case_id LIMIT 1
        )
        WHERE c.risk_level = 'EMERGENCY'
          AND c.current_state NOT IN ('CLOSED')
        ORDER BY c.priority_score DESC, c.updated_at ASC
    """))
    rows = result.fetchall()
    return {
        "emergency_cases": [dict(r._mapping) for r in rows],
        "total": len(rows),
        "ambulance_number": "108",
    }


# ══════════════════════════════════════════
#  CLAIM A CASE
# ══════════════════════════════════════════

@router.post("/cases/{case_id}/claim", summary="Responder claims emergency case")
async def claim_case(
    case_id: str,
    me=Depends(responder_only),
    db: AsyncSession = Depends(get_db),
):
    # Mark case as claimed (lock it to this responder)
    result = await db.execute(text("""
        UPDATE case_state_machine
        SET is_locked = TRUE, updated_at = NOW()
        WHERE case_id = :cid AND risk_level = 'EMERGENCY' AND is_locked = FALSE
        RETURNING case_id
    """), {"cid": case_id})
    row = result.fetchone()
    if not row:
        raise HTTPException(409, "Case not available or already claimed")
    await db.commit()
    logger.warning(f"Emergency case {case_id} claimed by responder {me['sub']}")
    return {
        "message": "Case claimed",
        "case_id": case_id,
        "responder": me["name"],
        "ambulance_number": "108",
        "claimed_at": datetime.utcnow().isoformat(),
    }


# ══════════════════════════════════════════
#  PARAMEDIC INTAKE FORM
# ══════════════════════════════════════════

class IntakeForm(BaseModel):
    case_id: str
    patient_name: str
    patient_age: Optional[int] = None
    chief_complaint: str
    systolic_bp: Optional[int] = None
    diastolic_bp: Optional[int] = None
    heart_rate: Optional[int] = None
    spo2: Optional[int] = None
    gcs_score: Optional[int] = None       # Glasgow Coma Scale 3-15
    blood_glucose: Optional[int] = None
    allergies: Optional[str] = None
    medications: Optional[str] = None
    notes: Optional[str] = None


@router.post("/intake", summary="Paramedic intake form (on arrival)")
async def submit_intake(
    req: IntakeForm,
    me=Depends(responder_only),
    db: AsyncSession = Depends(get_db),
):
    # Severity assessment from vitals
    severity_flags = []
    if req.spo2 and req.spo2 < 90:
        severity_flags.append(f"SpO2 critically low: {req.spo2}%")
    if req.systolic_bp and req.systolic_bp > 180:
        severity_flags.append(f"BP hypertensive crisis: {req.systolic_bp}")
    if req.heart_rate and (req.heart_rate < 40 or req.heart_rate > 150):
        severity_flags.append(f"HR critical: {req.heart_rate}")
    if req.gcs_score and req.gcs_score < 9:
        severity_flags.append(f"GCS severely depressed: {req.gcs_score}")

    # Log to audit
    await db.execute(text("""
        INSERT INTO notifications_log (channel, to_number, message_type, message_body, status)
        VALUES ('push', :to, 'PARAMEDIC_INTAKE', :body, 'sent')
    """), {
        "to": "108-dispatch",
        "body": f"Intake: {req.patient_name} | {req.chief_complaint} | flags: {severity_flags}",
    })
    await db.commit()

    logger.warning(
        f"PARAMEDIC INTAKE: case={req.case_id} patient={req.patient_name} "
        f"flags={severity_flags} responder={me['sub']}"
    )

    return {
        "intake_recorded": True,
        "case_id": req.case_id,
        "severity_flags": severity_flags,
        "critical": len(severity_flags) > 0,
        "recommended_action": "Immediate ER" if severity_flags else "Standard intake",
        "responder": me["name"],
        "recorded_at": datetime.utcnow().isoformat(),
    }


# ══════════════════════════════════════════
#  STATUS UPDATES
# ══════════════════════════════════════════

VALID_STATUSES = ("dispatched", "en_route", "on_scene", "transporting", "at_hospital", "completed")


@router.patch("/cases/{case_id}/status", summary="Update responder status")
async def update_status(
    case_id: str,
    status: str = Body(..., embed=True),
    eta_minutes: Optional[int] = Body(None, embed=True),
    me=Depends(responder_only),
    db: AsyncSession = Depends(get_db),
):
    if status not in VALID_STATUSES:
        raise HTTPException(400, f"Status must be one of {VALID_STATUSES}")

    logger.info(f"Emergency status update: case={case_id} status={status} by {me['sub']}")
    return {
        "case_id": case_id,
        "status": status,
        "eta_minutes": eta_minutes,
        "updated_by": me["name"],
        "updated_at": datetime.utcnow().isoformat(),
        "ambulance_number": "108",
    }
