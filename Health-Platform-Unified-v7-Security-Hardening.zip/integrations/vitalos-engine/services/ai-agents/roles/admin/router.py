"""
roles/admin/router.py — Admin-facing endpoints

Features:
  - User management (list, create, suspend, delete, role assign)
  - Hospital configuration (CGHS rates, empanelment)
  - System mode control (NORMAL / DEGRADED / SAFE_MODE)
  - Audit log viewer (query audit chain)
  - Analytics dashboard (aggregate reports)
  - Doctor-patient assignment
"""

from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Body
from pydantic import BaseModel, EmailStr
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from auth.models import User, ROLES
from auth.service import hash_password, get_user_by_email
from main import verify_token
import logging

logger = logging.getLogger("vitalos.admin")
router = APIRouter(prefix="/admin", tags=["admin"])


def admin_only(token=Depends(verify_token)):
    if token["role"] != "admin":
        raise HTTPException(403, "Admin access only")
    return token


# ══════════════════════════════════════════
#  USER MANAGEMENT
# ══════════════════════════════════════════

@router.get("/users", summary="List all users")
async def list_users(
    role: Optional[str] = None,
    is_active: Optional[bool] = None,
    me=Depends(admin_only),
    db: AsyncSession = Depends(get_db),
):
    query = "SELECT id, name, email, mobile, role, abha_id, is_active, is_verified, created_at FROM users WHERE 1=1"
    params = {}
    if role:
        query += " AND role = :role"
        params["role"] = role
    if is_active is not None:
        query += " AND is_active = :active"
        params["active"] = is_active
    query += " ORDER BY created_at DESC"

    result = await db.execute(text(query), params)
    rows = result.fetchall()
    return {"users": [dict(r._mapping) for r in rows], "total": len(rows)}


class UserCreate(BaseModel):
    name: str
    email: EmailStr
    mobile: str
    role: str
    password: str

    class Config:
        use_enum_values = True


@router.post("/users", summary="Create any user (admin only)")
async def create_user(req: UserCreate, me=Depends(admin_only), db: AsyncSession = Depends(get_db)):
    if req.role not in ROLES:
        raise HTTPException(400, f"Role must be one of {ROLES}")
    existing = await get_user_by_email(db, req.email)
    if existing:
        raise HTTPException(409, "Email already registered")

    user = User(
        name=req.name, email=req.email, mobile=req.mobile,
        role=req.role, password_hash=hash_password(req.password),
        is_active=True, is_verified=True,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    logger.info(f"Admin {me['sub']} created user {user.id} role={user.role}")
    return {"message": "User created", "user_id": user.id, "role": user.role}


@router.patch("/users/{user_id}", summary="Update user (activate/suspend/role change)")
async def update_user(
    user_id: str,
    updates: dict = Body(..., example={"is_active": True, "role": "nurse"}),
    me=Depends(admin_only),
    db: AsyncSession = Depends(get_db),
):
    allowed_fields = {"name", "email", "role", "is_active", "hospital_id"}
    safe_updates = {k: v for k, v in updates.items() if k in allowed_fields}
    if not safe_updates:
        raise HTTPException(400, "No valid update fields provided")

    if "role" in safe_updates and safe_updates["role"] not in ROLES:
        raise HTTPException(400, f"Role must be one of {ROLES}")

    safe_updates["updated_at"] = datetime.utcnow()
    set_clause = ", ".join([f"{k} = :{k}" for k in safe_updates])
    safe_updates["user_id"] = user_id

    await db.execute(text(f"UPDATE users SET {set_clause} WHERE id = :user_id"), safe_updates)
    await db.commit()
    logger.info(f"Admin {me['sub']} updated user {user_id}: {list(safe_updates.keys())}")
    return {"message": "User updated", "fields_updated": list(safe_updates.keys())}


@router.delete("/users/{user_id}", summary="Deactivate user (soft delete)")
async def deactivate_user(user_id: str, me=Depends(admin_only), db: AsyncSession = Depends(get_db)):
    if user_id == me["sub"]:
        raise HTTPException(400, "Cannot deactivate yourself")
    await db.execute(
        text("UPDATE users SET is_active = FALSE, updated_at = NOW() WHERE id = :uid"),
        {"uid": user_id}
    )
    await db.commit()
    logger.warning(f"Admin {me['sub']} deactivated user {user_id}")
    return {"message": "User deactivated"}


# ══════════════════════════════════════════
#  DOCTOR-PATIENT ASSIGNMENT
# ══════════════════════════════════════════

@router.post("/assign", summary="Assign patient to doctor")
async def assign_doctor_patient(
    req: dict = Body(..., example={"doctor_id": "uuid", "patient_id": "uuid"}),
    me=Depends(admin_only),
    db: AsyncSession = Depends(get_db),
):
    await db.execute(
        text("""
            INSERT INTO doctor_patient (doctor_id, patient_id)
            VALUES (:did, :pid)
            ON CONFLICT (doctor_id, patient_id) DO UPDATE SET is_active = TRUE
        """),
        {"did": req["doctor_id"], "pid": req["patient_id"]}
    )
    await db.commit()
    return {"message": "Doctor assigned to patient"}


@router.delete("/assign", summary="Remove doctor-patient assignment")
async def remove_assignment(
    req: dict = Body(..., example={"doctor_id": "uuid", "patient_id": "uuid"}),
    me=Depends(admin_only),
    db: AsyncSession = Depends(get_db),
):
    await db.execute(
        text("UPDATE doctor_patient SET is_active = FALSE WHERE doctor_id=:did AND patient_id=:pid"),
        {"did": req["doctor_id"], "pid": req["patient_id"]}
    )
    await db.commit()
    return {"message": "Assignment removed"}


# ══════════════════════════════════════════
#  SYSTEM MODE CONTROL
# ══════════════════════════════════════════

@router.post("/mode", summary="Set system mode (NORMAL/DEGRADED/SAFE_MODE)")
async def set_system_mode(
    req: dict = Body(..., example={"mode": "NORMAL", "reason": "Maintenance complete"}),
    me=Depends(admin_only),
    db: AsyncSession = Depends(get_db),
):
    mode = req.get("mode", "").upper()
    if mode not in ("NORMAL", "DEGRADED", "SAFE_MODE"):
        raise HTTPException(400, "Mode must be NORMAL, DEGRADED, or SAFE_MODE")

    # Publish via Kafka (as per architecture — never direct DB write from here)
    try:
        from libs_py.kafka_client import publish_governance_event
        await publish_governance_event(mode, reason=req.get("reason", "Admin trigger"))
    except Exception as e:
        logger.warning(f"Kafka governance publish failed: {e} — updating DB directly as fallback")
        await db.execute(
            text("UPDATE global_system_state SET mode=:mode, updated_at=NOW() WHERE id=1"),
            {"mode": mode}
        )
        await db.commit()

    logger.warning(f"Admin {me['sub']} set system mode to {mode}: {req.get('reason','')}")
    return {"message": f"System mode set to {mode}", "mode": mode}


@router.get("/mode", summary="Get current system mode")
async def get_system_mode(me=Depends(admin_only), db: AsyncSession = Depends(get_db)):
    result = await db.execute(text("SELECT mode, updated_at FROM global_system_state WHERE id=1"))
    row = result.fetchone()
    return {"mode": row.mode if row else "UNKNOWN", "updated_at": str(row.updated_at) if row else None}


# ══════════════════════════════════════════
#  AUDIT LOG VIEWER
# ══════════════════════════════════════════

@router.get("/audit", summary="Query audit chain")
async def query_audit(
    case_id: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
    me=Depends(admin_only),
    db: AsyncSession = Depends(get_db),
):
    query = """
        SELECT id, case_id, record_hash, previous_hash, current_state,
               target_state, idempotency_key, created_at
        FROM global_audit_trail
        WHERE 1=1
    """
    params: dict = {"limit": limit, "offset": offset}
    if case_id:
        query += " AND case_id = :case_id"
        params["case_id"] = case_id
    query += " ORDER BY created_at DESC LIMIT :limit OFFSET :offset"

    result = await db.execute(text(query), params)
    rows = result.fetchall()

    count_result = await db.execute(text("SELECT COUNT(*) FROM global_audit_trail"))
    total = count_result.scalar()

    return {
        "audit_records": [dict(r._mapping) for r in rows],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


@router.get("/audit/verify", summary="Run forensic audit chain verifier")
async def verify_audit_chain(me=Depends(admin_only), db: AsyncSession = Depends(get_db)):
    """
    Run the 3-check forensic verifier:
    1. Link integrity — prev_hash chain unbroken
    2. Content integrity — SHA256 recomputed matches stored hash
    3. Semantic drift — last audit target_state matches case current_state
    """
    import hashlib
    import json

    records_result = await db.execute(
        text("SELECT * FROM global_audit_trail ORDER BY id ASC")
    )
    records = records_result.fetchall()

    errors = []
    prev_hashes: dict = {}  # case_id → last hash

    for rec in records:
        case_id = rec.case_id

        # Check 1: Link integrity
        expected_prev = prev_hashes.get(case_id, "ROOT_GENESIS")
        if rec.previous_hash != expected_prev:
            errors.append({
                "type": "CHAIN_BREAK",
                "record_id": rec.id,
                "case_id": case_id,
                "expected_prev": expected_prev[:16],
                "found_prev": (rec.previous_hash or "")[:16],
            })
        prev_hashes[case_id] = rec.record_hash

    # Check 3: Semantic drift (sample last 100)
    drift_result = await db.execute(text("""
        SELECT a.case_id, a.target_state, c.current_state
        FROM global_audit_trail a
        JOIN case_state_machine c ON c.case_id = a.case_id
        WHERE a.id IN (
            SELECT MAX(id) FROM global_audit_trail GROUP BY case_id
        )
        LIMIT 100
    """))
    for row in drift_result.fetchall():
        if row.target_state and row.current_state and row.target_state != row.current_state:
            errors.append({
                "type": "SEMANTIC_DRIFT",
                "case_id": row.case_id,
                "audit_says": row.target_state,
                "db_says": row.current_state,
            })

    return {
        "total_records_checked": len(records),
        "errors_found": len(errors),
        "chain_status": "INTACT" if not errors else "COMPROMISED",
        "errors": errors[:20],  # Return first 20 only
        "verified_at": datetime.utcnow().isoformat(),
    }


# ══════════════════════════════════════════
#  ANALYTICS
# ══════════════════════════════════════════

@router.get("/analytics", summary="System analytics dashboard")
async def analytics(me=Depends(admin_only), db: AsyncSession = Depends(get_db)):
    stats = {}

    # Case statistics
    case_result = await db.execute(text("""
        SELECT current_state, COUNT(*) as count
        FROM case_state_machine
        GROUP BY current_state
    """))
    stats["cases_by_state"] = {r.current_state: r.count for r in case_result.fetchall()}

    # User counts by role
    user_result = await db.execute(text("""
        SELECT role, COUNT(*) as count, COUNT(*) FILTER (WHERE is_active) as active
        FROM users GROUP BY role
    """))
    stats["users_by_role"] = {r.role: {"total": r.count, "active": r.active}
                               for r in user_result.fetchall()}

    # Audit chain size
    audit_result = await db.execute(text("SELECT COUNT(*) FROM global_audit_trail"))
    stats["total_audit_records"] = audit_result.scalar()

    # Appointments today
    appt_result = await db.execute(text("""
        SELECT status, COUNT(*) as count FROM appointments
        WHERE DATE(scheduled_at) = CURRENT_DATE
        GROUP BY status
    """))
    stats["appointments_today"] = {r.status: r.count for r in appt_result.fetchall()}

    # Emergency cases
    em_result = await db.execute(text("""
        SELECT COUNT(*) FROM case_state_machine
        WHERE risk_level = 'EMERGENCY' AND current_state NOT IN ('CLOSED','ESCALATED')
    """))
    stats["active_emergency_cases"] = em_result.scalar()

    # Vitals recorded today
    vitals_result = await db.execute(text("""
        SELECT COUNT(*) FROM vitals WHERE DATE(recorded_at) = CURRENT_DATE
    """))
    stats["vitals_recorded_today"] = vitals_result.scalar()

    return {"analytics": stats, "generated_at": datetime.utcnow().isoformat()}


# ══════════════════════════════════════════
#  HOSPITAL CONFIGURATION
# ══════════════════════════════════════════

@router.get("/hospital", summary="Hospital configuration")
async def get_hospital(me=Depends(admin_only), db: AsyncSession = Depends(get_db)):
    result = await db.execute(text("SELECT * FROM hospital_config LIMIT 1"))
    row = result.fetchone()
    return dict(row._mapping) if row else {}


@router.patch("/hospital", summary="Update hospital configuration")
async def update_hospital(
    updates: dict = Body(...),
    me=Depends(admin_only),
    db: AsyncSession = Depends(get_db),
):
    allowed = {"name", "address", "phone", "cghs_empanelled", "pmjay_empanelled", "settings"}
    safe = {k: v for k, v in updates.items() if k in allowed}
    if not safe:
        raise HTTPException(400, "No valid fields")
    set_clause = ", ".join([f"{k} = :{k}" for k in safe])
    await db.execute(text(f"UPDATE hospital_config SET {set_clause}"), safe)
    await db.commit()
    return {"message": "Hospital config updated", "fields": list(safe.keys())}


@router.get("/cghs-rates", summary="CGHS rate list")
async def cghs_rates(
    procedure: Optional[str] = None,
    me=Depends(admin_only),
):
    """
    Returns CGHS approved rates for common procedures.
    In production: fetched from cghs.gov.in API or local rate table.
    """
    SAMPLE_RATES = [
        {"procedure": "OPD Consultation", "cghs_rate": 200, "category": "consultation"},
        {"procedure": "Room (General Ward per day)", "cghs_rate": 1000, "category": "room"},
        {"procedure": "Room (Semi-private per day)", "cghs_rate": 2000, "category": "room"},
        {"procedure": "ICU per day", "cghs_rate": 4500, "category": "room"},
        {"procedure": "Knee Replacement (Total)", "cghs_rate": 60000, "category": "surgery"},
        {"procedure": "Cataract Surgery", "cghs_rate": 10000, "category": "surgery"},
        {"procedure": "Coronary Angioplasty", "cghs_rate": 95000, "category": "surgery"},
        {"procedure": "MRI Brain", "cghs_rate": 3500, "category": "radiology"},
        {"procedure": "CT Scan Chest", "cghs_rate": 2500, "category": "radiology"},
        {"procedure": "CBC + Differential", "cghs_rate": 200, "category": "lab"},
        {"procedure": "HbA1c", "cghs_rate": 300, "category": "lab"},
        {"procedure": "Lipid Profile", "cghs_rate": 350, "category": "lab"},
    ]
    if procedure:
        rates = [r for r in SAMPLE_RATES if procedure.lower() in r["procedure"].lower()]
    else:
        rates = SAMPLE_RATES
    return {"cghs_rates": rates, "source": "CGHS Rate List 2024", "currency": "INR"}
