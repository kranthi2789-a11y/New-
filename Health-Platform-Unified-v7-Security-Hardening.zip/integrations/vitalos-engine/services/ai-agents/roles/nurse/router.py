"""
roles/nurse/router.py — Nurse-facing endpoints

Features:
  - Ward patient list
  - Record vitals (BP, SpO2, HR, temp, glucose)
  - Medication Administration Record (MAR)
  - Escalate to doctor
  - Discharge checklist
  - Alert on critical vitals
"""

from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Body
from pydantic import BaseModel
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from auth.models import User
from main import verify_token
from services.whatsapp import send_whatsapp
import logging

logger = logging.getLogger("vitalos.nurse")
router = APIRouter(prefix="/nurse", tags=["nurse"])

CRITICAL_THRESHOLDS = {
    "systolic_bp":   (80, 180),   # (low, high)
    "diastolic_bp":  (50, 120),
    "heart_rate":    (40, 150),
    "spo2":          (90, 100),   # below 90 = CRITICAL
    "temperature":   (35.0, 39.5),
    "blood_glucose": (50, 400),
}


def nurse_only(token=Depends(verify_token)):
    if token["role"] not in ("nurse", "doctor", "admin"):
        raise HTTPException(403, "Nurse access only")
    return token


# ══════════════════════════════════════════
#  WARD PATIENTS
# ══════════════════════════════════════════

@router.get("/patients", summary="Ward patient list")
async def ward_patients(me=Depends(nurse_only), db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("""
            SELECT u.id, u.name, u.mobile, u.abha_id,
                   p.conditions, p.blood_group,
                   v.systolic_bp, v.heart_rate, v.spo2, v.recorded_at as last_vitals_at
            FROM users u
            LEFT JOIN patients p ON p.mobile = u.mobile
            LEFT JOIN LATERAL (
                SELECT * FROM vitals WHERE patient_id = u.id
                ORDER BY recorded_at DESC LIMIT 1
            ) v ON TRUE
            WHERE u.role = 'patient' AND u.is_active = TRUE
            ORDER BY u.name
        """)
    )
    rows = result.fetchall()
    return {"patients": [dict(r._mapping) for r in rows]}


# ══════════════════════════════════════════
#  VITALS RECORDING
# ══════════════════════════════════════════

class VitalsRequest(BaseModel):
    patient_id: str
    systolic_bp: Optional[int] = None
    diastolic_bp: Optional[int] = None
    heart_rate: Optional[int] = None
    temperature: Optional[float] = None
    spo2: Optional[int] = None
    weight_kg: Optional[float] = None
    blood_glucose: Optional[int] = None
    notes: Optional[str] = None


@router.post("/vitals", summary="Record patient vitals")
async def record_vitals(req: VitalsRequest, me=Depends(nurse_only), db: AsyncSession = Depends(get_db)):
    await db.execute(
        text("""
            INSERT INTO vitals
            (patient_id, recorded_by, systolic_bp, diastolic_bp, heart_rate,
             temperature, spo2, weight_kg, blood_glucose, notes)
            VALUES (:pid, :nurse_id, :sbp, :dbp, :hr, :temp, :spo2, :wt, :bg, :notes)
        """),
        {
            "pid": req.patient_id, "nurse_id": me["sub"],
            "sbp": req.systolic_bp, "dbp": req.diastolic_bp,
            "hr": req.heart_rate, "temp": req.temperature,
            "spo2": req.spo2, "wt": req.weight_kg,
            "bg": req.blood_glucose, "notes": req.notes,
        }
    )
    await db.commit()

    # Check for critical values
    alerts = _check_critical_vitals(req)
    if alerts:
        logger.warning(f"CRITICAL VITALS for patient {req.patient_id}: {alerts}")
        # Auto-escalate to doctor
        await _auto_escalate(req.patient_id, alerts, me["name"], db)

    return {
        "message": "Vitals recorded",
        "critical_alerts": alerts,
        "escalated": len(alerts) > 0,
    }


def _check_critical_vitals(req: VitalsRequest) -> list:
    alerts = []
    checks = {
        "systolic_bp":   req.systolic_bp,
        "diastolic_bp":  req.diastolic_bp,
        "heart_rate":    req.heart_rate,
        "spo2":          req.spo2,
        "temperature":   req.temperature,
        "blood_glucose": req.blood_glucose,
    }
    for param, value in checks.items():
        if value is None:
            continue
        low, high = CRITICAL_THRESHOLDS.get(param, (None, None))
        if low and value < low:
            alerts.append(f"⬇ {param} critically LOW: {value} (threshold: {low})")
        elif high and value > high:
            alerts.append(f"⬆ {param} critically HIGH: {value} (threshold: {high})")
    return alerts


async def _auto_escalate(patient_id: str, alerts: list, nurse_name: str, db: AsyncSession):
    """Find assigned doctor and notify via WhatsApp."""
    doctor_result = await db.execute(
        text("""
            SELECT u.mobile, u.name FROM doctor_patient dp
            JOIN users u ON dp.doctor_id = u.id
            WHERE dp.patient_id = :pid AND dp.is_active = TRUE
            LIMIT 1
        """),
        {"pid": patient_id}
    )
    doctor = doctor_result.fetchone()
    if doctor:
        alert_text = "\n".join(alerts)
        message = (
            f"🚨 *Critical Vitals Alert — VitalOS*\n\n"
            f"Patient ID: {patient_id}\n"
            f"Nurse: {nurse_name}\n\n"
            f"*Critical Readings:*\n{alert_text}\n\n"
            f"Please review immediately."
        )
        try:
            await send_whatsapp(doctor.mobile, message)
        except Exception as e:
            logger.error(f"Doctor alert WhatsApp failed: {e}")


@router.get("/vitals/{patient_id}", summary="Patient vitals history")
async def get_vitals(patient_id: str, me=Depends(nurse_only), db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("""
            SELECT v.*, u.name as nurse_name FROM vitals v
            JOIN users u ON v.recorded_by = u.id
            WHERE v.patient_id = :pid
            ORDER BY v.recorded_at DESC LIMIT 20
        """),
        {"pid": patient_id}
    )
    rows = result.fetchall()
    return {"vitals": [dict(r._mapping) for r in rows]}


# ══════════════════════════════════════════
#  MEDICATION ADMINISTRATION RECORD (MAR)
# ══════════════════════════════════════════

class MarRecord(BaseModel):
    patient_id: str
    drug_name: str
    dosage: str
    route: str = "oral"
    administered_at: Optional[str] = None
    notes: Optional[str] = None


@router.post("/mar", summary="Record medication administration")
async def record_mar(req: MarRecord, me=Depends(nurse_only), db: AsyncSession = Depends(get_db)):
    admin_at = req.administered_at or datetime.utcnow().isoformat()
    await db.execute(
        text("""
            INSERT INTO mar_records
            (patient_id, nurse_id, drug_name, dosage, route, administered_at, notes)
            VALUES (:pid, :nid, :drug, :dose, :route, :at, :notes)
        """),
        {
            "pid": req.patient_id, "nid": me["sub"],
            "drug": req.drug_name, "dose": req.dosage,
            "route": req.route, "at": admin_at, "notes": req.notes,
        }
    )
    await db.commit()
    return {"message": f"MAR recorded: {req.drug_name} administered at {admin_at}"}


@router.get("/mar/{patient_id}", summary="Patient MAR history")
async def get_mar(patient_id: str, me=Depends(nurse_only), db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("""
            SELECT m.*, u.name as nurse_name FROM mar_records m
            JOIN users u ON m.nurse_id = u.id
            WHERE m.patient_id = :pid
            ORDER BY m.administered_at DESC LIMIT 50
        """),
        {"pid": patient_id}
    )
    rows = result.fetchall()
    return {"mar": [dict(r._mapping) for r in rows]}


# ══════════════════════════════════════════
#  ESCALATION TO DOCTOR
# ══════════════════════════════════════════

class EscalationRequest(BaseModel):
    patient_id: str
    patient_name: str
    reason: str
    urgency: str = "high"


@router.post("/escalate", summary="Escalate patient to doctor")
async def escalate_to_doctor(
    req: EscalationRequest, me=Depends(nurse_only), db: AsyncSession = Depends(get_db)
):
    doctor_result = await db.execute(
        text("""
            SELECT u.mobile, u.name FROM doctor_patient dp
            JOIN users u ON dp.doctor_id = u.id
            WHERE dp.patient_id = :pid AND dp.is_active = TRUE
            LIMIT 1
        """),
        {"pid": req.patient_id}
    )
    doctor = doctor_result.fetchone()

    message = (
        f"🔴 *Nurse Escalation — VitalOS*\n\n"
        f"Patient: *{req.patient_name}*\n"
        f"Escalated by: {me['name']}\n"
        f"Urgency: *{req.urgency.upper()}*\n\n"
        f"Reason:\n{req.reason}\n\n"
        f"Please attend immediately."
    )

    notified = False
    if doctor:
        try:
            await send_whatsapp(doctor.mobile, message)
            notified = True
        except Exception as e:
            logger.error(f"Escalation WhatsApp failed: {e}")

    logger.warning(f"ESCALATION: patient={req.patient_id} reason={req.reason[:50]} nurse={me['sub']}")
    return {
        "message": "Escalation sent",
        "doctor_notified": notified,
        "doctor_name": doctor.name if doctor else "Not assigned",
    }


# ══════════════════════════════════════════
#  DISCHARGE CHECKLIST
# ══════════════════════════════════════════

DISCHARGE_CHECKLIST = [
    "Discharge summary signed by doctor",
    "Medications dispensed and explained to patient",
    "Follow-up appointment scheduled",
    "Diet and activity instructions given",
    "Emergency contact and 108 number provided",
    "PMJAY/insurance paperwork completed",
    "Lab reports and discharge notes given to patient",
    "Patient and family counselled",
]


@router.post("/discharge/{patient_id}", summary="Complete discharge checklist")
async def discharge_patient(
    patient_id: str,
    completed_items: List[str] = Body(...),
    notes: Optional[str] = Body(None),
    me=Depends(nurse_only),
    db: AsyncSession = Depends(get_db),
):
    from typing import List
    missing = [item for item in DISCHARGE_CHECKLIST if item not in completed_items]

    logger.info(f"Discharge: patient={patient_id} completed={len(completed_items)} missing={len(missing)}")

    return {
        "discharge_ready": len(missing) == 0,
        "completed": completed_items,
        "pending": missing,
        "notes": notes,
        "checklist_total": len(DISCHARGE_CHECKLIST),
        "completed_count": len(completed_items),
    }


@router.get("/discharge/checklist", summary="Get discharge checklist template")
async def get_checklist(me=Depends(nurse_only)):
    return {"checklist": DISCHARGE_CHECKLIST}
