"""
roles/patient/router.py — All patient-facing endpoints

Features:
  - Profile management (view, edit, health card)
  - Prescription scan → Calendar sync → WhatsApp reminder
  - Lab report history
  - Family contacts (add/remove/SOS trigger)
  - Insurance policies (find, save, benefits lookup)
  - Bill scan and dispute
  - Medication adherence logging
"""

import base64
from datetime import datetime, date
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Body
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from core.database import Patient, MedicationReminder, LabReport, Prescription
from auth.models import User, FamilyContact
from main import verify_token
from agents.orchestrator import AgentOrchestrator
from services.whatsapp import send_whatsapp_template
from services.calendar import generate_ical, prescription_to_calendar_events
from services.sos import broadcast_sos
import logging

logger = logging.getLogger("vitalos.patient")
router = APIRouter(prefix="/patient", tags=["patient"])


def patient_only(token=Depends(verify_token)):
    if token["role"] != "patient":
        raise HTTPException(403, "Patient access only")
    return token


# ══════════════════════════════════════════
#  PROFILE
# ══════════════════════════════════════════

@router.get("/me", summary="Get own profile")
async def get_profile(me=Depends(patient_only), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == me["sub"]))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(404, "Profile not found")
    return {
        "id": user.id, "name": user.name, "mobile": user.mobile,
        "email": user.email, "abha_id": user.abha_id, "role": user.role,
        "is_verified": user.is_verified, "created_at": str(user.created_at),
    }


class ProfileUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    abha_id: Optional[str] = None


@router.patch("/me", summary="Update own profile")
async def update_profile(
    req: ProfileUpdate, me=Depends(patient_only), db: AsyncSession = Depends(get_db)
):
    update_data = {k: v for k, v in req.dict().items() if v is not None}
    update_data["updated_at"] = datetime.utcnow()
    await db.execute(update(User).where(User.id == me["sub"]).values(**update_data))
    await db.commit()
    return {"message": "Profile updated successfully"}


@router.get("/me/health-card", summary="Digital health card")
async def health_card(me=Depends(patient_only), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == me["sub"]))
    user = result.scalar_one_or_none()

    # Fetch latest vitals
    from auth.models import FamilyContact
    vitals_result = await db.execute(
        select(Patient).where(Patient.mobile == user.mobile).limit(1)
    )
    patient = vitals_result.scalar_one_or_none()

    return {
        "health_card": {
            "card_number": f"VOS-{user.id[:8].upper()}",
            "patient_name": user.name,
            "mobile": user.mobile,
            "abha_id": user.abha_id or "Not linked",
            "blood_group": patient.blood_group if patient else "Unknown",
            "conditions": patient.conditions if patient else [],
            "allergies": patient.allergies if patient else [],
            "issued_by": "VitalOS Clinical OS",
            "issued_at": str(datetime.utcnow().date()),
            "valid_until": str(date(datetime.utcnow().year + 1, 1, 1)),
            "emergency_contact": "108",
            "qr_data": f"vitalos://patient/{user.id}",
        }
    }


# ══════════════════════════════════════════
#  PRESCRIPTION SCAN → CALENDAR + WHATSAPP
# ══════════════════════════════════════════

@router.post("/prescriptions/scan", summary="Scan Rx → parse → calendar → WhatsApp reminder")
async def scan_prescription(
    file: UploadFile = File(...),
    me=Depends(patient_only),
    db: AsyncSession = Depends(get_db),
):
    """
    Upload prescription image/PDF → AI parses → creates medication reminders
    → generates iCal → sends WhatsApp confirmation to patient.
    """
    contents = await file.read()
    b64 = base64.b64encode(contents).decode()

    # AI parse
    agent = AgentOrchestrator.get("prescription")
    result = await agent.run(prescription_text=f"[Image: {file.filename}]", image_base64=b64)

    if "error" in result:
        raise HTTPException(400, f"Could not parse prescription: {result.get('error')}")

    medications = result.get("medications", [])
    if not medications:
        raise HTTPException(400, "No medications found in prescription")

    # Generate calendar events
    today = datetime.utcnow().strftime("%Y-%m-%d")
    cal_events = prescription_to_calendar_events(medications, start_date=today)
    ical_content = generate_ical(cal_events)

    # Save to DB
    user_result = await db.execute(select(User).where(User.id == me["sub"]))
    user = user_result.scalar_one_or_none()

    for med in medications:
        for t in med.get("reminder_times", ["08:00"]):
            reminder = MedicationReminder(
                patient_mobile=user.mobile if user else "",
                drug_name=med.get("drug_name", ""),
                dosage=med.get("dosage", ""),
                frequency=med.get("frequency", ""),
                schedule_times=med.get("reminder_times", []),
                active=True,
                streak_days=0,
            )
            db.add(reminder)

    # Save prescription record
    rx_record = Prescription(
        patient_mobile=user.mobile if user else "",
        doctor_name=result.get("doctor_name", ""),
        clinic_name=result.get("clinic_name", ""),
        medications=medications,
        diagnosis=result.get("diagnosis", ""),
    )
    db.add(rx_record)
    await db.commit()

    # Send WhatsApp confirmation
    drug_list = "\n".join([f"• {m.get('drug_name','')} {m.get('dosage','')}" for m in medications[:5]])
    wa_message = (
        f"💊 *Prescription Scanned — VitalOS*\n\n"
        f"Your prescription has been parsed.\n\n"
        f"*Medications ({len(medications)}):*\n{drug_list}\n\n"
        f"✅ Reminders added to your schedule\n"
        f"📅 Calendar file sent — import to Google/Apple Calendar\n\n"
        f"Doctor: {result.get('doctor_name','Unknown')}\n"
        f"Follow-up in: {result.get('follow_up_days','N/A')} days"
    )

    if user:
        try:
            await send_whatsapp_template(user.mobile, "medication_reminder",
                name=user.name, drug=medications[0].get("drug_name",""), 
                dosage=medications[0].get("dosage",""),
                instructions=medications[0].get("instructions","As directed"))
        except Exception as e:
            logger.warning(f"WhatsApp send failed: {e}")

    warnings = result.get("interaction_warnings", [])

    return {
        "medications": medications,
        "reminders_created": len(cal_events),
        "interaction_warnings": warnings,
        "calendar": {
            "ical_available": True,
            "events_count": len(cal_events),
            "instructions": "Download the .ics file and import to Google Calendar / Apple Calendar",
        },
        "whatsapp_sent": True,
        "message": f"Parsed {len(medications)} medications. Reminders scheduled. WhatsApp sent.",
    }


@router.get("/prescriptions/calendar.ics", summary="Download medication calendar")
async def download_calendar(me=Depends(patient_only), db: AsyncSession = Depends(get_db)):
    """Download iCal file of all active medication reminders."""
    user_result = await db.execute(select(User).where(User.id == me["sub"]))
    user = user_result.scalar_one_or_none()

    reminders_result = await db.execute(
        select(MedicationReminder).where(
            MedicationReminder.patient_mobile == (user.mobile if user else ""),
            MedicationReminder.active == True,
        )
    )
    reminders = reminders_result.scalars().all()

    today = datetime.utcnow().strftime("%Y-%m-%d")
    events = []
    for r in reminders:
        for t in (r.schedule_times or ["08:00"]):
            events.append({
                "title":    f"💊 {r.drug_name} {r.dosage}".strip(),
                "description": f"Take as prescribed. VitalOS reminder.",
                "date":    today,
                "time":    t,
                "repeat":  "DAILY",
            })

    ical = generate_ical(events)
    return Response(
        content=ical,
        media_type="text/calendar",
        headers={"Content-Disposition": "attachment; filename=vitalos-medications.ics"},
    )


@router.get("/prescriptions", summary="Prescription history")
async def prescription_history(me=Depends(patient_only), db: AsyncSession = Depends(get_db)):
    user_result = await db.execute(select(User).where(User.id == me["sub"]))
    user = user_result.scalar_one_or_none()
    result = await db.execute(
        select(Prescription).where(Prescription.patient_mobile == (user.mobile if user else ""))
        .order_by(Prescription.created_at.desc()).limit(20)
    )
    rxs = result.scalars().all()
    return {"prescriptions": [
        {"id": r.id, "doctor": r.doctor_name, "diagnosis": r.diagnosis,
         "medications": r.medications, "date": str(r.created_at)}
        for r in rxs
    ]}


# ══════════════════════════════════════════
#  LAB REPORTS
# ══════════════════════════════════════════

@router.post("/labs/scan", summary="Scan lab report image")
async def scan_lab(
    file: UploadFile = File(...),
    patient_age: Optional[int] = None,
    me=Depends(patient_only),
    db: AsyncSession = Depends(get_db),
):
    contents = await file.read()
    b64 = base64.b64encode(contents).decode()
    agent = AgentOrchestrator.get("lab")
    result = await agent.run(lab_text="[Image uploaded]", image_base64=b64, patient_age=patient_age)

    user_result = await db.execute(select(User).where(User.id == me["sub"]))
    user = user_result.scalar_one_or_none()

    lab = LabReport(
        patient_mobile=user.mobile if user else "",
        report_type=result.get("report_type", "Unknown"),
        raw_text="[Image]",
        extracted_values={v["test_name"]: v for v in result.get("values", [])},
        flags=result.get("flags", []),
        follow_up_urgency=result.get("follow_up_urgency", "routine"),
        ai_explanation=result.get("patient_summary", ""),
    )
    db.add(lab)
    await db.commit()

    # Alert if urgent
    urgency = result.get("follow_up_urgency", "routine")
    if urgency in ("urgent", "emergency") and user:
        try:
            await send_whatsapp_template(
                user.mobile, "lab_result",
                name=user.name,
                report_type=result.get("report_type", "Lab Report"),
                urgency=urgency.upper(),
                summary=result.get("patient_summary", "Please consult your doctor.")
            )
        except Exception as e:
            logger.warning(f"Lab alert WhatsApp failed: {e}")

    return result


@router.get("/labs", summary="Lab report history")
async def lab_history(me=Depends(patient_only), db: AsyncSession = Depends(get_db)):
    user_result = await db.execute(select(User).where(User.id == me["sub"]))
    user = user_result.scalar_one_or_none()
    result = await db.execute(
        select(LabReport).where(LabReport.patient_mobile == (user.mobile if user else ""))
        .order_by(LabReport.created_at.desc()).limit(20)
    )
    labs = result.scalars().all()
    return {"lab_reports": [
        {"id": r.id, "type": r.report_type, "flags": r.flags,
         "urgency": r.follow_up_urgency, "date": str(r.created_at)}
        for r in labs
    ]}


# ══════════════════════════════════════════
#  FAMILY CONTACTS + SOS
# ══════════════════════════════════════════

class FamilyContactCreate(BaseModel):
    name: str
    mobile: str
    relation: str
    is_primary_sos: bool = False


@router.get("/family", summary="List family contacts")
async def list_family(me=Depends(patient_only), db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(FamilyContact).where(FamilyContact.patient_id == me["sub"])
    )
    contacts = result.scalars().all()
    return {"contacts": [
        {"id": c.id, "name": c.name, "mobile": c.mobile,
         "relation": c.relation, "is_primary_sos": c.is_primary_sos}
        for c in contacts
    ]}


@router.post("/family", summary="Add family contact")
async def add_family_contact(
    req: FamilyContactCreate, me=Depends(patient_only), db: AsyncSession = Depends(get_db)
):
    contact = FamilyContact(
        patient_id=me["sub"], name=req.name, mobile=req.mobile,
        relation=req.relation, is_primary_sos=req.is_primary_sos,
    )
    db.add(contact)
    await db.commit()
    await db.refresh(contact)
    return {"message": "Contact added", "id": contact.id}


@router.delete("/family/{contact_id}", summary="Remove family contact")
async def remove_family_contact(
    contact_id: str, me=Depends(patient_only), db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(FamilyContact).where(
            FamilyContact.id == contact_id,
            FamilyContact.patient_id == me["sub"]
        )
    )
    contact = result.scalar_one_or_none()
    if not contact:
        raise HTTPException(404, "Contact not found")
    await db.delete(contact)
    await db.commit()
    return {"message": "Contact removed"}


class SosRequest(BaseModel):
    location: Optional[str] = None
    message: Optional[str] = None


@router.post("/sos", summary="🚨 Trigger SOS to all family contacts")
async def trigger_sos(
    req: SosRequest, me=Depends(patient_only), db: AsyncSession = Depends(get_db)
):
    user_result = await db.execute(select(User).where(User.id == me["sub"]))
    user = user_result.scalar_one_or_none()

    contacts_result = await db.execute(
        select(FamilyContact).where(FamilyContact.patient_id == me["sub"])
    )
    contacts = contacts_result.scalars().all()

    family_list = [
        {"name": c.name, "mobile": c.mobile,
         "relation": c.relation, "is_primary_sos": c.is_primary_sos}
        for c in contacts
    ]

    result = await broadcast_sos(
        patient_name=user.name if user else me["name"],
        patient_mobile=user.mobile if user else "",
        family_contacts=family_list,
        location=req.location,
        message=req.message,
    )

    logger.warning(f"SOS triggered by patient {me['sub']}: {result}")
    return {**result, "emergency_number": "108"}


# ══════════════════════════════════════════
#  INSURANCE
# ══════════════════════════════════════════

class InsuranceCreate(BaseModel):
    policy_name: str
    insurer: Optional[str] = None
    policy_number: Optional[str] = None
    sum_insured: Optional[float] = None
    premium_annual: Optional[float] = None
    expiry_date: Optional[str] = None
    policy_text: Optional[str] = None


@router.get("/insurance", summary="My saved insurance policies")
async def list_insurance(me=Depends(patient_only), db: AsyncSession = Depends(get_db)):
    from sqlalchemy import text
    result = await db.execute(
        text("SELECT * FROM insurance_policies WHERE patient_id=:pid ORDER BY created_at DESC"),
        {"pid": me["sub"]}
    )
    rows = result.fetchall()
    return {"policies": [dict(r._mapping) for r in rows]}


@router.post("/insurance", summary="Save insurance policy")
async def add_insurance(
    req: InsuranceCreate, me=Depends(patient_only), db: AsyncSession = Depends(get_db)
):
    # AI analysis of policy text
    ai_summary = None
    if req.policy_text:
        agent = AgentOrchestrator.get("insurance")
        try:
            ai_summary = await agent.run(
                policy_details=req.policy_text,
                procedure="general coverage overview",
            )
        except Exception:
            pass

    from sqlalchemy import text
    await db.execute(
        text("""
            INSERT INTO insurance_policies
            (patient_id, policy_name, insurer, policy_number, sum_insured,
             premium_annual, expiry_date, policy_text, ai_summary)
            VALUES (:pid, :pname, :ins, :pnum, :si, :pa, :exp, :pt, :ai)
        """),
        {
            "pid": me["sub"], "pname": req.policy_name, "ins": req.insurer,
            "pnum": req.policy_number, "si": req.sum_insured,
            "pa": req.premium_annual, "exp": req.expiry_date,
            "pt": req.policy_text, "ai": str(ai_summary) if ai_summary else None,
        }
    )
    await db.commit()
    return {"message": "Policy saved", "ai_summary": ai_summary}


@router.post("/insurance/analyze", summary="Analyze policy for a procedure")
async def analyze_insurance(
    req: dict = Body(..., example={"policy_details": "...", "procedure": "Knee replacement"}),
    me=Depends(patient_only),
):
    agent = AgentOrchestrator.get("insurance")
    result = await agent.run(
        policy_details=req.get("policy_details", ""),
        procedure=req.get("procedure", ""),
        hospital_type=req.get("hospital_type", "private"),
        patient_income_category=req.get("income_category"),
        estimated_cost=req.get("estimated_cost"),
    )
    return result


@router.post("/insurance/find", summary="Find policies for my condition")
async def find_insurance_benefits(
    req: dict = Body(..., example={"condition": "diabetes", "location": "Hyderabad"}),
    me=Depends(patient_only),
):
    """AI finds applicable government + private schemes for patient's condition."""
    agent = AgentOrchestrator.get("insurance")
    result = await agent.run(
        policy_details=f"Find all applicable insurance and government health schemes for: {req.get('condition','')}",
        procedure=f"Treatment for {req.get('condition','')}",
        patient_income_category=req.get("income_category"),
    )
    return result


# ══════════════════════════════════════════
#  BILL SCAN + DISPUTE
# ══════════════════════════════════════════

@router.post("/bills/scan", summary="Scan hospital bill → detect overcharges")
async def scan_bill(
    file: UploadFile = File(None),
    bill_text: Optional[str] = Body(None),
    hospital_type: str = "private",
    insurance_type: str = "none",
    me=Depends(patient_only),
    db: AsyncSession = Depends(get_db),
):
    text_to_analyze = bill_text or ""
    if file:
        contents = await file.read()
        # In production: OCR via Tesseract/Google Vision
        # For now decode if text, otherwise note it's an image
        try:
            text_to_analyze = contents.decode("utf-8")
        except Exception:
            text_to_analyze = f"[Bill image: {file.filename}] " + (bill_text or "")

    if not text_to_analyze:
        raise HTTPException(400, "Provide bill text or upload bill image")

    agent = AgentOrchestrator.get("bill")
    result = await agent.run(
        bill_text=text_to_analyze,
        hospital_type=hospital_type,
        insurance_type=insurance_type,
    )

    # Notify if overcharge found
    overcharge = result.get("potential_overcharge", "₹0")
    user_result = await db.execute(select(User).where(User.id == me["sub"]))
    user = user_result.scalar_one_or_none()

    if user and overcharge and overcharge not in ("₹0", "0", "None"):
        try:
            await send_whatsapp_template(
                user.mobile, "bill_dispute",
                name=user.name,
                amount=overcharge,
                hospital=hospital_type,
            )
        except Exception as e:
            logger.warning(f"Bill dispute WhatsApp failed: {e}")

    return result


# ══════════════════════════════════════════
#  MEDICATION ADHERENCE
# ══════════════════════════════════════════

@router.post("/medications/log", summary="Log medication taken/skipped")
async def log_medication(
    req: dict = Body(..., example={"drug_name": "Metformin", "status": "taken", "scheduled_time": "08:00"}),
    me=Depends(patient_only),
    db: AsyncSession = Depends(get_db),
):
    from sqlalchemy import text
    await db.execute(
        text("""
            INSERT INTO medication_logs (patient_id, drug_name, scheduled_time, status, taken_at)
            VALUES (:pid, :drug, :stime, :status, :taken_at)
        """),
        {
            "pid": me["sub"],
            "drug": req.get("drug_name"),
            "stime": req.get("scheduled_time", "08:00"),
            "status": req.get("status", "taken"),
            "taken_at": datetime.utcnow() if req.get("status") == "taken" else None,
        }
    )
    await db.commit()
    return {"message": f"Medication logged as {req.get('status')}"}


@router.get("/medications/adherence", summary="Medication adherence summary")
async def medication_adherence(me=Depends(patient_only), db: AsyncSession = Depends(get_db)):
    from sqlalchemy import text
    result = await db.execute(
        text("""
            SELECT drug_name,
                   COUNT(*) FILTER (WHERE status='taken') as taken,
                   COUNT(*) FILTER (WHERE status='skipped') as skipped,
                   COUNT(*) as total
            FROM medication_logs
            WHERE patient_id = :pid
            GROUP BY drug_name
        """),
        {"pid": me["sub"]}
    )
    rows = result.fetchall()
    drugs = []
    for r in rows:
        total = r.total or 1
        adherence_pct = round((r.taken / total) * 100, 1)
        drugs.append({
            "drug_name": r.drug_name,
            "taken": r.taken, "skipped": r.skipped, "total": r.total,
            "adherence_percent": adherence_pct,
        })
    return {"adherence": drugs}
