"""
VitalOS Agent Inference Contract v1.0

Every Python agent MUST return an AgentInferenceResponse.
The TypeScript Orchestrator will REJECT any response that fails this schema.
This is the "Counsel → Judge" handshake.
"""

from pydantic import BaseModel, Field, field_validator
from typing import Optional, Literal

SCHEMA_VERSION = "1.0.0"
AGENT_VERSION = "1.0.0"

# Allowed clinical states an agent may suggest (subset of all states)
SUGGESTABLE_STATES = {"TRIAGE_COMPLETED", "ROUTING_PENDING", "ESCALATED", "CLOSED", "DOCTOR_REVIEW_PENDING"}


class AgentInferenceResponse(BaseModel):
    """
    Strict contract for agent → orchestrator suggestions.
    Agents suggest state, Orchestrator decides and commits.
    """
    case_id: str
    suggested_state: Literal[
        "TRIAGE_COMPLETED",
        "DOCTOR_REVIEW_PENDING",
        "ROUTING_PENDING",
        "ESCALATED",
        "CLOSED",
    ]
    confidence_score: float = Field(ge=0.0, le=1.0)
    risk_level: Literal["LOW", "MEDIUM", "HIGH", "EMERGENCY"]
    metadata: dict
    trace_id: str
    agent_version: str = AGENT_VERSION
    schema_version: str = SCHEMA_VERSION
    inference_trace: str

    @field_validator("suggested_state")
    @classmethod
    def validate_state(cls, v: str) -> str:
        if v not in SUGGESTABLE_STATES:
            raise ValueError(f"Agent cannot suggest state '{v}'. Allowed: {SUGGESTABLE_STATES}")
        return v

    @field_validator("confidence_score")
    @classmethod
    def validate_confidence(cls, v: float) -> float:
        if v < 0.5:
            raise ValueError(f"Confidence score {v} too low — agent should not suggest state change with < 50% confidence")
        return v
