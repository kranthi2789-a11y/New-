"""
auth/router.py — Authentication endpoints for all roles

POST /auth/register          — patient self-register with OTP
POST /auth/login/otp/send    — send OTP to mobile (patient)
POST /auth/login/otp/verify  — verify OTP → issue JWT
POST /auth/login/password    — email+password login (doctor/nurse/admin)
POST /auth/refresh            — rotate refresh token
POST /auth/logout             — revoke session
POST /auth/register/staff    — admin creates doctor/nurse account
"""

from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status, Body
from pydantic import BaseModel, EmailStr, validator
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from auth.models import User, ROLES
from auth.service import (
    create_otp_session, verify_otp_session,
    hash_password, verify_password,
    issue_access_token, issue_refresh_token, save_refresh_token,
    rotate_refresh_token, revoke_all_tokens,
    get_user_by_mobile, get_user_by_email, get_user_by_id,
)
from services.whatsapp import send_whatsapp
import logging

logger = logging.getLogger("vitalos.auth.router")
router = APIRouter(prefix="/auth", tags=["auth"])


# ── Request / Response Models ─────────────────────────────────

class OtpSendRequest(BaseModel):
    mobile: str

    @validator("mobile")
    def validate_mobile(cls, v):
        v = v.strip().replace(" ", "")
        if not v.startswith("+91"):
            v = "+91" + v.lstrip("0")
        if len(v) != 13:
            raise ValueError("Mobile must be 10 digits (Indian number)")
        return v


class OtpVerifyRequest(BaseModel):
    mobile: str
    otp: str
    name: Optional[str] = None       # Required only on first login (self-register)
    abha_id: Optional[str] = None


class PasswordLoginRequest(BaseModel):
    email: str
    password: str


class StaffRegisterRequest(BaseModel):
    name: str
    email: EmailStr
    mobile: str
    role: str
    password: str

    @validator("role")
    def validate_role(cls, v):
        allowed = ("doctor", "nurse", "emergency_responder", "admin")
        if v not in allowed:
            raise ValueError(f"Role must be one of {allowed}")
        return v


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: dict


class RefreshRequest(BaseModel):
    refresh_token: str


# ── Helper ────────────────────────────────────────────────────

def user_dict(u: User) -> dict:
    return {
        "id": u.id, "name": u.name, "role": u.role,
        "mobile": u.mobile, "email": u.email,
        "abha_id": u.abha_id, "is_verified": u.is_verified,
    }


def make_token_response(user: User) -> TokenResponse:
    access = issue_access_token(user)
    refresh_plain, refresh_hash = issue_refresh_token()
    return TokenResponse(
        access_token=access,
        refresh_token=refresh_plain,
        user=user_dict(user),
    ), refresh_hash


# ── PATIENT: Send OTP ─────────────────────────────────────────
@router.post("/login/otp/send", summary="Send OTP to patient mobile")
async def send_otp(req: OtpSendRequest, db: AsyncSession = Depends(get_db)):
    otp = await create_otp_session(db, req.mobile)

    # Send via WhatsApp (Twilio)
    msg = f"🏥 VitalOS\nYour login OTP is: *{otp}*\nValid for 10 minutes.\nDo not share this with anyone."
    try:
        await send_whatsapp(req.mobile, msg)
    except Exception as e:
        logger.warning(f"WhatsApp OTP send failed: {e} — OTP still valid")

    return {"message": "OTP sent to WhatsApp", "mobile": req.mobile[-4:].rjust(len(req.mobile), "*")}


# ── PATIENT: Verify OTP + issue JWT ──────────────────────────
@router.post("/login/otp/verify", response_model=TokenResponse, summary="Verify OTP → JWT")
async def verify_otp(req: OtpVerifyRequest, db: AsyncSession = Depends(get_db)):
    valid = await verify_otp_session(db, req.mobile, req.otp)
    if not valid:
        raise HTTPException(status_code=401, detail="Invalid or expired OTP")

    # Fetch or auto-create patient
    user = await get_user_by_mobile(db, req.mobile)
    if not user:
        if not req.name:
            raise HTTPException(status_code=400, detail="Name required for first-time registration")
        user = User(
            mobile=req.mobile, name=req.name,
            role="patient", is_verified=True, is_active=True,
            abha_id=req.abha_id,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)
        logger.info(f"New patient registered: {user.id}")
    else:
        user.is_verified = True
        await db.commit()

    resp, refresh_hash = make_token_response(user)
    await save_refresh_token(db, user.id, refresh_hash)
    logger.info(f"Patient login: {user.id} role={user.role}")
    return resp


# ── ALL STAFF: Email + Password login ────────────────────────
@router.post("/login/password", response_model=TokenResponse, summary="Staff login (doctor/nurse/admin)")
async def password_login(req: PasswordLoginRequest, db: AsyncSession = Depends(get_db)):
    user = await get_user_by_email(db, req.email)
    if not user or not user.password_hash:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    if not verify_password(req.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account suspended")

    resp, refresh_hash = make_token_response(user)
    await save_refresh_token(db, user.id, refresh_hash)
    logger.info(f"Staff login: {user.id} role={user.role}")
    return resp


# ── ADMIN: Create staff account ───────────────────────────────
@router.post("/register/staff", summary="Admin creates doctor/nurse/staff account")
async def register_staff(
    req: StaffRegisterRequest,
    db: AsyncSession = Depends(get_db),
):
    # Check duplicate
    existing = await get_user_by_email(db, req.email)
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")

    user = User(
        name=req.name, email=req.email,
        mobile=req.mobile, role=req.role,
        password_hash=hash_password(req.password),
        is_active=True, is_verified=True,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    logger.info(f"Staff account created: {user.id} role={user.role} by admin")
    return {"message": "Account created", "user_id": user.id, "role": user.role}


# ── Refresh token rotation ────────────────────────────────────
@router.post("/refresh", summary="Rotate access + refresh token")
async def refresh(req: RefreshRequest, db: AsyncSession = Depends(get_db)):
    result = await rotate_refresh_token(db, req.refresh_token)
    if not result:
        raise HTTPException(status_code=401, detail="Invalid or expired refresh token")
    user_id, new_access, new_refresh = result
    return {"access_token": new_access, "refresh_token": new_refresh, "token_type": "bearer"}


# ── Logout ─────────────────────────────────────────────────────
@router.post("/logout", summary="Revoke session")
async def logout(
    token_data: dict = Body(..., example={"user_id": "uuid-here"}),
    db: AsyncSession = Depends(get_db),
):
    await revoke_all_tokens(db, token_data.get("user_id", ""))
    return {"message": "Logged out successfully"}
