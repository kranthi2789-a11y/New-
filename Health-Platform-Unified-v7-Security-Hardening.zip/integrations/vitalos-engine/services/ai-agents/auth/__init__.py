# VitalOS auth package
