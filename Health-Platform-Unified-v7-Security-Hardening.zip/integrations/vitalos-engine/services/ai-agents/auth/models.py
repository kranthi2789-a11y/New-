"""
auth/models.py — User ORM model and role definitions
"""
from datetime import datetime
from typing import Optional
from sqlalchemy import String, Boolean, Text, DateTime, Numeric
from sqlalchemy.orm import Mapped, mapped_column
from core.database import Base
import uuid


ROLES = ('patient', 'doctor', 'nurse', 'emergency_responder', 'admin')


class User(Base):
    __tablename__ = "users"

    id:            Mapped[str]  = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    mobile:        Mapped[str]  = mapped_column(String(15), unique=True, nullable=False)
    email:         Mapped[Optional[str]] = mapped_column(String(120), unique=True)
    name:          Mapped[str]  = mapped_column(String(100), nullable=False)
    role:          Mapped[str]  = mapped_column(String(30), nullable=False)
    password_hash: Mapped[Optional[str]] = mapped_column(Text)
    abha_id:       Mapped[Optional[str]] = mapped_column(String(50), unique=True)
    hospital_id:   Mapped[Optional[str]] = mapped_column(String(36))
    is_active:     Mapped[bool] = mapped_column(Boolean, default=True)
    is_verified:   Mapped[bool] = mapped_column(Boolean, default=False)
    created_at:    Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at:    Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class OtpSession(Base):
    __tablename__ = "otp_sessions"

    id:         Mapped[str]  = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    mobile:     Mapped[str]  = mapped_column(String(15), nullable=False)
    otp_hash:   Mapped[str]  = mapped_column(Text, nullable=False)
    purpose:    Mapped[str]  = mapped_column(String(20), default='login')
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    used:       Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id:         Mapped[str]  = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id:    Mapped[str]  = mapped_column(String(36), nullable=False)
    token_hash: Mapped[str]  = mapped_column(Text, unique=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    revoked:    Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class FamilyContact(Base):
    __tablename__ = "family_contacts"

    id:             Mapped[str]  = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id:     Mapped[str]  = mapped_column(String(36), nullable=False)
    name:           Mapped[str]  = mapped_column(String(100), nullable=False)
    mobile:         Mapped[str]  = mapped_column(String(15), nullable=False)
    relation:       Mapped[str]  = mapped_column(String(50), nullable=False)
    is_primary_sos: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at:     Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
