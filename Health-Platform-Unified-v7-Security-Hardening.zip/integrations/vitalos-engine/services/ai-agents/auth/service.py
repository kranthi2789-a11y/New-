"""
auth/service.py — OTP generation, JWT issuance, bcrypt, token management

JWT Flows:
  Patient   → mobile OTP → JWT
  Doctor    → email + password → JWT
  Nurse     → email + password → JWT
  Admin     → email + password → JWT
  Emergency → pre-issued token or password → JWT
"""

import os
import secrets
import hashlib
from datetime import datetime, timedelta
from typing import Optional, Tuple

import bcrypt
import jwt
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update

from auth.models import User, OtpSession, RefreshToken
from core.config import settings
import logging

logger = logging.getLogger("vitalos.auth")

JWT_SECRET     = settings.JWT_SECRET
JWT_ALGORITHM  = "HS256"
ACCESS_TTL     = timedelta(hours=8)
REFRESH_TTL    = timedelta(days=30)
OTP_TTL        = timedelta(minutes=10)


# ── Password hashing ──────────────────────────────────────────
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=12)).decode()


def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode(), hashed.encode())


# ── OTP generation ────────────────────────────────────────────
def generate_otp() -> str:
    """6-digit OTP. In production, send via Twilio SMS."""
    return str(secrets.randbelow(900000) + 100000)


def hash_otp(otp: str) -> str:
    return hashlib.sha256(otp.encode()).hexdigest()


async def create_otp_session(
    db: AsyncSession, mobile: str, purpose: str = "login"
) -> str:
    """Create OTP session. Returns plaintext OTP for sending to user."""
    otp = generate_otp()
    otp_hash = hash_otp(otp)
    expires_at = datetime.utcnow() + OTP_TTL

    # Invalidate previous OTPs for same mobile
    await db.execute(
        update(OtpSession)
        .where(OtpSession.mobile == mobile, OtpSession.used == False)
        .values(used=True)
    )

    session = OtpSession(
        mobile=mobile, otp_hash=otp_hash,
        purpose=purpose, expires_at=expires_at
    )
    db.add(session)
    await db.commit()

    logger.info(f"OTP created for {mobile[-4:].rjust(len(mobile),'*')} | purpose={purpose}")
    # In dev mode log the OTP (NEVER in production)
    if settings.DEBUG:
        logger.info(f"[DEV ONLY] OTP for {mobile}: {otp}")

    return otp


async def verify_otp_session(
    db: AsyncSession, mobile: str, otp: str, purpose: str = "login"
) -> bool:
    """Verify OTP. Marks session as used on success."""
    otp_hash = hash_otp(otp)
    now = datetime.utcnow()

    result = await db.execute(
        select(OtpSession).where(
            OtpSession.mobile == mobile,
            OtpSession.otp_hash == otp_hash,
            OtpSession.purpose == purpose,
            OtpSession.used == False,
            OtpSession.expires_at > now,
        ).limit(1)
    )
    session = result.scalar_one_or_none()
    if not session:
        return False

    session.used = True
    await db.commit()
    return True


# ── JWT issuance ──────────────────────────────────────────────
def issue_access_token(user: User) -> str:
    payload = {
        "sub":      user.id,
        "role":     user.role,
        "name":     user.name,
        "mobile":   user.mobile,
        "exp":      datetime.utcnow() + ACCESS_TTL,
        "iat":      datetime.utcnow(),
        "type":     "access",
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def issue_refresh_token() -> Tuple[str, str]:
    """Returns (plaintext_token, hash_for_db)."""
    token = secrets.token_urlsafe(48)
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    return token, token_hash


async def save_refresh_token(db: AsyncSession, user_id: str, token_hash: str) -> None:
    rt = RefreshToken(
        user_id=user_id,
        token_hash=token_hash,
        expires_at=datetime.utcnow() + REFRESH_TTL,
    )
    db.add(rt)
    await db.commit()


async def rotate_refresh_token(
    db: AsyncSession, old_token: str
) -> Optional[Tuple[str, str, str]]:
    """
    Validate old refresh token, revoke it, issue new one.
    Returns (user_id, new_access_token, new_refresh_token) or None.
    """
    old_hash = hashlib.sha256(old_token.encode()).hexdigest()
    now = datetime.utcnow()

    result = await db.execute(
        select(RefreshToken).where(
            RefreshToken.token_hash == old_hash,
            RefreshToken.revoked == False,
            RefreshToken.expires_at > now,
        ).limit(1)
    )
    rt = result.scalar_one_or_none()
    if not rt:
        return None

    # Revoke old
    rt.revoked = True

    # Fetch user
    user_result = await db.execute(select(User).where(User.id == rt.user_id))
    user = user_result.scalar_one_or_none()
    if not user or not user.is_active:
        await db.commit()
        return None

    # Issue new pair
    new_access = issue_access_token(user)
    new_refresh, new_hash = issue_refresh_token()
    await save_refresh_token(db, user.id, new_hash)
    await db.commit()

    return user.id, new_access, new_refresh


async def revoke_all_tokens(db: AsyncSession, user_id: str) -> None:
    """Logout — revoke all refresh tokens for user."""
    await db.execute(
        update(RefreshToken)
        .where(RefreshToken.user_id == user_id, RefreshToken.revoked == False)
        .values(revoked=True)
    )
    await db.commit()


# ── User lookup helpers ───────────────────────────────────────
async def get_user_by_mobile(db: AsyncSession, mobile: str) -> Optional[User]:
    r = await db.execute(select(User).where(User.mobile == mobile))
    return r.scalar_one_or_none()


async def get_user_by_email(db: AsyncSession, email: str) -> Optional[User]:
    r = await db.execute(select(User).where(User.email == email))
    return r.scalar_one_or_none()


async def get_user_by_id(db: AsyncSession, user_id: str) -> Optional[User]:
    r = await db.execute(select(User).where(User.id == user_id))
    return r.scalar_one_or_none()
