"""
integrations/fhir_adapter.py — FHIR R4 + HL7 v2.x Integration Layer

Adapters for:
  1. FHIR R4 (HL7 FHIR) — standard for modern hospital interop (NHA ABDM)
  2. HL7 v2.x — legacy hospital systems (lab, radiology)
  3. External lab partner APIs (placeholder for real integrations)
  4. Pharmacy API adapter

All adapters are READ/WRITE bridges — they translate between
VitalOS internal format and external standards.
"""

from __future__ import annotations
import json
import logging
import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List

from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from main import verify_token

logger = logging.getLogger("vitalos.integrations")
integrations_router = APIRouter(prefix="/integrations", tags=["integrations"])


# ══════════════════════════════════════════
#  FHIR R4 ADAPTER
# ══════════════════════════════════════════

class FHIRAdapter:
    """
    Converts VitalOS data to FHIR R4 resources and back.
    FHIR base URL configurable via FHIR_SERVER_URL env var.
    """

    FHIR_VERSION = "4.0.1"

    @classmethod
    def patient_to_fhir(cls, patient: Dict) -> Dict:
        """Convert VitalOS patient dict to FHIR R4 Patient resource."""
        return {
            "resourceType": "Patient",
            "id": patient.get("id", str(uuid.uuid4())),
            "meta": {"versionId": "1", "lastUpdated": datetime.utcnow().isoformat()},
            "identifier": [
                {"system": "https://abdm.gov.in/abha", "value": patient.get("abha_id", "")},
                {"system": "https://vitalos.in/patient", "value": patient.get("id", "")},
            ],
            "name": [{"use": "official", "text": patient.get("name", "")}],
            "telecom": [
                {"system": "phone", "value": patient.get("mobile", ""), "use": "mobile"}
            ],
            "gender": patient.get("gender", "unknown").lower(),
            "birthDate": patient.get("birth_date", ""),
            "address": [{"use": "home", "city": patient.get("city", ""), "country": "IN"}],
        }

    @classmethod
    def prescription_to_fhir(cls, rx: Dict) -> Dict:
        """Convert VitalOS prescription to FHIR R4 MedicationRequest."""
        return {
            "resourceType": "MedicationRequest",
            "id": str(rx.get("id", uuid.uuid4())),
            "status": "active",
            "intent": "order",
            "subject": {"reference": f"Patient/{rx.get('patient_id', '')}"},
            "requester": {"display": rx.get("doctor_name", "")},
            "authoredOn": str(rx.get("created_at", datetime.utcnow().date())),
            "medicationCodeableConcept": {
                "coding": [
                    {"system": "http://www.nlm.nih.gov/research/umls/rxnorm",
                     "display": rx.get("drug_name", "")}
                ]
            },
            "dosageInstruction": [
                {
                    "text": f"{rx.get('dosage','')} {rx.get('frequency','')}",
                    "route": {"text": rx.get("route", "oral")},
                }
            ],
        }

    @classmethod
    def lab_report_to_fhir(cls, lab: Dict) -> Dict:
        """Convert VitalOS lab report to FHIR R4 DiagnosticReport."""
        return {
            "resourceType": "DiagnosticReport",
            "id": str(lab.get("id", uuid.uuid4())),
            "status": "final",
            "code": {
                "coding": [{"display": lab.get("report_type", "")}],
                "text": lab.get("report_type", ""),
            },
            "subject": {"reference": f"Patient/{lab.get('patient_id', '')}"},
            "effectiveDateTime": str(lab.get("created_at", datetime.utcnow())),
            "conclusion": lab.get("ai_explanation", ""),
            "conclusionCode": [
                {"coding": [{"display": flag}]} for flag in (lab.get("flags") or [])
            ],
        }

    @classmethod
    def vitals_to_fhir(cls, vitals: Dict) -> Dict:
        """Convert vitals reading to FHIR R4 Observation bundle."""
        observations = []
        mapping = [
            ("systolic_bp",  "55284-4", "Systolic BP", "mm[Hg]"),
            ("heart_rate",   "8867-4",  "Heart Rate",  "/min"),
            ("spo2",         "59408-5", "SpO2",        "%"),
            ("temperature",  "8310-5",  "Body Temp",   "Cel"),
            ("blood_glucose","2339-0",  "Blood Glucose","mg/dL"),
        ]
        for field, loinc, display, unit in mapping:
            val = vitals.get(field)
            if val:
                observations.append({
                    "resourceType": "Observation",
                    "id": str(uuid.uuid4()),
                    "status": "final",
                    "code": {
                        "coding": [{"system": "http://loinc.org",
                                    "code": loinc, "display": display}]
                    },
                    "subject": {"reference": f"Patient/{vitals.get('patient_id','')}"},
                    "valueQuantity": {"value": val, "unit": unit},
                    "effectiveDateTime": str(vitals.get("recorded_at", datetime.utcnow())),
                })
        return {"resourceType": "Bundle", "type": "collection",
                "entry": [{"resource": obs} for obs in observations]}


# ══════════════════════════════════════════
#  HL7 V2 ADAPTER
# ══════════════════════════════════════════

class HL7Adapter:
    """
    HL7 v2.x message builder/parser for lab orders and results.
    Used for legacy LIS/RIS integration.
    """

    @classmethod
    def build_oru_r01(cls, patient_id: str, order_id: str,
                      lab_results: List[Dict]) -> str:
        """
        Build HL7 v2.5 ORU^R01 (Observation Result) message.
        Used to send lab results from LIS to VitalOS.
        """
        ts = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        msg_id = str(uuid.uuid4())[:8].upper()

        lines = [
            f"MSH|^~\\&|VITALOS|HOSPITAL|LIS|LAB|{ts}||ORU^R01^ORU_R01|{msg_id}|P|2.5",
            f"PID|1||{patient_id}^^^VITALOS||PATIENT^NAME||||||||||",
            f"OBR|1|{order_id}|{order_id}|LAB^Lab Order|||{ts}",
        ]
        for i, result in enumerate(lab_results, 1):
            value = result.get("value", "")
            unit = result.get("unit", "")
            ref_range = result.get("reference_range", "")
            abnormal_flag = result.get("abnormal_flag", "N")
            test_name = result.get("test_name", "")
            lines.append(
                f"OBX|{i}|NM|{test_name}^{test_name}^L||{value}|{unit}|{ref_range}|{abnormal_flag}|||F"
            )

        return "\r".join(lines)

    @classmethod
    def parse_oru_r01(cls, hl7_message: str) -> Dict:
        """Parse HL7 ORU^R01 message → VitalOS lab result format."""
        lines = hl7_message.strip().split("\r")
        result = {"test_results": [], "patient_id": "", "order_id": ""}

        for line in lines:
            segs = line.split("|")
            seg_type = segs[0] if segs else ""

            if seg_type == "PID" and len(segs) > 3:
                result["patient_id"] = segs[3].split("^")[0]
            elif seg_type == "OBR" and len(segs) > 2:
                result["order_id"] = segs[2]
            elif seg_type == "OBX" and len(segs) > 8:
                result["test_results"].append({
                    "test_name": segs[3].split("^")[0] if len(segs) > 3 else "",
                    "value": segs[5] if len(segs) > 5 else "",
                    "unit": segs[6] if len(segs) > 6 else "",
                    "reference_range": segs[7] if len(segs) > 7 else "",
                    "abnormal_flag": segs[8] if len(segs) > 8 else "N",
                })
        return result


# ══════════════════════════════════════════
#  API ROUTES
# ══════════════════════════════════════════

@integrations_router.get("/fhir/patient/{patient_id}",
                          summary="Export patient as FHIR R4 Patient resource")
async def fhir_patient(
    patient_id: str,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if me["role"] not in ("doctor", "admin", "patient"):
        raise HTTPException(403, "Access denied")
    from sqlalchemy import text
    result = await db.execute(text(
        "SELECT id, name, mobile, abha_id FROM users WHERE id=:pid"
    ), {"pid": patient_id})
    row = result.fetchone()
    if not row:
        raise HTTPException(404, "Patient not found")
    return FHIRAdapter.patient_to_fhir(dict(row._mapping))


@integrations_router.post("/hl7/ingest", summary="Ingest HL7 ORU^R01 lab result")
async def ingest_hl7(
    body: dict = Body(..., example={"hl7_message": "MSH|..."}),
    me=Depends(verify_token),
):
    if me["role"] not in ("admin", "nurse", "doctor"):
        raise HTTPException(403, "Access denied")
    parsed = HL7Adapter.parse_oru_r01(body.get("hl7_message", ""))
    return {"parsed": parsed, "ingested": True, "standard": "HL7 v2.5 ORU^R01"}


@integrations_router.get("/fhir/bundle/{patient_id}",
                          summary="Full FHIR R4 bundle for patient")
async def fhir_bundle(
    patient_id: str,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if me["role"] not in ("doctor", "admin"):
        raise HTTPException(403, "Doctor/Admin only")
    from sqlalchemy import text
    user_r = await db.execute(text(
        "SELECT id, name, mobile, abha_id FROM users WHERE id=:pid"
    ), {"pid": patient_id})
    user = user_r.fetchone()
    if not user:
        raise HTTPException(404, "Patient not found")

    patient_fhir = FHIRAdapter.patient_to_fhir(dict(user._mapping))

    return {
        "resourceType": "Bundle",
        "type": "collection",
        "id": str(uuid.uuid4()),
        "meta": {"lastUpdated": datetime.utcnow().isoformat()},
        "entry": [{"resource": patient_fhir}],
        "fhir_version": FHIRAdapter.FHIR_VERSION,
        "abdm_compliant": True,
    }
