"""
clinical_specialties/specialty_engine.py
Specialty-aware clinical rules that enrich every case with
domain-specific validation, dosage rules, and workflow steps.

Called AFTER protocol check, BEFORE agent suggestion is accepted.
"""

from __future__ import annotations
import logging
from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass, field

logger = logging.getLogger("vitalos.specialties")


@dataclass
class SpecialtyEnrichment:
    specialty: str
    flags: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    workflow_steps: List[str] = field(default_factory=list)
    dosage_adjustments: List[str] = field(default_factory=list)
    next_review_days: Optional[int] = None
    audit_fields: Dict[str, Any] = field(default_factory=dict)


class BaseSpecialty(ABC):
    name: str = "BASE"
    icd10_prefixes: List[str] = []  # ICD-10 code prefixes this specialty handles

    @abstractmethod
    def validate(self, case_data: Dict) -> Tuple[bool, List[str]]:
        """Returns (is_valid, list_of_issues)"""
        ...

    @abstractmethod
    def enrich(self, case_data: Dict) -> SpecialtyEnrichment:
        """Return enriched case data with specialty-specific insights."""
        ...

    def get_workflow(self) -> List[str]:
        return []

    def _age(self, d: Dict) -> int:
        return int(d.get("age") or 40)

    def _vitals(self, d: Dict) -> Dict:
        return d.get("vitals") or {}

    def _medications(self, d: Dict) -> List[Dict]:
        return d.get("medications") or []


# ── CARDIOLOGY ────────────────────────────────────────────────
class CardiologySpecialty(BaseSpecialty):
    name = "cardiology"
    icd10_prefixes = ["I"]

    def validate(self, case_data: Dict) -> Tuple[bool, List[str]]:
        issues = []
        v = self._vitals(case_data)
        sbp = v.get("systolic_bp") or 0
        dbp = v.get("diastolic_bp") or 0
        if sbp > 180 or dbp > 110:
            issues.append(f"Hypertensive crisis: {sbp}/{dbp}")
        for med in self._medications(case_data):
            name_l = (med.get("drug_name") or "").lower()
            if "nsaid" in name_l or "ibuprofen" in name_l:
                issues.append(f"NSAID contraindicated in heart failure: {med.get('drug_name')}")
        return (len(issues) == 0, issues)

    def enrich(self, case_data: Dict) -> SpecialtyEnrichment:
        v = self._vitals(case_data)
        sbp = v.get("systolic_bp") or 120
        hr = v.get("heart_rate") or 80
        flags = []
        if sbp > 160: flags.append("HYPERTENSION_UNCONTROLLED")
        if hr > 100: flags.append("TACHYCARDIA")
        if hr < 50: flags.append("BRADYCARDIA")
        return SpecialtyEnrichment(
            specialty=self.name,
            flags=flags,
            workflow_steps=self.get_workflow(),
            next_review_days=7 if flags else 30,
            audit_fields={"sbp": sbp, "hr": hr},
        )

    def get_workflow(self) -> List[str]:
        return ["ECG_12_LEAD","TROPONIN_BNPNP","ECHO_IF_INDICATED",
                "RISK_STRATIFICATION","CARDIOLOGY_CONSULT","DISCHARGE_OR_ADMIT"]


# ── PEDIATRICS ────────────────────────────────────────────────
class PediatricsSpecialty(BaseSpecialty):
    name = "pediatrics"
    icd10_prefixes = []  # Age-based, not ICD prefix

    # India immunisation schedule milestones (age in months)
    VACCINE_SCHEDULE = {
        0: ["BCG", "OPV-0", "Hep-B-1"],
        6: ["OPV-1", "Pentavalent-1", "RVV-1", "PCV-1"],
        10: ["OPV-2", "Pentavalent-2", "RVV-2", "PCV-2"],
        14: ["OPV-3", "Pentavalent-3", "PCV-3"],
        24: ["OPV-B", "MR-1", "JE-1"],
        60: ["DPT-B1", "OPV-B1", "MR-2"],
    }

    def validate(self, case_data: Dict) -> Tuple[bool, List[str]]:
        issues = []
        age_months = int(case_data.get("age_months") or (self._age(case_data) * 12))
        weight_kg = case_data.get("weight_kg")
        for med in self._medications(case_data):
            dosage_str = str(med.get("dosage") or "")
            if "mg/kg" not in dosage_str and weight_kg:
                issues.append(f"Paediatric dosage not weight-based: {med.get('drug_name')} {dosage_str}")
            if "aspirin" in (med.get("drug_name") or "").lower() and age_months < 192:
                issues.append(f"Aspirin contraindicated <16yr (Reye's): {med.get('drug_name')}")
        return (len(issues) == 0, issues)

    def enrich(self, case_data: Dict) -> SpecialtyEnrichment:
        age_months = int(case_data.get("age_months") or (self._age(case_data) * 12))
        due = []
        for milestone, vaccines in self.VACCINE_SCHEDULE.items():
            if age_months >= milestone:
                due.extend(vaccines)
        return SpecialtyEnrichment(
            specialty=self.name,
            flags=["PAEDIATRIC_PATIENT"],
            warnings=["Weight-based dosing required for all medications"],
            workflow_steps=self.get_workflow(),
            dosage_adjustments=["All doses must be calculated as mg/kg"],
            audit_fields={"age_months": age_months, "vaccines_due_check": due[:5]},
        )

    def get_workflow(self) -> List[str]:
        return ["WEIGHT_MEASUREMENT","GROWTH_CHART_PLOT","DEVELOPMENTAL_SCREEN",
                "VACCINATION_STATUS","PAED_CONSULT_IF_COMPLEX","PARENT_COUNSELLING"]


# ── ONCOLOGY ──────────────────────────────────────────────────
class OncologySpecialty(BaseSpecialty):
    name = "oncology"
    icd10_prefixes = ["C", "D"]

    def validate(self, case_data: Dict) -> Tuple[bool, List[str]]:
        issues = []
        chemo_cycle = case_data.get("chemo_cycle_number")
        if chemo_cycle:
            v = self._vitals(case_data)
            anc = case_data.get("anc")  # Absolute neutrophil count
            if anc is not None and anc < 1000:
                issues.append(f"Neutropenia (ANC {anc}) — chemo hold / G-CSF required")
        return (len(issues) == 0, issues)

    def enrich(self, case_data: Dict) -> SpecialtyEnrichment:
        stage = case_data.get("cancer_stage")
        cycle = case_data.get("chemo_cycle_number")
        return SpecialtyEnrichment(
            specialty=self.name,
            flags=["ONCOLOGY_PATIENT"],
            warnings=["Immunocompromised — infection risk elevated","Palliative care goals must be documented"],
            workflow_steps=self.get_workflow(stage),
            audit_fields={"stage": stage, "chemo_cycle": cycle},
        )

    def get_workflow(self, stage: Optional[str] = None) -> List[str]:
        base = ["DIAGNOSIS_CONFIRMATION","STAGING","MDT_MEETING","TREATMENT_PLAN"]
        if stage in ("III", "IV"):
            base += ["PALLIATIVE_CARE_CONSULT", "GOALS_OF_CARE_DOCUMENT"]
        return base + ["CHEMO_CYCLE_ASSESSMENT","TOXICITY_MONITORING","FOLLOW_UP_IMAGING"]


# ── ENDOCRINOLOGY ─────────────────────────────────────────────
class EndocrinologySpecialty(BaseSpecialty):
    name = "endocrinology"
    icd10_prefixes = ["E"]

    HBA1C_THRESHOLDS = {"normal": 5.7, "prediabetes": 6.4, "diabetes": 6.5}

    def validate(self, case_data: Dict) -> Tuple[bool, List[str]]:
        issues = []
        labs = case_data.get("lab_values") or {}
        hba1c = labs.get("hba1c")
        if hba1c and hba1c > 10.0:
            issues.append(f"HbA1c critically elevated: {hba1c}% — DKA risk")
        glucose = (self._vitals(case_data).get("blood_glucose") or
                   labs.get("fasting_glucose") or 0)
        if glucose > 400:
            issues.append(f"Hyperglycaemic emergency: glucose {glucose} mg/dL")
        if glucose > 0 and glucose < 60:
            issues.append(f"Hypoglycaemia: glucose {glucose} mg/dL")
        return (len(issues) == 0, issues)

    def enrich(self, case_data: Dict) -> SpecialtyEnrichment:
        labs = case_data.get("lab_values") or {}
        hba1c = labs.get("hba1c") or 0
        flags = []
        if hba1c > 9: flags.append("POOR_GLYCAEMIC_CONTROL")
        elif hba1c > 6.5: flags.append("DIABETES_SUBOPTIMAL")
        return SpecialtyEnrichment(
            specialty=self.name,
            flags=flags,
            workflow_steps=self.get_workflow(),
            next_review_days=90,
            audit_fields={"hba1c": hba1c},
        )

    def get_workflow(self) -> List[str]:
        return ["FASTING_GLUCOSE","HBA1C","LIPID_PROFILE","RENAL_FUNCTION",
                "URINE_ACR","FUNDOSCOPY","FOOT_EXAM","DIETARY_COUNSELLING"]


# ── GYNECOLOGY / OBSTETRICS ──────────────────────────────────
class GynecologySpecialty(BaseSpecialty):
    name = "gynecology"
    icd10_prefixes = ["O", "N"]

    PREGNANCY_SCANS = {12: "Dating + NT scan", 20: "Anomaly scan", 28: "Growth scan", 34: "Presentation scan"}

    def validate(self, case_data: Dict) -> Tuple[bool, List[str]]:
        issues = []
        weeks = case_data.get("pregnancy_weeks")
        for med in self._medications(case_data):
            name_l = (med.get("drug_name") or "").lower()
            if weeks and any(x in name_l for x in ["warfarin","methotrexate","thalidomide"]):
                issues.append(f"Teratogenic drug in pregnancy: {med.get('drug_name')}")
        sbp = self._vitals(case_data).get("systolic_bp") or 0
        if weeks and weeks > 20 and sbp > 140:
            issues.append(f"Pre-eclampsia risk: BP {sbp} at {weeks}wks — refer OB immediately")
        return (len(issues) == 0, issues)

    def enrich(self, case_data: Dict) -> SpecialtyEnrichment:
        weeks = case_data.get("pregnancy_weeks") or 0
        due_scans = [f"Wk{w}: {s}" for w, s in self.PREGNANCY_SCANS.items() if weeks <= w <= weeks + 4]
        return SpecialtyEnrichment(
            specialty=self.name,
            flags=["OBSTETRIC_PATIENT"] if weeks else [],
            workflow_steps=self.get_workflow(weeks),
            audit_fields={"pregnancy_weeks": weeks, "upcoming_scans": due_scans},
        )

    def get_workflow(self, weeks: int = 0) -> List[str]:
        base = ["BOOKING_BLOODS","BP_URINE","SCAN_SCHEDULE","IRON_FOLIC_ACID"]
        if weeks >= 36: base.append("DELIVERY_PLANNING")
        return base


# ── NEUROLOGY ─────────────────────────────────────────────────
class NeurologySpecialty(BaseSpecialty):
    name = "neurology"
    icd10_prefixes = ["G", "F"]

    def validate(self, case_data: Dict) -> Tuple[bool, List[str]]:
        issues = []
        v = self._vitals(case_data)
        gcs = v.get("gcs") or 15
        if gcs <= 8:
            issues.append(f"GCS≤8 ({gcs}) — airway at risk, ICU input needed")
        for med in self._medications(case_data):
            if "anticoagulant" in str(med.get("class") or "").lower():
                issues.append("Anticoagulant + stroke: confirm type before dosing")
        return (len(issues) == 0, issues)

    def enrich(self, case_data: Dict) -> SpecialtyEnrichment:
        v = self._vitals(case_data)
        gcs = v.get("gcs") or 15
        flags = ["ALTERED_CONSCIOUSNESS"] if gcs < 15 else []
        return SpecialtyEnrichment(
            specialty=self.name,
            flags=flags,
            workflow_steps=self.get_workflow(),
            audit_fields={"gcs": gcs},
        )

    def get_workflow(self) -> List[str]:
        return ["NEUROLOGICAL_EXAM","CT_HEAD","MRI_IF_INDICATED",
                "EEG_IF_SEIZURE","NEUROLOGY_CONSULT","REHABILITATION_PLAN"]


# ── ORTHOPEDICS ───────────────────────────────────────────────
class OrthopedicsSpecialty(BaseSpecialty):
    name = "orthopedics"
    icd10_prefixes = ["M", "S"]

    def validate(self, case_data: Dict) -> Tuple[bool, List[str]]:
        issues = []
        age = self._age(case_data)
        if age > 65 and "hip fracture" in self._vitals(case_data):
            issues.append("Hip fracture >65yr — orthogeriatrics input required")
        return (len(issues) == 0, issues)

    def enrich(self, case_data: Dict) -> SpecialtyEnrichment:
        return SpecialtyEnrichment(
            specialty=self.name,
            flags=[],
            workflow_steps=self.get_workflow(),
            next_review_days=14,
        )

    def get_workflow(self) -> List[str]:
        return ["XRAY_AFFECTED_JOINT","FRACTURE_CLASSIFICATION",
                "ORTHO_CONSULT","SURGICAL_VS_CONSERVATIVE",
                "DVT_PROPHYLAXIS","PHYSIOTHERAPY_PLAN","FOLLOW_UP_XRAY"]


# ── PULMONOLOGY ───────────────────────────────────────────────
class PulmonologySpecialty(BaseSpecialty):
    name = "pulmonology"
    icd10_prefixes = ["J"]

    def validate(self, case_data: Dict) -> Tuple[bool, List[str]]:
        issues = []
        v = self._vitals(case_data)
        spo2 = v.get("spo2") or 98
        rr = v.get("respiratory_rate") or 16
        if spo2 < 92: issues.append(f"SpO2 {spo2}% — supplemental O2 required")
        if rr > 25: issues.append(f"Respiratory rate {rr} — respiratory failure risk")
        return (len(issues) == 0, issues)

    def enrich(self, case_data: Dict) -> SpecialtyEnrichment:
        v = self._vitals(case_data)
        spo2 = v.get("spo2") or 98
        return SpecialtyEnrichment(
            specialty=self.name,
            flags=["RESPIRATORY_COMPROMISE"] if spo2 < 94 else [],
            workflow_steps=self.get_workflow(),
            audit_fields={"spo2": spo2},
        )

    def get_workflow(self) -> List[str]:
        return ["ABG_ANALYSIS","CXR","SPIROMETRY_IF_STABLE",
                "O2_THERAPY_TARGET_SpO2_94_98","PULM_CONSULT","BRONCHODILATOR_TRIAL"]


# ═══════════════════════════════════════════════
#  SPECIALTY REGISTRY
# ═══════════════════════════════════════════════
class SpecialtyRegistry:
    _registry: Dict[str, BaseSpecialty] = {
        "cardiology":     CardiologySpecialty(),
        "pediatrics":     PediatricsSpecialty(),
        "oncology":       OncologySpecialty(),
        "endocrinology":  EndocrinologySpecialty(),
        "gynecology":     GynecologySpecialty(),
        "neurology":      NeurologySpecialty(),
        "orthopedics":    OrthopedicsSpecialty(),
        "pulmonology":    PulmonologySpecialty(),
    }

    @classmethod
    def get(cls, specialty: str) -> Optional[BaseSpecialty]:
        return cls._registry.get(specialty.lower())

    @classmethod
    def validate_and_enrich(cls, specialty: str, case_data: Dict) -> Dict:
        """
        Main entry point called from orchestrator hook.
        Returns enriched case_data with specialty fields merged in.
        """
        spec = cls.get(specialty)
        if not spec:
            return case_data

        is_valid, issues = spec.validate(case_data)
        enrichment = spec.enrich(case_data)

        case_data.setdefault("data", {})
        case_data["data"]["specialty"] = specialty
        case_data["data"]["specialty_valid"] = is_valid
        case_data["data"]["specialty_issues"] = issues
        case_data["data"]["specialty_flags"] = enrichment.flags
        case_data["data"]["specialty_warnings"] = enrichment.warnings
        case_data["data"]["specialty_workflow"] = enrichment.workflow_steps
        case_data["data"]["specialty_dosage_notes"] = enrichment.dosage_adjustments

        if issues:
            logger.warning(
                f"Specialty validation issues: specialty={specialty} "
                f"case={case_data.get('case_id','?')} issues={issues}"
            )

        return case_data

    @classmethod
    def list_specialties(cls) -> List[str]:
        return list(cls._registry.keys())
