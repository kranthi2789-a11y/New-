"""
api/routes.py — All VitalOS AI Agent endpoints
"""

from fastapi import APIRouter, Depends, UploadFile, File
from pydantic import BaseModel
from typing import Optional, List
import base64

from agents.orchestrator import AgentOrchestrator
from main import verify_token

router = APIRouter()


# ── Request Models ─────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str
    session_id: str = "default"
    language: str = "english"
    patient_context: Optional[dict] = None

class PrescriptionRequest(BaseModel):
    text: str
    patient_age: Optional[int] = None
    patient_conditions: Optional[List[str]] = []
    wake_time: str = "07:00"
    breakfast_time: str = "08:00"
    dinner_time: str = "20:00"

class LabRequest(BaseModel):
    text: str
    patient_age: Optional[int] = None
    patient_gender: str = "unknown"
    patient_conditions: Optional[List[str]] = []
    image_base64: Optional[str] = None

class ReminderRequest(BaseModel):
    medications: List[dict]
    patient_name: str = "Patient"
    wake_time: str = "07:00"
    breakfast_time: str = "08:00"
    lunch_time: str = "13:00"
    dinner_time: str = "20:00"
    sleep_time: str = "22:00"

class InsuranceRequest(BaseModel):
    policy_details: str
    procedure: str
    hospital_type: str = "private"
    patient_income_category: Optional[str] = None
    estimated_cost: Optional[str] = None

class RiskRequest(BaseModel):
    age: int = 40
    gender: str = "male"
    vitals: Optional[dict] = None
    lab_history: Optional[List[dict]] = []
    conditions: Optional[List[str]] = []
    lifestyle: Optional[dict] = None

class HospitalRequest(BaseModel):
    symptoms: str
    location: str = "Hyderabad"
    insurance: Optional[str] = None
    specialty: Optional[str] = None

class DoctorRequest(BaseModel):
    chief_complaint: str
    history: str = ""
    examination: str = ""
    diagnosis: str = ""
    doctor_notes: str = ""

class EmergencyRequest(BaseModel):
    symptoms: str
    location: str = "unknown"
    patient_profile: Optional[dict] = None

class FamilyRequest(BaseModel):
    family_members: List[dict]
    query: str

class CostRequest(BaseModel):
    medications: Optional[List[dict]] = []
    procedure: Optional[str] = None
    budget: Optional[str] = None
    location: str = "India"

class PharmacyRequest(BaseModel):
    drugs: List[str]
    location: str = "Hyderabad"

class FollowUpRequest(BaseModel):
    diagnosis: str
    visit_date: str
    medications: Optional[List[str]] = []
    patient_name: str = "Patient"
    doctor_name: str = "your doctor"

class ChronicRequest(BaseModel):
    condition: str
    patient_data: dict
    monitoring_history: Optional[List[dict]] = []

class PreventiveRequest(BaseModel):
    age: int
    gender: str
    conditions: Optional[List[str]] = []
    location: str = "India"

class BillRequest(BaseModel):
    bill_text: str
    hospital_type: str = "private"
    insurance_type: str = "none"


# ── Endpoints ──────────────────────────────────────────────────

@router.get("/agents")
async def list_agents(_user=Depends(verify_token)):
    return {"agents": AgentOrchestrator.list_agents(), "total": 16, "schema_version": "1.0.0"}

@router.post("/chat")
async def chat(req: ChatRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("chat").run(
        message=req.message, session_id=req.session_id,
        language=req.language, patient_context=req.patient_context,
    )

@router.post("/prescription/parse")
async def parse_prescription(req: PrescriptionRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("prescription").run(
        prescription_text=req.text, patient_age=req.patient_age,
        patient_conditions=req.patient_conditions, wake_time=req.wake_time,
        breakfast_time=req.breakfast_time, dinner_time=req.dinner_time,
    )

@router.post("/prescription/upload")
async def upload_prescription(file: UploadFile = File(...), _user=Depends(verify_token)):
    contents = await file.read()
    b64 = base64.b64encode(contents).decode()
    return await AgentOrchestrator.get("prescription").run(
        prescription_text=f"[Image: {file.filename}]", image_base64=b64,
    )

@router.post("/lab/interpret")
async def interpret_lab(req: LabRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("lab").run(
        lab_text=req.text, patient_age=req.patient_age,
        patient_gender=req.patient_gender, patient_conditions=req.patient_conditions,
        image_base64=req.image_base64,
    )

@router.post("/reminders/schedule")
async def schedule_reminders(req: ReminderRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("reminder").run(
        medications=req.medications, patient_name=req.patient_name,
        wake_time=req.wake_time, breakfast_time=req.breakfast_time,
        lunch_time=req.lunch_time, dinner_time=req.dinner_time, sleep_time=req.sleep_time,
    )

@router.post("/insurance/analyze")
async def analyze_insurance(req: InsuranceRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("insurance").run(
        policy_details=req.policy_details, procedure=req.procedure,
        hospital_type=req.hospital_type, patient_income_category=req.patient_income_category,
        estimated_cost=req.estimated_cost,
    )

@router.post("/health/risk")
async def health_risk(req: RiskRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("risk").run(
        age=req.age, gender=req.gender, vitals=req.vitals,
        lab_history=req.lab_history, conditions=req.conditions, lifestyle=req.lifestyle,
    )

@router.post("/hospital/find")
async def find_hospital(req: HospitalRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("hospital").run(
        symptoms=req.symptoms, location=req.location,
        insurance=req.insurance, specialty=req.specialty,
    )

@router.post("/doctor/note")
async def generate_soap(req: DoctorRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("doctor").run(
        chief_complaint=req.chief_complaint, history=req.history,
        examination=req.examination, diagnosis=req.diagnosis, doctor_notes=req.doctor_notes,
    )

@router.post("/emergency/triage")
async def emergency_triage(req: EmergencyRequest):
    # Emergency endpoint — no auth required, never blocked by Safe Mode
    return await AgentOrchestrator.get("emergency").run(
        symptoms=req.symptoms, location=req.location, patient_profile=req.patient_profile,
    )

@router.post("/family/health")
async def family_health(req: FamilyRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("family").run(
        family_members=req.family_members, query=req.query,
    )

@router.post("/cost/optimize")
async def optimize_cost(req: CostRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("cost").run(
        medications=req.medications, procedure=req.procedure,
        budget=req.budget, location=req.location,
    )

@router.post("/pharmacy/find")
async def find_pharmacy(req: PharmacyRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("pharmacy").run(
        drugs=req.drugs, location=req.location,
    )

@router.post("/followup/schedule")
async def schedule_followup(req: FollowUpRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("followup").run(
        diagnosis=req.diagnosis, visit_date=req.visit_date,
        medications=req.medications, patient_name=req.patient_name,
        doctor_name=req.doctor_name,
    )

@router.post("/chronic/monitor")
async def monitor_chronic(req: ChronicRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("chronic").run(
        condition=req.condition, patient_data=req.patient_data,
        monitoring_history=req.monitoring_history,
    )

@router.post("/preventive/plan")
async def preventive_plan(req: PreventiveRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("preventive").run(
        age=req.age, gender=req.gender,
        conditions=req.conditions, location=req.location,
    )

@router.post("/bill/analyze")
async def analyze_bill(req: BillRequest, _user=Depends(verify_token)):
    return await AgentOrchestrator.get("bill").run(
        bill_text=req.bill_text, hospital_type=req.hospital_type,
        insurance_type=req.insurance_type,
    )

@router.delete("/chat/session/{session_id}")
async def clear_session(session_id: str, _user=Depends(verify_token)):
    AgentOrchestrator.get("chat").clear_session(session_id)
    return {"cleared": session_id}
