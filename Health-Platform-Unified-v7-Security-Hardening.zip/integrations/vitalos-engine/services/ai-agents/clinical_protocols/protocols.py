"""
clinical_protocols/protocols.py
Auto-triggering clinical protocol engine.

Protocols sit ABOVE agent suggestions.
If a protocol triggers → it overrides any agent suggestion and forces
the Orchestrator into the correct escalation path.

Hierarchy: Protocol > CDSS > Agent Suggestion
"""

from __future__ import annotations
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime

logger = logging.getLogger("vitalos.protocols")


@dataclass
class ProtocolTrigger:
    """Returned when a protocol fires."""
    protocol_name: str
    severity: str                     # "CRITICAL" | "HIGH" | "MODERATE"
    triggered_by: List[str]           # which criteria fired
    forced_state: Optional[str]       # override suggested_state if set
    forced_risk: Optional[str]        # override risk_level if set
    mandatory_actions: List[str]      # steps that MUST happen
    time_target_seconds: int          # SLA for this protocol
    escalate_immediately: bool
    audit_note: str


class BaseProtocol(ABC):
    """
    Every clinical protocol extends this.
    Protocol.evaluate() is called BEFORE the Orchestrator commits any transition.
    If a trigger is returned, the Orchestrator MUST honour it.
    """

    name: str = "BASE"
    version: str = "1.0.0"

    @abstractmethod
    def evaluate(self, case_data: Dict[str, Any]) -> Optional[ProtocolTrigger]:
        """
        Evaluate whether this protocol applies to the case.
        Returns ProtocolTrigger if it fires, None otherwise.
        case_data keys: vitals, symptoms, diagnosis, risk_level, current_state, age, gender, flags
        """
        ...

    def _vitals(self, case_data: Dict) -> Dict:
        return case_data.get("vitals") or {}

    def _age(self, case_data: Dict) -> int:
        return int(case_data.get("age") or 40)

    def _symptoms(self, case_data: Dict) -> str:
        return str(case_data.get("symptoms") or "").lower()


# ═══════════════════════════════════════════════
#  SEPSIS PROTOCOL  (qSOFA-based)
# ═══════════════════════════════════════════════
class SepsisProtocol(BaseProtocol):
    """
    qSOFA criteria: ≥2 of:
      1. Respiratory rate ≥22/min
      2. Altered mentation (GCS <15)
      3. Systolic BP ≤100 mmHg
    Plus: suspected infection
    Sepsis-3: organ dysfunction + suspected infection
    """
    name = "SEPSIS_PROTOCOL"

    SEPSIS_KEYWORDS = [
        "fever", "infection", "sepsis", "bacteremia", "pneumonia",
        "uti", "wound infection", "cellulitis", "meningitis",
        "बुखार", "संक्रमण",
    ]

    def evaluate(self, case_data: Dict) -> Optional[ProtocolTrigger]:
        v = self._vitals(case_data)
        symptoms = self._symptoms(case_data)

        qsofa_score = 0
        criteria_met = []

        rr = v.get("respiratory_rate") or 0
        sbp = v.get("systolic_bp") or 120
        gcs = v.get("gcs") or 15
        temp = v.get("temperature") or 37.0
        hr = v.get("heart_rate") or 80
        spo2 = v.get("spo2") or 98

        if rr >= 22:
            qsofa_score += 1; criteria_met.append(f"RR≥22 ({rr})")
        if sbp <= 100:
            qsofa_score += 1; criteria_met.append(f"SBP≤100 ({sbp})")
        if gcs < 15:
            qsofa_score += 1; criteria_met.append(f"GCS<15 ({gcs})")

        has_infection_context = any(kw in symptoms for kw in self.SEPSIS_KEYWORDS)

        # Septic shock: hypotension + lactate (proxy: low SpO2 + hypotension)
        septic_shock = sbp < 90 and spo2 < 94 and temp > 38.0
        if septic_shock:
            criteria_met.append("SEPTIC_SHOCK_SUSPECTED")

        if (qsofa_score >= 2 and has_infection_context) or septic_shock:
            sev = "CRITICAL" if septic_shock else "HIGH"
            return ProtocolTrigger(
                protocol_name=self.name,
                severity=sev,
                triggered_by=criteria_met,
                forced_state="ESCALATED" if septic_shock else None,
                forced_risk="EMERGENCY" if septic_shock else "HIGH",
                mandatory_actions=[
                    "Blood cultures x2 within 1hr",
                    "IV access + fluid resuscitation 30mL/kg",
                    "Broad-spectrum antibiotics within 1hr",
                    "Lactate measurement",
                    "Oxygen target SpO2 ≥94%",
                    "ICU team notification",
                ],
                time_target_seconds=3600,  # 1hr bundle
                escalate_immediately=septic_shock,
                audit_note=f"qSOFA={qsofa_score} | criteria={criteria_met} | shock={septic_shock}",
            )
        return None


# ═══════════════════════════════════════════════
#  STROKE PROTOCOL  (FAST)
# ═══════════════════════════════════════════════
class StrokeProtocol(BaseProtocol):
    """
    FAST: Face drooping, Arm weakness, Speech difficulty, Time to call
    Time to CT ≤ 25 min | Time to tPA ≤ 60 min (golden hour)
    """
    name = "STROKE_PROTOCOL"

    STROKE_KEYWORDS = [
        "facial droop", "arm weakness", "speech difficulty", "slurred speech",
        "sudden headache", "vision loss", "paralysis", "hemiplegia",
        "stroke", "tia", "cvst", "brain attack",
        "चेहरे का झुकना", "बाहु कमजोरी", "वाणी विकार",
    ]

    def evaluate(self, case_data: Dict) -> Optional[ProtocolTrigger]:
        symptoms = self._symptoms(case_data)
        v = self._vitals(case_data)
        gcs = v.get("gcs") or 15

        fast_count = sum(1 for kw in self.STROKE_KEYWORDS if kw in symptoms)
        sudden_onset = "sudden" in symptoms or "acute" in symptoms

        if fast_count >= 1 and sudden_onset:
            return ProtocolTrigger(
                protocol_name=self.name,
                severity="CRITICAL",
                triggered_by=[kw for kw in self.STROKE_KEYWORDS if kw in symptoms],
                forced_state="ESCALATED",
                forced_risk="EMERGENCY",
                mandatory_actions=[
                    "CT head STAT (target <25 min)",
                    "Neurology on-call alert NOW",
                    "Blood glucose check immediately",
                    "BP monitoring — do NOT lower unless >220/120",
                    "tPA eligibility assessment (if ischaemic, <4.5hr)",
                    "ECG + troponin",
                    "NPO — aspiration risk",
                ],
                time_target_seconds=3600,  # 1hr
                escalate_immediately=True,
                audit_note=f"FAST_score={fast_count} | gcs={gcs} | sudden={sudden_onset}",
            )
        return None


# ═══════════════════════════════════════════════
#  TRAUMA PROTOCOL
# ═══════════════════════════════════════════════
class TraumaProtocol(BaseProtocol):
    """ATLS primary survey: Airway → Breathing → Circulation → Disability → Exposure"""
    name = "TRAUMA_PROTOCOL"

    TRAUMA_KEYWORDS = [
        "accident", "trauma", "fall", "fracture", "injury", "bleeding",
        "mvd", "rta", "road traffic", "gunshot", "stab",
        "दुर्घटना", "चोट",
    ]

    def evaluate(self, case_data: Dict) -> Optional[ProtocolTrigger]:
        symptoms = self._symptoms(case_data)
        v = self._vitals(case_data)
        sbp = v.get("systolic_bp") or 120
        hr = v.get("heart_rate") or 80
        spo2 = v.get("spo2") or 98
        gcs = v.get("gcs") or 15

        is_trauma = any(kw in symptoms for kw in self.TRAUMA_KEYWORDS)
        haemodynamic_instability = sbp < 90 or hr > 120 or spo2 < 92

        if is_trauma:
            sev = "CRITICAL" if haemodynamic_instability or gcs < 12 else "HIGH"
            return ProtocolTrigger(
                protocol_name=self.name,
                severity=sev,
                triggered_by=[kw for kw in self.TRAUMA_KEYWORDS if kw in symptoms],
                forced_state="ESCALATED" if sev == "CRITICAL" else None,
                forced_risk="EMERGENCY" if sev == "CRITICAL" else "HIGH",
                mandatory_actions=[
                    "Primary survey: ABCDE",
                    "2 large-bore IV lines",
                    "Cross-match blood + group & screen",
                    "FAST ultrasound if abdominal trauma",
                    "Trauma surgeon notification",
                    "C-spine precautions if mechanism warrants",
                    "Chest X-ray + pelvis X-ray",
                ],
                time_target_seconds=1800,
                escalate_immediately=(sev == "CRITICAL"),
                audit_note=f"trauma=True | haemo_unstable={haemodynamic_instability} | gcs={gcs}",
            )
        return None


# ═══════════════════════════════════════════════
#  ICU PROTOCOL
# ═══════════════════════════════════════════════
class ICUProtocol(BaseProtocol):
    """ICU admission criteria: SOFA score proxy via available vitals"""
    name = "ICU_PROTOCOL"

    def evaluate(self, case_data: Dict) -> Optional[ProtocolTrigger]:
        v = self._vitals(case_data)
        spo2 = v.get("spo2") or 98
        sbp = v.get("systolic_bp") or 120
        gcs = v.get("gcs") or 15
        rr = v.get("respiratory_rate") or 16
        urine_output = v.get("urine_output_ml_hr")  # optional

        icu_criteria = []
        if spo2 < 90: icu_criteria.append(f"SpO2 {spo2}%<90")
        if sbp < 90: icu_criteria.append(f"SBP {sbp}<90")
        if gcs <= 8: icu_criteria.append(f"GCS {gcs}≤8")
        if rr > 30: icu_criteria.append(f"RR {rr}>30")
        if urine_output is not None and urine_output < 0.5:
            icu_criteria.append(f"UO {urine_output}<0.5 mL/kg/hr")

        if len(icu_criteria) >= 2:
            return ProtocolTrigger(
                protocol_name=self.name,
                severity="CRITICAL",
                triggered_by=icu_criteria,
                forced_state="ESCALATED",
                forced_risk="EMERGENCY",
                mandatory_actions=[
                    "ICU bed request STAT",
                    "Intensivist notification",
                    "Arterial line + central venous access",
                    "Continuous cardiac monitoring",
                    "Vasopressor readiness",
                    "Ventilator standby",
                ],
                time_target_seconds=900,
                escalate_immediately=True,
                audit_note=f"ICU_criteria={icu_criteria}",
            )
        return None


# ═══════════════════════════════════════════════
#  CODE BLUE
# ═══════════════════════════════════════════════
class CodeBlueProtocol(BaseProtocol):
    """Cardiac/respiratory arrest — immediate resuscitation"""
    name = "CODE_BLUE"

    CODE_BLUE_KEYWORDS = [
        "cardiac arrest", "respiratory arrest", "no pulse", "unresponsive",
        "pulseless", "code blue", "vf", "vt", "pea", "asystole",
        "हृदय गति रुकना",
    ]

    def evaluate(self, case_data: Dict) -> Optional[ProtocolTrigger]:
        symptoms = self._symptoms(case_data)
        v = self._vitals(case_data)
        gcs = v.get("gcs") or 15
        hr = v.get("heart_rate")
        sbp = v.get("systolic_bp")

        code_blue = any(kw in symptoms for kw in self.CODE_BLUE_KEYWORDS)
        physiological_arrest = (gcs == 3 and (hr == 0 or sbp == 0))

        if code_blue or physiological_arrest:
            return ProtocolTrigger(
                protocol_name=self.name,
                severity="CRITICAL",
                triggered_by=(
                    [kw for kw in self.CODE_BLUE_KEYWORDS if kw in symptoms]
                    or ["GCS=3 + no pulse/BP"]
                ),
                forced_state="ESCALATED",
                forced_risk="EMERGENCY",
                mandatory_actions=[
                    "CALL CODE BLUE IMMEDIATELY",
                    "Start CPR — 30:2",
                    "Defibrillator to bedside",
                    "IV/IO access",
                    "Adrenaline 1mg IV every 3-5 min",
                    "Advanced airway management",
                    "Identify reversible causes (4H4T)",
                ],
                time_target_seconds=0,  # Immediate
                escalate_immediately=True,
                audit_note="CODE_BLUE_TRIGGERED",
            )
        return None


# ═══════════════════════════════════════════════
#  PROTOCOL REGISTRY
# ═══════════════════════════════════════════════
class ProtocolEngine:
    """
    Evaluates all protocols in priority order.
    Called from the orchestrator hook BEFORE committing any state transition.
    """

    _protocols = [
        CodeBlueProtocol(),   # Highest priority
        StrokeProtocol(),
        SepsisProtocol(),
        TraumaProtocol(),
        ICUProtocol(),
    ]

    @classmethod
    def evaluate_all(cls, case_data: Dict[str, Any]) -> Optional[ProtocolTrigger]:
        """
        Run all protocols. Return the first (highest priority) trigger found.
        Returns None if no protocol fires — normal flow continues.
        """
        for protocol in cls._protocols:
            try:
                trigger = protocol.evaluate(case_data)
                if trigger:
                    logger.warning(
                        f"Protocol fired: {trigger.protocol_name} | "
                        f"severity={trigger.severity} | "
                        f"case_id={case_data.get('case_id','?')} | "
                        f"criteria={trigger.triggered_by[:3]}"
                    )
                    return trigger
            except Exception as e:
                logger.error(f"Protocol {protocol.name} evaluation error: {e}")
        return None

    @classmethod
    def apply_trigger(cls, trigger: ProtocolTrigger, event_payload: Dict) -> Dict:
        """
        Merge protocol overrides into event payload.
        Called by orchestrator hook.
        """
        if trigger.forced_state:
            event_payload["suggested_state"] = trigger.forced_state
        if trigger.forced_risk:
            event_payload["risk_level"] = trigger.forced_risk
        event_payload.setdefault("data", {})
        event_payload["data"]["protocol_triggered"] = trigger.protocol_name
        event_payload["data"]["protocol_severity"] = trigger.severity
        event_payload["data"]["protocol_actions"] = trigger.mandatory_actions
        event_payload["data"]["protocol_audit"] = trigger.audit_note
        event_payload["data"]["time_target_seconds"] = trigger.time_target_seconds
        return event_payload
