"""
billing/billing_engine.py — Hospital-side Billing Engine

Handles:
  - Procedure-based billing
  - Package pricing (day-care, surgical packages)
  - Insurance mapping (PMJAY, CGHS, ESI, private)
  - Bill generation with CGHS rate compliance check
  - Revenue cycle tracking

This is the PROVIDER side billing (hospital).
Patient-side bill analysis (dispute) is in roles/patient/router.py.
"""

from __future__ import annotations
import logging
import uuid
from datetime import datetime
from typing import Optional, Dict, List, Any

from fastapi import APIRouter, Depends, HTTPException, Body
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from main import verify_token

logger = logging.getLogger("vitalos.billing")
billing_router = APIRouter(prefix="/billing", tags=["billing"])

# Sample CGHS rates (subset — full table from admin/cghs-rates)
CGHS_RATES: Dict[str, float] = {
    "OPD_CONSULTATION": 200,
    "SPECIALIST_CONSULTATION": 400,
    "EMERGENCY_CONSULTATION": 600,
    "GENERAL_WARD_PER_DAY": 1000,
    "SEMI_PRIVATE_PER_DAY": 2000,
    "PRIVATE_ROOM_PER_DAY": 3500,
    "ICU_PER_DAY": 4500,
    "MRI_BRAIN": 3500,
    "CT_SCAN_CHEST": 2500,
    "XRAY_CHEST": 200,
    "CBC": 200,
    "HBA1C": 300,
    "LIPID_PROFILE": 350,
    "ECG": 150,
    "ECHO": 1500,
    "KNEE_REPLACEMENT_TOTAL": 60000,
    "CATARACT_SURGERY": 10000,
    "CORONARY_ANGIOPLASTY": 95000,
    "NORMAL_DELIVERY": 8000,
    "CAESAREAN": 15000,
}

# Insurance coverage types
INSURANCE_TYPES = {
    "PMJAY": {"coverage_limit": 500000, "cashless": True, "applicable_hospitals": "all_empanelled"},
    "CGHS":  {"coverage_limit": None,   "cashless": True, "applicable_hospitals": "cghs_empanelled"},
    "ESI":   {"coverage_limit": None,   "cashless": True, "applicable_hospitals": "esi_empanelled"},
    "PRIVATE": {"coverage_limit": "policy_defined", "cashless": "varies", "applicable_hospitals": "network"},
    "NONE":  {"coverage_limit": 0, "cashless": False, "applicable_hospitals": "none"},
}


class BillLineItem(BaseModel):
    service_code: str
    description: str
    quantity: int = 1
    unit_price: float
    category: str  # "consultation" | "investigation" | "procedure" | "room" | "pharmacy"

class GenerateBillRequest(BaseModel):
    patient_id: str
    admission_date: Optional[str] = None
    discharge_date: Optional[str] = None
    insurance_type: str = "NONE"
    policy_number: Optional[str] = None
    line_items: List[BillLineItem]
    attending_doctor_id: Optional[str] = None


@billing_router.post("/generate", summary="Generate hospital bill with CGHS compliance check")
async def generate_bill(
    req: GenerateBillRequest,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if me["role"] not in ("doctor", "nurse", "admin"):
        raise HTTPException(403, "Doctor/Admin required")

    bill_id = f"BILL-{str(uuid.uuid4())[:8].upper()}"
    items_with_validation = []
    cghs_flags = []
    total_charged = 0.0
    total_cghs_approved = 0.0

    for item in req.line_items:
        total_charged += item.unit_price * item.quantity
        cghs_rate = CGHS_RATES.get(item.service_code.upper())
        cghs_rate_total = (cghs_rate or item.unit_price) * item.quantity
        total_cghs_approved += cghs_rate_total
        overcharge = max(0, (item.unit_price * item.quantity) - cghs_rate_total)

        if overcharge > 0 and req.insurance_type in ("CGHS", "PMJAY"):
            cghs_flags.append({
                "service": item.description,
                "charged": item.unit_price * item.quantity,
                "cghs_rate": cghs_rate,
                "overcharge": overcharge,
            })

        items_with_validation.append({
            **item.dict(),
            "line_total": item.unit_price * item.quantity,
            "cghs_approved_rate": cghs_rate,
            "cghs_line_total": cghs_rate_total,
            "cghs_excess": overcharge,
        })

    # Insurance coverage computation
    insurance = INSURANCE_TYPES.get(req.insurance_type, INSURANCE_TYPES["NONE"])
    insured_amount = 0.0
    patient_liability = total_charged

    if req.insurance_type == "CGHS":
        insured_amount = total_cghs_approved
        patient_liability = max(0, total_charged - insured_amount)
    elif req.insurance_type == "PMJAY":
        insured_amount = min(total_cghs_approved, 500000)
        patient_liability = max(0, total_charged - insured_amount)
    elif req.insurance_type == "ESI":
        insured_amount = total_charged  # ESI covers fully for eligible employees
        patient_liability = 0

    # Save bill
    await db.execute(text("""
        INSERT INTO billing_records
        (bill_id, patient_id, total_charged, total_cghs_approved, insured_amount,
         patient_liability, insurance_type, policy_number, cghs_flags,
         line_items_json, created_by, created_at)
        VALUES (:bid, :pid, :tc, :tca, :ia, :pl, :ins, :pnum, :flags, :items, :uid, NOW())
    """), {
        "bid": bill_id, "pid": req.patient_id,
        "tc": total_charged, "tca": total_cghs_approved,
        "ia": insured_amount, "pl": patient_liability,
        "ins": req.insurance_type, "pnum": req.policy_number,
        "flags": str(cghs_flags), "items": str(items_with_validation),
        "uid": me["sub"],
    })
    await db.commit()

    return {
        "bill_id": bill_id,
        "patient_id": req.patient_id,
        "generated_at": datetime.utcnow().isoformat(),
        "summary": {
            "total_charged":      round(total_charged, 2),
            "cghs_approved_total": round(total_cghs_approved, 2),
            "insured_amount":     round(insured_amount, 2),
            "patient_liability":  round(patient_liability, 2),
        },
        "insurance": {
            "type": req.insurance_type,
            "cashless": insurance.get("cashless"),
            "policy_number": req.policy_number,
        },
        "cghs_compliance": {
            "flags": cghs_flags,
            "compliant": len(cghs_flags) == 0,
            "excess_charged": round(total_charged - total_cghs_approved, 2),
        },
        "line_items": items_with_validation,
    }


@billing_router.get("/patient/{patient_id}", summary="Patient billing history")
async def patient_billing(
    patient_id: str,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if me["role"] not in ("doctor", "admin", "patient") or \
       (me["role"] == "patient" and me["sub"] != patient_id):
        raise HTTPException(403, "Access denied")

    result = await db.execute(text("""
        SELECT bill_id, total_charged, insured_amount, patient_liability,
               insurance_type, created_at
        FROM billing_records WHERE patient_id=:pid
        ORDER BY created_at DESC LIMIT 20
    """), {"pid": patient_id})
    rows = result.fetchall()
    return {"bills": [dict(r._mapping) for r in rows]}


@billing_router.get("/packages", summary="Surgical and day-care packages")
async def get_packages(me=Depends(verify_token)):
    """Standard package pricing — aligned with NABH and CGHS."""
    return {
        "packages": [
            {"name": "Cataract Surgery Day Care",   "price": 12000, "cghs": 10000, "includes": "Surgery + OT + consumables + 1 day stay"},
            {"name": "Normal Delivery Package",     "price": 15000, "cghs": 8000,  "includes": "Labour + delivery + 3 day stay + newborn care"},
            {"name": "Knee Replacement (Unilateral)","price": 80000, "cghs": 60000, "includes": "Surgery + implant + 7 day stay + physio"},
            {"name": "PTCA (Stent)",                "price": 120000,"cghs": 95000, "includes": "Procedure + 3 day stay + cath lab + stent"},
            {"name": "Appendicectomy (Lap)",        "price": 35000, "cghs": 25000, "includes": "Surgery + 2 day stay + anaesthesia"},
            {"name": "ICU Package (per day)",       "price": 6000,  "cghs": 4500,  "includes": "Bed + monitoring + nursing + basic medications"},
        ],
        "note": "Prices are indicative. Final billing per actual services rendered.",
    }
