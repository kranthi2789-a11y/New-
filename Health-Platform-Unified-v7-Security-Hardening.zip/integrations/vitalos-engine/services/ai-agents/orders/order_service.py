"""
orders/order_service.py — Clinical Orders & Results Engine

Order lifecycle:
CREATED → SENT → IN_PROGRESS → COMPLETED → RESULT_RECEIVED

Supports:
  - Lab orders
  - Radiology orders
  - Medication orders

Every order state change is published to Kafka (vitalos.orders.events)
and written to the audit-adjacent orders_log table.
"""

from __future__ import annotations
import logging
import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List
from enum import Enum

from fastapi import APIRouter, Depends, HTTPException, Body
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from main import verify_token

logger = logging.getLogger("vitalos.orders")
router = APIRouter(prefix="/orders", tags=["orders"])


class OrderStatus(str, Enum):
    CREATED         = "CREATED"
    SENT            = "SENT"
    IN_PROGRESS     = "IN_PROGRESS"
    COMPLETED       = "COMPLETED"
    RESULT_RECEIVED = "RESULT_RECEIVED"
    CANCELLED       = "CANCELLED"

class OrderType(str, Enum):
    LAB        = "LAB"
    RADIOLOGY  = "RADIOLOGY"
    MEDICATION = "MEDICATION"


# ── Request models ────────────────────────────────────────────

class LabOrderRequest(BaseModel):
    patient_id: str
    case_id: Optional[str] = None
    tests: List[str]                   # e.g. ["CBC", "LFT", "HbA1c"]
    priority: str = "routine"          # "routine" | "urgent" | "STAT"
    clinical_notes: Optional[str] = None
    fasting_required: bool = False

class RadiologyOrderRequest(BaseModel):
    patient_id: str
    case_id: Optional[str] = None
    modality: str                      # "XRAY" | "CT" | "MRI" | "USG" | "ECHO"
    body_part: str
    clinical_indication: str
    priority: str = "routine"
    contrast_required: bool = False

class MedicationOrderRequest(BaseModel):
    patient_id: str
    case_id: Optional[str] = None
    drug_name: str
    dose: str
    route: str                         # "oral" | "IV" | "IM" | "SC" | "topical"
    frequency: str                     # "OD" | "BD" | "TDS" | "QDS" | "PRN"
    duration_days: int
    notes: Optional[str] = None
    start_immediately: bool = True

class ResultIngestRequest(BaseModel):
    order_id: str
    result_data: Dict[str, Any]
    result_text: Optional[str] = None
    abnormal_flags: List[str] = []
    critical: bool = False


# ── Helper to publish order event ────────────────────────────

async def _publish_order_event(order_id: str, status: str, order_type: str,
                                 patient_id: str, data: Dict, db: AsyncSession):
    """Persist order event to DB. Kafka publish is best-effort."""
    await db.execute(text("""
        INSERT INTO orders_log
        (order_id, patient_id, order_type, status, payload, created_at)
        VALUES (:oid, :pid, :otype, :status, :payload, NOW())
        ON CONFLICT (order_id) DO UPDATE SET status=:status, updated_at=NOW()
    """), {
        "oid": order_id, "pid": patient_id,
        "otype": order_type, "status": status,
        "payload": str(data),
    })
    # Best-effort Kafka publish
    try:
        from core.kafka_helper import publish_to_kafka
        await publish_to_kafka("vitalos.orders.events", order_id, {
            "order_id": order_id, "status": status,
            "order_type": order_type, "patient_id": patient_id,
            "timestamp": datetime.utcnow().isoformat(),
        })
    except Exception:
        pass  # Non-blocking


# ── LAB ORDERS ───────────────────────────────────────────────

@router.post("/lab", summary="Place lab order")
async def place_lab_order(
    req: LabOrderRequest,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if me["role"] not in ("doctor", "nurse", "admin"):
        raise HTTPException(403, "Doctor/Nurse access required")

    order_id = f"LAB-{str(uuid.uuid4())[:8].upper()}"
    stat_prefix = "🔴 STAT" if req.priority == "STAT" else ("⚡ URGENT" if req.priority == "urgent" else "")

    await _publish_order_event(order_id, OrderStatus.CREATED, OrderType.LAB,
                                req.patient_id, req.__dict__, db)
    await db.commit()

    logger.info(f"Lab order placed: {order_id} tests={req.tests} priority={req.priority}")
    return {
        "order_id": order_id,
        "status": OrderStatus.CREATED,
        "order_type": OrderType.LAB,
        "tests": req.tests,
        "priority": req.priority,
        "fasting_required": req.fasting_required,
        "instructions": f"{stat_prefix} Collect sample and send to lab. Order ID: {order_id}",
        "expected_tat_hours": 1 if req.priority == "STAT" else 4 if req.priority == "urgent" else 24,
    }


@router.post("/lab/{order_id}/result", summary="Ingest lab result")
async def ingest_lab_result(
    order_id: str,
    req: ResultIngestRequest,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    req.order_id = order_id

    # Notify doctor via WhatsApp if critical
    if req.critical:
        try:
            from services.whatsapp import send_whatsapp
            # Find assigned doctor
            doc_result = await db.execute(text("""
                SELECT u.mobile, u.name FROM doctor_patient dp
                JOIN users u ON dp.doctor_id = u.id
                WHERE dp.patient_id = :pid AND dp.is_active = TRUE LIMIT 1
            """), {"pid": req.result_data.get("patient_id", "")})
            doc = doc_result.fetchone()
            if doc:
                await send_whatsapp(doc.mobile,
                    f"🔴 *CRITICAL Lab Result — VitalOS*\n\n"
                    f"Order: {order_id}\n"
                    f"Critical flags: {', '.join(req.abnormal_flags)}\n"
                    f"Please review immediately."
                )
        except Exception as e:
            logger.warning(f"Critical result WhatsApp failed: {e}")

    await _publish_order_event(order_id, OrderStatus.RESULT_RECEIVED, OrderType.LAB,
                                req.result_data.get("patient_id", ""), req.__dict__, db)
    await db.commit()

    return {
        "order_id": order_id,
        "status": OrderStatus.RESULT_RECEIVED,
        "critical": req.critical,
        "abnormal_flags": req.abnormal_flags,
        "doctor_notified": req.critical,
    }


# ── RADIOLOGY ORDERS ─────────────────────────────────────────

@router.post("/radiology", summary="Place radiology order")
async def place_radiology_order(
    req: RadiologyOrderRequest,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if me["role"] not in ("doctor", "admin"):
        raise HTTPException(403, "Doctor access required")

    order_id = f"RAD-{str(uuid.uuid4())[:8].upper()}"

    # Safety: contrast + metformin check
    warnings = []
    if req.contrast_required:
        warnings.append("Hold metformin 48hr before and after contrast — lactic acidosis risk")
        warnings.append("Renal function check required before contrast administration")
        if req.modality == "CT":
            warnings.append("Ensure creatinine <1.5 mg/dL before contrast CT")

    await _publish_order_event(order_id, OrderStatus.CREATED, OrderType.RADIOLOGY,
                                req.patient_id, req.__dict__, db)
    await db.commit()

    return {
        "order_id": order_id,
        "status": OrderStatus.CREATED,
        "modality": req.modality,
        "body_part": req.body_part,
        "priority": req.priority,
        "contrast_required": req.contrast_required,
        "safety_warnings": warnings,
        "instructions": f"Schedule {req.modality} {req.body_part} — Order: {order_id}",
        "expected_tat_hours": 1 if req.priority == "STAT" else 6,
    }


# ── MEDICATION ORDERS ─────────────────────────────────────────

@router.post("/medication", summary="Place medication order with CDSS check")
async def place_medication_order(
    req: MedicationOrderRequest,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if me["role"] not in ("doctor", "nurse", "admin"):
        raise HTTPException(403, "Doctor/Nurse access required")

    # CDSS safety check
    from cdss.engine import CDSSEngine
    cdss_result = CDSSEngine.evaluate(
        medications=[{"drug_name": req.drug_name, "drug_class": ""}],
    )
    if not cdss_result.safe_to_proceed:
        raise HTTPException(400, {
            "error": "CDSS_BLOCK",
            "reason": cdss_result.block_reason,
            "alerts": [{"severity": a.severity, "message": a.message}
                       for a in cdss_result.alerts if a.severity == "REJECT"],
        })

    order_id = f"MED-{str(uuid.uuid4())[:8].upper()}"

    await _publish_order_event(order_id, OrderStatus.CREATED, OrderType.MEDICATION,
                                req.patient_id, req.__dict__, db)
    await db.commit()

    return {
        "order_id": order_id,
        "status": OrderStatus.CREATED,
        "drug_name": req.drug_name,
        "dose": req.dose,
        "route": req.route,
        "frequency": req.frequency,
        "duration_days": req.duration_days,
        "cdss_warnings": [a.message for a in cdss_result.alerts if a.severity == "WARN"],
        "start_immediately": req.start_immediately,
    }


# ── STATUS UPDATE ─────────────────────────────────────────────

@router.patch("/{order_id}/status", summary="Update order status")
async def update_order_status(
    order_id: str,
    status: str = Body(..., embed=True),
    notes: Optional[str] = Body(None, embed=True),
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    valid = [s.value for s in OrderStatus]
    if status not in valid:
        raise HTTPException(400, f"Status must be one of {valid}")

    await db.execute(text("""
        UPDATE orders_log SET status=:status, updated_at=NOW()
        WHERE order_id=:oid
    """), {"status": status, "oid": order_id})
    await db.commit()
    return {"order_id": order_id, "status": status, "updated_by": me["name"]}


# ── GET PATIENT ORDERS ────────────────────────────────────────

@router.get("/patient/{patient_id}", summary="Get all orders for patient")
async def patient_orders(
    patient_id: str,
    order_type: Optional[str] = None,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    q = "SELECT * FROM orders_log WHERE patient_id=:pid"
    params: Dict = {"pid": patient_id}
    if order_type:
        q += " AND order_type=:otype"
        params["otype"] = order_type
    q += " ORDER BY created_at DESC LIMIT 50"

    result = await db.execute(text(q), params)
    rows = result.fetchall()
    return {"orders": [dict(r._mapping) for r in rows]}
