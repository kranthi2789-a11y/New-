"""
sla/sla_engine.py — SLA / Time-Bound Care Engine

Monitors every active case against SLA thresholds.
Runs as a background worker (APScheduler) every 30 seconds.

SLA definitions:
  TRIAGE:          Emergency ≤30s | High ≤2min | Medium/Low ≤5min
  DOCTOR_REVIEW:   Emergency ≤5min | High ≤15min | Others ≤1hr
  ROUTING:         Emergency ≤2min | Others ≤30min
  TOTAL_CASE:      Emergency ≤4hr | High ≤8hr | Others ≤24hr

SLA breach → Kafka alert → WhatsApp to responsible clinician
"""

from __future__ import annotations
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

logger = logging.getLogger("vitalos.sla")

# SLA thresholds in SECONDS per (state, risk_level)
SLA_THRESHOLDS: Dict[Tuple[str, str], int] = {
    # (state, risk)          seconds
    ("TRIAGE_PENDING",    "EMERGENCY"): 30,
    ("TRIAGE_PENDING",    "HIGH"):      120,
    ("TRIAGE_PENDING",    "MEDIUM"):    300,
    ("TRIAGE_PENDING",    "LOW"):       300,
    ("DOCTOR_REVIEW_PENDING", "EMERGENCY"): 300,
    ("DOCTOR_REVIEW_PENDING", "HIGH"):   900,
    ("DOCTOR_REVIEW_PENDING", "MEDIUM"): 3600,
    ("DOCTOR_REVIEW_PENDING", "LOW"):    3600,
    ("ROUTING_PENDING",   "EMERGENCY"): 120,
    ("ROUTING_PENDING",   "HIGH"):      1800,
    ("ROUTING_PENDING",   "MEDIUM"):    3600,
    ("ROUTING_PENDING",   "LOW"):       7200,
}

TOTAL_CASE_SLA: Dict[str, int] = {
    "EMERGENCY": 4 * 3600,
    "HIGH":      8 * 3600,
    "MEDIUM":    24 * 3600,
    "LOW":       48 * 3600,
}


@dataclass
class SLAViolation:
    case_id: str
    state: str
    risk_level: str
    seconds_in_state: int
    sla_threshold_seconds: int
    breach_seconds: int
    attending_doctor_id: Optional[str]
    hospital_id: Optional[str]


class SLAMonitor:
    """
    Background monitor. Called by APScheduler every 30 seconds.
    Queries active cases, detects SLA breaches, fires alerts.
    """

    @classmethod
    async def check_violations(cls, db) -> List[SLAViolation]:
        """Find all active cases breaching their SLA."""
        from sqlalchemy import text

        now = datetime.utcnow()
        violations: List[SLAViolation] = []

        # Fetch all non-terminal cases
        result = await db.execute(text("""
            SELECT c.case_id, c.current_state, c.risk_level,
                   c.updated_at, c.attending_doctor_id, c.hospital_id
            FROM case_state_machine c
            WHERE c.current_state NOT IN ('CLOSED','ESCALATED')
              AND c.is_locked = FALSE
        """))
        rows = result.fetchall()

        for row in rows:
            state = row.current_state
            risk = row.risk_level
            updated_at = row.updated_at

            if not updated_at:
                continue

            seconds_in_state = int((now - updated_at).total_seconds())
            threshold = SLA_THRESHOLDS.get((state, risk))

            if threshold and seconds_in_state > threshold:
                violations.append(SLAViolation(
                    case_id=row.case_id,
                    state=state,
                    risk_level=risk,
                    seconds_in_state=seconds_in_state,
                    sla_threshold_seconds=threshold,
                    breach_seconds=seconds_in_state - threshold,
                    attending_doctor_id=getattr(row, "attending_doctor_id", None),
                    hospital_id=getattr(row, "hospital_id", None),
                ))

        if violations:
            logger.warning(f"SLA violations found: {len(violations)}")

        return violations

    @classmethod
    async def handle_violations(cls, violations: List[SLAViolation], db) -> None:
        """For each violation: log it + alert responsible clinician."""
        from sqlalchemy import text
        from services.whatsapp import send_whatsapp

        for v in violations:
            # Log to SLA breach table
            try:
                await db.execute(text("""
                    INSERT INTO sla_breaches
                    (case_id, state, risk_level, seconds_in_state, threshold_seconds,
                     breach_seconds, attending_doctor_id, detected_at)
                    VALUES (:cid, :state, :risk, :sis, :thresh, :breach, :doc, NOW())
                    ON CONFLICT (case_id, state) DO UPDATE
                    SET breach_seconds=:breach, detected_at=NOW()
                """), {
                    "cid": v.case_id, "state": v.state, "risk": v.risk_level,
                    "sis": v.seconds_in_state, "thresh": v.sla_threshold_seconds,
                    "breach": v.breach_seconds,
                    "doc": v.attending_doctor_id,
                })
            except Exception as e:
                logger.error(f"SLA log write failed: {e}")

            # Alert attending doctor
            if v.attending_doctor_id:
                try:
                    doc_result = await db.execute(text(
                        "SELECT mobile, name FROM users WHERE id=:uid"
                    ), {"uid": v.attending_doctor_id})
                    doc = doc_result.fetchone()
                    if doc:
                        mins_over = v.breach_seconds // 60
                        await send_whatsapp(doc.mobile,
                            f"⏱ *SLA Breach — VitalOS*\n\n"
                            f"Case: {v.case_id}\n"
                            f"State: {v.state.replace('_',' ')}\n"
                            f"Risk: {v.risk_level}\n"
                            f"SLA exceeded by: {mins_over} min\n\n"
                            f"Please action immediately."
                        )
                except Exception as e:
                    logger.warning(f"SLA alert WhatsApp failed: {e}")

        await db.commit()


# ── APScheduler background task ───────────────────────────────
async def sla_check_job():
    """Called every 30s by APScheduler in main.py startup."""
    try:
        from core.database import AsyncSessionLocal
        async with AsyncSessionLocal() as db:
            violations = await SLAMonitor.check_violations(db)
            if violations:
                await SLAMonitor.handle_violations(violations, db)
    except Exception as e:
        logger.error(f"SLA check job error: {e}")


# ── Router ────────────────────────────────────────────────────
from fastapi import APIRouter, Depends
from core.database import get_db
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from main import verify_token

sla_router = APIRouter(prefix="/sla", tags=["sla"])


@sla_router.get("/breaches", summary="List current SLA breaches")
async def list_breaches(
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if me["role"] not in ("admin", "doctor"):
        from fastapi import HTTPException
        raise HTTPException(403, "Admin/Doctor only")

    result = await db.execute(text("""
        SELECT * FROM sla_breaches
        WHERE detected_at > NOW() - INTERVAL '24 hours'
        ORDER BY breach_seconds DESC LIMIT 50
    """))
    rows = result.fetchall()
    return {"breaches": [dict(r._mapping) for r in rows], "total": len(rows)}


@sla_router.get("/thresholds", summary="Get SLA threshold configuration")
async def get_thresholds(me=Depends(verify_token)):
    return {
        "state_slas": {f"{s}|{r}": v for (s, r), v in SLA_THRESHOLDS.items()},
        "total_case_slas": TOTAL_CASE_SLA,
        "check_interval_seconds": 30,
    }
