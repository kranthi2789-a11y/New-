"""
agents/base.py — Base class for all VitalOS AI agents

All agents are STATELESS — they receive input, call Claude, return structured output.
They never touch the database directly. The TS Orchestrator owns state.
"""

import time
import logging
import json
import re
from abc import ABC, abstractmethod
from typing import Any, Optional
import anthropic

from core.config import settings
from core.rag import retrieve_medical_context

logger = logging.getLogger("vitalos.agent")

_client: Optional[anthropic.Anthropic] = None


def get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        _client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
    return _client


class BaseAgent(ABC):
    """
    All VitalOS agents inherit from this.
    Provides: Claude API access, RAG retrieval, structured output, logging, versioning.
    """

    description: str = "Base VitalOS agent"
    category: str = "general"
    model: str = settings.CLAUDE_MODEL
    max_tokens: int = settings.MAX_TOKENS

    def _call_claude(
        self,
        system_prompt: str,
        user_message: str,
        use_rag: bool = False,
        rag_query: Optional[str] = None,
    ) -> str:
        """
        Core Claude API call with optional RAG context injection.
        Always injects agent_version and schema_version into system prompt.
        """
        client = get_client()

        # Inject versioning context
        versioned_system = (
            f"{system_prompt}\n\n"
            f"[System: agent_version={settings.AGENT_VERSION}, schema_version={settings.SCHEMA_VERSION}]"
        )

        # Optionally inject medical context from RAG
        if use_rag:
            query = rag_query or user_message
            context = retrieve_medical_context(query)
            versioned_system = f"{versioned_system}\n\n<medical_context>\n{context}\n</medical_context>"

        start = time.perf_counter()
        try:
            response = client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                system=versioned_system,
                messages=[{"role": "user", "content": user_message}],
            )
            text = response.content[0].text
            elapsed_ms = (time.perf_counter() - start) * 1000
            tokens = response.usage.input_tokens + response.usage.output_tokens
            logger.info(
                f"[{self.__class__.__name__}] {elapsed_ms:.0f}ms · {tokens} tokens"
            )
            return text
        except anthropic.AuthenticationError:
            logger.error("Invalid Anthropic API key")
            raise
        except anthropic.RateLimitError:
            logger.warning("Rate limited — backing off")
            raise
        except Exception as e:
            logger.error(f"Claude API error in {self.__class__.__name__}: {e}")
            raise

    def _call_claude_vision(
        self,
        system_prompt: str,
        user_text: str,
        image_base64: str,
        media_type: str = "image/jpeg",
    ) -> str:
        """Call Claude with vision for image-based inputs (prescriptions, lab reports)."""
        client = get_client()
        context = retrieve_medical_context(user_text)
        full_system = (
            f"{system_prompt}\n\n<medical_context>\n{context}\n</medical_context>\n\n"
            f"[System: agent_version={settings.AGENT_VERSION}]"
        )

        # Strip data URI prefix if present
        if image_base64.startswith("data:"):
            parts = image_base64.split(",", 1)
            if "png" in parts[0]:
                media_type = "image/png"
            image_base64 = parts[1] if len(parts) > 1 else image_base64

        response = client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            system=full_system,
            messages=[{
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": media_type,
                            "data": image_base64,
                        },
                    },
                    {"type": "text", "text": user_text},
                ],
            }],
        )
        return response.content[0].text

    @staticmethod
    def _safe_json_parse(text: str) -> Optional[dict]:
        """Extract and parse JSON from Claude response — handles markdown fences."""
        text = re.sub(r"```(?:json)?\n?", "", text).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group())
                except Exception:
                    pass
        return None

    @abstractmethod
    async def run(self, **kwargs) -> Any:
        """Each agent implements its own run() method. Always stateless."""
        pass
