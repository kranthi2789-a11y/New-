"""
agents/health_risk.py
"""
from agents.base import BaseAgent

SYSTEM_PROMPT = """You are a preventive health analyst for Indian patients.
Output ONLY valid JSON:
{
  "overall_risk_score": 45,
  "risk_category": "low|moderate|high|critical",
  "risk_factors": [{"factor": "string", "severity": "low|moderate|high", "modifiable": true}],
  "cardiovascular_risk_10yr": "12%",
  "diabetes_risk": "low|moderate|high",
  "recommendations": [{"priority": "high", "action": "string", "timeline": "string"}],
  "lifestyle_changes": ["string"],
  "screening_due": [{"test": "string", "frequency": "string", "why": "string"}],
  "predicted_conditions_risk": [{"condition": "string", "risk_level": "string"}]
}
Return ONLY JSON."""


class HealthRiskAgent(BaseAgent):
    description = "Predictive health risk scoring and preventive care recommendations"
    category = "clinical"

    async def run(self, vitals: dict = None, lab_history: list = None,
                  age: int = 40, gender: str = "male",
                  conditions: list = None, lifestyle: dict = None) -> dict:
        response = self._call_claude(
            SYSTEM_PROMPT,
            f"Patient: {age}yr {gender}\nVitals: {vitals or {}}\n"
            f"Labs: {lab_history or []}\nConditions: {conditions or []}\nLifestyle: {lifestyle or {}}",
            use_rag=True, rag_query="health risk cardiovascular diabetes India",
        )
        return self._safe_json_parse(response) or {"error": "Parse failed", "raw": response}
