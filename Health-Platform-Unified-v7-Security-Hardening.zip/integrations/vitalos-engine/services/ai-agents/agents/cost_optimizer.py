"""
agents/cost_optimizer.py
"""
from typing import Optional
from agents.base import BaseAgent


class CostOptimizerAgent(BaseAgent):
    description = "Generic alternatives, Jan Aushadhi, government schemes to reduce healthcare costs"
    category = "finance"

    async def run(self, medications: list = None, procedure: Optional[str] = None,
                  budget: Optional[str] = None, location: str = "India") -> dict:
        response = self._call_claude(
            """Healthcare cost reduction expert for India.
Output ONLY valid JSON:
{
  "total_estimated_cost": "string",
  "savings_possible": "string",
  "generic_alternatives": [
    {"brand":"string","generic":"string","brand_cost":"string","generic_cost":"string","savings":"string","where_to_buy":"string"}
  ],
  "government_schemes": [{"scheme":"string","benefit":"string","eligibility":"string"}],
  "jan_aushadhi_available": ["drugs available at Jan Aushadhi"],
  "free_government_services": ["applicable free services"],
  "practical_tips": ["India-specific cost saving tips"]
}
Return ONLY JSON.""",
            f"Medications: {medications or []}\nProcedure: {procedure or 'none'}\n"
            f"Budget: {budget or 'unspecified'}\nLocation: {location}",
            use_rag=True, rag_query="generic medicines Jan Aushadhi PMJAY India",
        )
        return self._safe_json_parse(response) or {"response": response}
