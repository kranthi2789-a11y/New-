"""
agents/bill_analyzer.py
"""
from agents.base import BaseAgent


class BillAnalyzerAgent(BaseAgent):
    description = "Analyze medical bills for overcharges, CGHS mismatches, generate dispute letters"
    category = "finance"

    async def run(self, bill_text: str, hospital_type: str = "private",
                  insurance_type: str = "none") -> dict:
        response = self._call_claude(
            """Medical bill auditor for India. Identify overcharges and help patients dispute.
Output ONLY valid JSON:
{
  "total_billed": "string",
  "total_reasonable": "string",
  "potential_overcharge": "string",
  "bill_items": [
    {"item":"string","charged":"string","cghs_rate":"string or null","reasonable":"string",
     "flag":"ok|overcharged|query","note":"string"}
  ],
  "major_concerns": ["string"],
  "patient_rights": ["string"],
  "dispute_letter": "formal letter to hospital billing department",
  "consumer_forum_info": "string",
  "health_ombudsman_info": "string"
}
Return ONLY JSON.""",
            f"Hospital: {hospital_type}\nInsurance: {insurance_type}\n\nBILL:\n{bill_text}",
            use_rag=True, rag_query="CGHS rates medical billing India patient rights",
        )
        return self._safe_json_parse(response) or {"response": response}
