"""
agents/orchestrator.py — VitalOS Agent Dispatcher

Routes requests to the correct stateless inference agent.
Agents are singletons initialized once at startup.
"""

import logging
from agents.chat_companion import ChatCompanionAgent
from agents.prescription_intel import PrescriptionIntelAgent
from agents.medication_reminder import MedicationReminderAgent
from agents.lab_interpreter import LabInterpreterAgent
from agents.insurance_policy import InsurancePolicyAgent
from agents.health_risk import HealthRiskAgent
from agents.hospital_discovery import HospitalDiscoveryAgent
from agents.doctor_productivity import DoctorProductivityAgent
from agents.emergency_response import EmergencyResponseAgent
from agents.family_health import FamilyHealthAgent
from agents.cost_optimizer import CostOptimizerAgent
from agents.pharmacy_availability import PharmacyAvailabilityAgent
from agents.followup_automation import FollowUpAutomationAgent
from agents.chronic_disease import ChronicDiseaseAgent
from agents.preventive_health import PreventiveHealthAgent
from agents.bill_analyzer import BillAnalyzerAgent

logger = logging.getLogger("vitalos.agent_orchestrator")


class AgentOrchestrator:
    _agents: dict = {}

    @classmethod
    def initialize(cls):
        cls._agents = {
            "chat":        ChatCompanionAgent(),
            "prescription": PrescriptionIntelAgent(),
            "reminder":    MedicationReminderAgent(),
            "lab":         LabInterpreterAgent(),
            "insurance":   InsurancePolicyAgent(),
            "risk":        HealthRiskAgent(),
            "hospital":    HospitalDiscoveryAgent(),
            "doctor":      DoctorProductivityAgent(),
            "emergency":   EmergencyResponseAgent(),
            "family":      FamilyHealthAgent(),
            "cost":        CostOptimizerAgent(),
            "pharmacy":    PharmacyAvailabilityAgent(),
            "followup":    FollowUpAutomationAgent(),
            "chronic":     ChronicDiseaseAgent(),
            "preventive":  PreventiveHealthAgent(),
            "bill":        BillAnalyzerAgent(),
        }
        logger.info(f"✅ {len(cls._agents)} VitalOS agents initialized")

    @classmethod
    def get(cls, name: str):
        agent = cls._agents.get(name)
        if not agent:
            raise ValueError(f"Unknown agent: '{name}'. Available: {list(cls._agents.keys())}")
        return agent

    @classmethod
    def list_agents(cls) -> list:
        return [
            {
                "key": key,
                "name": agent.__class__.__name__,
                "description": agent.description,
                "category": agent.category,
                "agent_version": "1.0.0",
            }
            for key, agent in cls._agents.items()
        ]
