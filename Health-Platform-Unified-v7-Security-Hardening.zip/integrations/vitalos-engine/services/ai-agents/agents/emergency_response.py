"""
agents/emergency_response.py
"""
import json, re
from typing import Optional
from agents.base import BaseAgent


class EmergencyResponseAgent(BaseAgent):
    description = "Emergency triage, 108 routing, immediate action guidance"
    category = "emergency"

    async def run(self, symptoms: str, location: str = "unknown",
                  patient_profile: Optional[dict] = None) -> dict:
        response = self._call_claude(
            """You are an emergency medical dispatcher for India.
Output ONLY valid JSON:
{
  "severity": "minor|moderate|severe|life_threatening",
  "call_ambulance": true,
  "ambulance_number": "108",
  "immediate_actions": ["step 1", "step 2"],
  "nearest_er_type": "government|private|trauma_center",
  "do_not": ["what NOT to do"],
  "while_waiting": ["actions while waiting for help"],
  "patient_stable": false,
  "estimated_time_sensitivity": "minutes|hours|days"
}
Always include 108 if life-threatening. Return ONLY JSON.""",
            f"EMERGENCY: {symptoms}\nLocation: {location}\nProfile: {patient_profile or {}}",
        )
        text = re.sub(r"```(?:json)?\n?", "", response).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except Exception:
            return {"response": response, "call_ambulance": True, "ambulance_number": "108"}
