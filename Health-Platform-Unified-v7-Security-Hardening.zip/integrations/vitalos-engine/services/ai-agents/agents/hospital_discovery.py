"""
agents/hospital_discovery.py
"""
from typing import Optional
from agents.base import BaseAgent


class HospitalDiscoveryAgent(BaseAgent):
    description = "Find nearby hospitals and doctors by specialty with insurance compatibility"
    category = "clinical"

    async def run(self, symptoms: str, location: str = "Hyderabad",
                  insurance: Optional[str] = None, specialty: Optional[str] = None) -> dict:
        response = self._call_claude(
            """You are a hospital discovery assistant for India.
Output ONLY valid JSON:
{
  "recommended_specialty": "string",
  "urgency": "routine|soon|urgent|emergency",
  "hospitals": [
    {"name":"string","type":"government|private|charitable","estimated_cost_range":"string",
     "insurance_accepted":["list"],"contact":"string","notes":"string"}
  ],
  "government_options": ["free/low-cost options"],
  "telemedicine_option": "string or null",
  "emergency_action": "string or null"
}
Return ONLY JSON.""",
            f"Location: {location}\nSymptoms: {symptoms}\n"
            f"Insurance: {insurance or 'none'}\nSpecialty needed: {specialty or 'auto-detect'}",
            use_rag=True, rag_query=f"hospital {symptoms} India",
        )
        return self._safe_json_parse(response) or {"response": response}
