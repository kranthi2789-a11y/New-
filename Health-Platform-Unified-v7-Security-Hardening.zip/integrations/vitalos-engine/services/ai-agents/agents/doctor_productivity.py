"""
agents/doctor_productivity.py — SOAP notes, prescription, ICD-10 coding
"""
from agents.base import BaseAgent


class DoctorProductivityAgent(BaseAgent):
    description = "AI-assisted SOAP notes, prescription generation, and clinical documentation"
    category = "clinical"

    async def run(self, chief_complaint: str, history: str = "",
                  examination: str = "", diagnosis: str = "",
                  doctor_notes: str = "") -> dict:
        response = self._call_claude(
            """You are a clinical documentation assistant for Indian doctors.
Output ONLY valid JSON:
{
  "soap_note": {
    "subjective": "chief complaint and history",
    "objective": "vitals and examination findings",
    "assessment": "diagnosis/impression",
    "plan": "treatment, medications, follow-up"
  },
  "prescription": {
    "diagnosis": "string",
    "medications": [
      {"drug":"string","dosage":"string","frequency":"string","duration":"string","instructions":"string"}
    ],
    "investigations": ["tests ordered"],
    "follow_up": "string",
    "referral": "string or null"
  },
  "icd10_codes": ["suggested codes"],
  "clinical_notes": "string",
  "patient_instructions": "simple language for patient"
}
Return ONLY JSON.""",
            f"Complaint: {chief_complaint}\nHistory: {history}\n"
            f"Examination: {examination}\nDiagnosis: {diagnosis}\nNotes: {doctor_notes}",
            use_rag=True, rag_query=f"{diagnosis} {chief_complaint}",
        )
        return self._safe_json_parse(response) or {"response": response}
