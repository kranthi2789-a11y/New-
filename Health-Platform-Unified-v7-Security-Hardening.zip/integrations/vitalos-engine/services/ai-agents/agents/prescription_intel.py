"""
agents/prescription_intel.py — Parse prescriptions (text or image) into structured medication data
"""
import json, re
from typing import Optional
from agents.base import BaseAgent

SYSTEM_PROMPT = """You are a clinical pharmacist AI specializing in Indian prescription parsing.
Output ONLY valid JSON:
{
  "doctor_name": "string or null",
  "clinic_name": "string or null",
  "patient_name": "string or null",
  "date": "string or null",
  "diagnosis": "string or null",
  "medications": [
    {
      "drug_name": "string",
      "generic_name": "string or null",
      "dosage": "string",
      "frequency": "string",
      "frequency_code": "OD|BD|TDS|QID|SOS|HS|AC|PC",
      "duration_days": "number or null",
      "route": "oral|topical|inhaled|injection|drops",
      "instructions": "string or null",
      "reminder_times": ["HH:MM"]
    }
  ],
  "follow_up_days": "number or null",
  "special_instructions": "string or null",
  "interaction_warnings": ["string"],
  "generic_alternatives": {"brand_name": "generic_name"}
}
Frequency → times: OD→["08:00"], BD→["08:00","20:00"], TDS→["08:00","14:00","20:00"],
QID→["07:00","11:00","15:00","19:00"], HS→["21:00"], SOS→[].
Common Indian brands: Glycomet=Metformin, Amlip=Amlodipine, Pan=Pantoprazole.
Return ONLY JSON."""

INTERACTION_RULES = {
    frozenset(["warfarin", "aspirin"]): "SEVERE: Major bleeding risk. Avoid combination.",
    frozenset(["metformin", "alcohol"]): "MODERATE: Increased lactic acidosis risk.",
    frozenset(["amlodipine", "simvastatin"]): "MODERATE: Max simvastatin 20mg/day.",
    frozenset(["ciprofloxacin", "antacid"]): "MODERATE: Take 2 hours apart.",
    frozenset(["levothyroxine", "calcium"]): "MODERATE: Take 4 hours apart.",
}


class PrescriptionIntelAgent(BaseAgent):
    description = "Parse prescriptions into structured medication data with interaction checks"
    category = "patient"

    async def run(self, prescription_text: str, patient_age: Optional[int] = None,
                  patient_conditions: Optional[list] = None, wake_time: str = "07:00",
                  breakfast_time: str = "08:00", dinner_time: str = "20:00",
                  image_base64: Optional[str] = None) -> dict:
        age_note = f"\nPatient age: {patient_age}" if patient_age else ""
        cond_note = f"\nConditions: {', '.join(patient_conditions)}" if patient_conditions else ""
        user_message = (
            f"Parse this prescription:{age_note}{cond_note}\n\n"
            f"PRESCRIPTION:\n{prescription_text}\n\n"
            f"Reminder times: Wake={wake_time}, Breakfast={breakfast_time}, Dinner={dinner_time}"
        )

        if image_base64:
            raw = self._call_claude_vision(SYSTEM_PROMPT, user_message, image_base64)
        else:
            raw = self._call_claude(SYSTEM_PROMPT, user_message, use_rag=True, rag_query=prescription_text)

        parsed = self._safe_json_parse(raw)
        if parsed and "medications" in parsed:
            drug_names = [m.get("generic_name", m.get("drug_name", "")).lower() for m in parsed["medications"]]
            warnings = parsed.get("interaction_warnings", [])
            for pair, warning in INTERACTION_RULES.items():
                if all(d in " ".join(drug_names) for d in pair):
                    if warning not in warnings:
                        warnings.append(warning)
            parsed["interaction_warnings"] = warnings

        return parsed or {"error": "Could not parse prescription", "raw": raw}


"""
agents/lab_interpreter.py — Parse lab reports with India-specific clinical context
"""

class LabInterpreterAgent(BaseAgent):
    description = "Parse and explain lab reports with India-specific clinical context"
    category = "clinical"

    SYSTEM_PROMPT = """You are a clinical pathologist AI for Indian patients.
Output ONLY valid JSON:
{
  "report_type": "CBC|LFT|KFT|Lipid|Thyroid|HbA1c|Urine|etc.",
  "lab_name": "string or null",
  "report_date": "string or null",
  "patient_summary": "2-3 sentence plain language summary",
  "values": [
    {
      "test_name": "string",
      "value": "string",
      "unit": "string",
      "reference_range": "string",
      "status": "normal|low|high|critical_low|critical_high",
      "plain_explanation": "1-2 sentences",
      "action_needed": "none|monitor|consult_doctor|urgent"
    }
  ],
  "flags": ["concerning findings"],
  "recommendations": ["actionable recommendations"],
  "follow_up_urgency": "routine|soon|urgent|emergency",
  "doctor_speciality_needed": "string or null",
  "lifestyle_tips": ["India-specific dietary and lifestyle advice"]
}
Use simple terms. Mention Jan Aushadhi for medicines, PMJAY/e-Sanjeevani for services.
Return ONLY JSON."""

    async def run(self, lab_text: str, patient_age: Optional[int] = None,
                  patient_gender: str = "unknown", patient_conditions: Optional[list] = None,
                  image_base64: Optional[str] = None) -> dict:
        profile = f"Age: {patient_age or 'unknown'}, Gender: {patient_gender}"
        if patient_conditions:
            profile += f", Conditions: {', '.join(patient_conditions)}"

        if image_base64:
            response = self._call_claude_vision(
                self.SYSTEM_PROMPT, f"Patient profile: {profile}\n\nParse this lab report:", image_base64)
        else:
            response = self._call_claude(
                self.SYSTEM_PROMPT,
                f"Patient profile: {profile}\n\nLAB REPORT:\n{lab_text}",
                use_rag=True, rag_query=lab_text,
            )
        parsed = self._safe_json_parse(response)
        return parsed or {"error": "Could not parse lab report", "raw": response}


"""
agents/medication_reminder.py — Build medication reminder schedules
"""
from datetime import datetime

class MedicationReminderAgent(BaseAgent):
    description = "Build intelligent medication schedules with WhatsApp reminder templates"
    category = "patient"

    SYSTEM_PROMPT = """You are a clinical pharmacist building medication reminder schedules for Indian patients.
Output ONLY valid JSON:
{
  "daily_schedule": [
    {
      "time": "HH:MM",
      "label": "Morning with breakfast",
      "medications": [
        {"drug_name": "string", "dosage": "string", "instructions": "string", "critical": true}
      ]
    }
  ],
  "total_medications": "number",
  "streak_goal": "30 days",
  "whatsapp_messages": {
    "morning_reminder": "Hinglish WhatsApp message",
    "evening_reminder": "string",
    "missed_dose": "string",
    "streak_achieved": "string"
  },
  "food_timing_notes": ["important food/timing instructions"],
  "refill_reminder_days": "number"
}
Mark cardiac/diabetes/BP/seizure medications as critical=true. Return ONLY JSON."""

    async def run(self, medications: list, patient_name: str = "Patient",
                  wake_time: str = "07:00", breakfast_time: str = "08:00",
                  lunch_time: str = "13:00", dinner_time: str = "20:00",
                  sleep_time: str = "22:00", language: str = "english") -> dict:
        med_list = "\n".join([
            f"- {m.get('drug_name','?')} {m.get('dosage','')} | {m.get('frequency_code','OD')} | "
            f"{m.get('duration_days','ongoing')}d | {m.get('instructions','none')}"
            for m in medications
        ])
        response = self._call_claude(
            self.SYSTEM_PROMPT,
            f"Schedule for {patient_name}:\nWake:{wake_time} Breakfast:{breakfast_time} "
            f"Lunch:{lunch_time} Dinner:{dinner_time} Sleep:{sleep_time}\n\nMeds:\n{med_list}",
        )
        parsed = self._safe_json_parse(response)
        if parsed:
            parsed["patient_name"] = patient_name
            parsed["generated_at"] = datetime.utcnow().isoformat()
            parsed["schema_version"] = "1.0.0"
        return parsed or {"error": "Could not generate schedule", "raw": response}
