"""
agents/chat_companion.py — Primary patient-facing conversational AI
"""
import logging
from typing import Optional
from agents.base import BaseAgent

logger = logging.getLogger("vitalos.agent.chat")

SYSTEM_PROMPT = """You are VitalOS, India's compassionate AI health companion.

Your role:
- Help patients understand their health conditions and medications
- Triage symptoms and recommend appropriate next steps
- Support Hindi, Telugu, Tamil, Kannada, Bengali, and English
- Guide patients toward the right healthcare resources in India

Rules:
- NEVER diagnose. Say "this may suggest" not "you have"
- Always recommend consulting a doctor for serious concerns
- Mention Indian-specific resources: PMJAY, Ayushman Bharat, Jan Aushadhi, 108 emergency
- For emergencies (chest pain, stroke, unconscious): immediately say "Call 108 now"
- Be warm, simple, and clear — many users are not medically literate
- Respond in the same language the patient writes in
- Keep responses concise for mobile screens (under 200 words unless detail needed)
"""

EMERGENCY_KEYWORDS = [
    "chest pain", "heart attack", "stroke", "unconscious", "not breathing",
    "heavy bleeding", "seizure", "anaphylaxis", "ambulance",
    "सीने में दर्द", "दिल का दौरा", "बेहोश",
]


class ChatCompanionAgent(BaseAgent):
    description = "Primary patient-facing conversational AI with symptom triage and health Q&A"
    category = "patient"
    _sessions: dict = {}

    async def run(self, message: str, session_id: str = "default",
                  language: str = "english", patient_context: Optional[dict] = None) -> dict:
        context_note = ""
        if patient_context:
            context_note = (
                f"\nPatient Profile:\n"
                f"- Age: {patient_context.get('age', 'unknown')}\n"
                f"- Conditions: {', '.join(patient_context.get('conditions', [])) or 'none'}\n"
                f"- Medications: {', '.join(patient_context.get('medications', [])) or 'none'}\n"
                f"- Allergies: {', '.join(patient_context.get('allergies', [])) or 'none'}\n"
            )

        history = self._sessions.get(session_id, [])
        history_text = ""
        if history:
            history_text = "\n".join([
                f"{'Patient' if h['role'] == 'user' else 'VitalOS'}: {h['content']}"
                for h in history[-6:]
            ])
            history_text = f"\n\nPrevious conversation:\n{history_text}\n"

        full_system = SYSTEM_PROMPT + (context_note or "")
        response = self._call_claude(
            system_prompt=full_system,
            user_message=f"{history_text}Patient: {message}",
            use_rag=True,
            rag_query=message,
        )

        if session_id not in self._sessions:
            self._sessions[session_id] = []
        self._sessions[session_id].append({"role": "user", "content": message})
        self._sessions[session_id].append({"role": "assistant", "content": response})
        self._sessions[session_id] = self._sessions[session_id][-20:]

        emergency_flag = any(kw in message.lower() for kw in EMERGENCY_KEYWORDS)
        return {
            "response": response,
            "emergency_flag": emergency_flag,
            "session_id": session_id,
            "suggested_action": "call_emergency" if emergency_flag else "continue_chat",
        }

    def clear_session(self, session_id: str):
        self._sessions.pop(session_id, None)
