"""
agents/preventive_health.py
"""
from agents.base import BaseAgent


class PreventiveHealthAgent(BaseAgent):
    description = "Preventive care: vaccinations, screenings, lifestyle by age/risk"
    category = "patient"

    async def run(self, age: int, gender: str, conditions: list = None,
                  location: str = "India") -> dict:
        response = self._call_claude(
            """Preventive health advisor for the Indian population.
Output ONLY valid JSON:
{
  "age_group_summary": "string",
  "vaccines_due": [{"vaccine":"string","dose":"string","due":"string","where_free":"string"}],
  "screenings_recommended": [{"test":"string","frequency":"string","why":"string","cost":"string"}],
  "lifestyle_targets": [{"area":"string","recommendation":"string","india_specific":true}],
  "diet_recommendations": ["India-specific advice"],
  "exercise_plan": "string",
  "mental_health_tips": ["string"],
  "government_schemes": ["applicable programs"]
}
Return ONLY JSON.""",
            f"Age: {age}, Gender: {gender}, Conditions: {conditions or []}, Location: {location}",
            use_rag=True, rag_query="preventive health vaccination screening India",
        )
        return self._safe_json_parse(response) or {"response": response}
