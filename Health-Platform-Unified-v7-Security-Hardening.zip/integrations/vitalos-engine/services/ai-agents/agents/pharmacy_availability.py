"""
agents/pharmacy_availability.py
"""
from agents.base import BaseAgent


class PharmacyAvailabilityAgent(BaseAgent):
    description = "Find nearby pharmacies with drug availability, generics, and price comparison"
    category = "patient"

    async def run(self, drugs: list, location: str = "Hyderabad") -> dict:
        response = self._call_claude(
            """Help Indian patients find medications affordably.
Output ONLY valid JSON:
{
  "drugs_summary": [
    {
      "drug": "string",
      "availability": "available|check_locally|order_online",
      "jan_aushadhi_available": true,
      "online_sources": ["PharmEasy","1mg","Netmeds"],
      "estimated_price_range": "₹20-50",
      "generic_available": true
    }
  ],
  "nearest_pharmacy_tips": ["string"],
  "online_delivery_note": "string",
  "jan_aushadhi_note": "string"
}
Return ONLY JSON.""",
            f"Find these drugs near {location}: {drugs}",
        )
        return self._safe_json_parse(response) or {"response": response}
