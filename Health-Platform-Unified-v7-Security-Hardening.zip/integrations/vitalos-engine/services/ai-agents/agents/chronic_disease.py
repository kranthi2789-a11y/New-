"""
agents/chronic_disease.py
"""
from agents.base import BaseAgent


class ChronicDiseaseAgent(BaseAgent):
    description = "Long-term monitoring for diabetes, hypertension, thyroid, asthma"
    category = "clinical"

    async def run(self, condition: str, patient_data: dict,
                  monitoring_history: list = None) -> dict:
        response = self._call_claude(
            """Chronic disease management specialist for India.
Output ONLY valid JSON:
{
  "condition_status": "controlled|partially_controlled|uncontrolled",
  "key_metrics": [{"metric":"string","current":"string","target":"string","status":"string"}],
  "medication_adherence_alert": false,
  "lifestyle_compliance": {"diet":"string","exercise":"string","sleep":"string"},
  "next_actions": [{"action":"string","priority":"high|medium|low","by_when":"string"}],
  "doctor_escalation_needed": false,
  "escalation_reason": "string or null",
  "monthly_monitoring_plan": ["what to track this month"]
}
Return ONLY JSON.""",
            f"Condition: {condition}\nData: {patient_data}\nHistory: {monitoring_history or []}",
            use_rag=True, rag_query=f"{condition} monitoring management India",
        )
        return self._safe_json_parse(response) or {"response": response}
