"""
agents/followup_automation.py
"""
from agents.base import BaseAgent


class FollowUpAutomationAgent(BaseAgent):
    description = "Auto-generate follow-up schedules and WhatsApp check-in messages post-visit"
    category = "clinical"

    async def run(self, diagnosis: str, visit_date: str, medications: list = None,
                  patient_name: str = "Patient", doctor_name: str = "your doctor") -> dict:
        response = self._call_claude(
            """Generate post-visit follow-up schedule for Indian patients.
Output ONLY valid JSON:
{
  "followup_schedule": [
    {"day":1,"type":"whatsapp_checkin|appointment|lab_test","message":"WhatsApp message","action_if_unwell":"string"}
  ],
  "red_flag_symptoms": ["symptoms requiring immediate doctor call"],
  "whatsapp_day1_message": "string",
  "whatsapp_day7_message": "string",
  "appointment_reminder_message": "string"
}
Return ONLY JSON.""",
            f"Diagnosis: {diagnosis}\nVisit: {visit_date}\nPatient: {patient_name}\n"
            f"Doctor: {doctor_name}\nMedications: {medications or []}",
        )
        return self._safe_json_parse(response) or {"response": response}
