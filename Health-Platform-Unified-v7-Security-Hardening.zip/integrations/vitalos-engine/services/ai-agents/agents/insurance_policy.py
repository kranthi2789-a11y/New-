"""
agents/insurance_policy.py
"""
from typing import Optional
from agents.base import BaseAgent

SYSTEM_PROMPT = """You are an Indian health insurance expert.
You know PM-JAY, Star Health, CGHS, ESI, HDFC Ergo, Niva Bupa, Max Bupa.
Output ONLY valid JSON:
{
  "policy_summary": "plain language explanation",
  "coverage_for_procedure": {
    "covered": true,
    "coverage_percentage": 80,
    "max_amount": "₹1,50,000",
    "pre_auth_required": true,
    "waiting_period_days": 30,
    "sub_limits": "string or null"
  },
  "pre_auth_steps": ["step 1", "step 2"],
  "documents_required": ["list"],
  "claim_tips": ["actionable tips"],
  "alternative_options": [{"option": "PM-JAY", "benefit": "string", "eligibility": "string"}],
  "cost_estimate": {"insured_amount": "string", "patient_liability": "string", "co_pay_percentage": 10},
  "important_exclusions": ["list"],
  "helpline_numbers": ["TPA helpline"]
}
Always mention PM-JAY if cost > ₹1L and patient may be eligible. Return ONLY JSON."""


class InsurancePolicyAgent(BaseAgent):
    description = "Insurance coverage analysis, pre-auth guidance, and claim tips"
    category = "patient"

    async def run(self, policy_details: str, procedure: str,
                  hospital_type: str = "private", patient_income_category: Optional[str] = None,
                  estimated_cost: Optional[str] = None) -> dict:
        notes = ""
        if patient_income_category:
            notes += f"\nPatient income: {patient_income_category}"
        if estimated_cost:
            notes += f"\nEstimated cost: {estimated_cost}"
        response = self._call_claude(
            SYSTEM_PROMPT,
            f"Analyze coverage:{notes}\n\nPOLICY:\n{policy_details}\n\nPROCEDURE: {procedure}\nHOSPITAL: {hospital_type}",
            use_rag=True, rag_query=f"insurance {procedure} India",
        )
        return self._safe_json_parse(response) or {"error": "Parse failed", "raw": response}
