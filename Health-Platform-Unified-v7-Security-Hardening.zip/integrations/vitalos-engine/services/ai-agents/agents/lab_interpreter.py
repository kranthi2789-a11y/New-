"""
agents/lab_interpreter.py
"""
import re
from typing import Optional
from agents.base import BaseAgent

SYSTEM_PROMPT = """You are a clinical pathologist AI for Indian patients.
Output ONLY valid JSON:
{
  "report_type": "CBC|LFT|KFT|Lipid|Thyroid|HbA1c|Urine|etc.",
  "lab_name": "string or null",
  "report_date": "string or null",
  "patient_summary": "2-3 sentence plain language summary",
  "values": [
    {
      "test_name": "string",
      "value": "string",
      "unit": "string",
      "reference_range": "string",
      "status": "normal|low|high|critical_low|critical_high",
      "plain_explanation": "1-2 sentences",
      "action_needed": "none|monitor|consult_doctor|urgent"
    }
  ],
  "flags": ["concerning findings"],
  "recommendations": ["actionable recommendations"],
  "follow_up_urgency": "routine|soon|urgent|emergency",
  "doctor_speciality_needed": "string or null",
  "lifestyle_tips": ["India-specific dietary and lifestyle advice"]
}
Use simple terms. Mention Jan Aushadhi, PMJAY, e-Sanjeevani where relevant. Return ONLY JSON."""


class LabInterpreterAgent(BaseAgent):
    description = "Parse and explain lab reports with India-specific clinical context"
    category = "clinical"

    async def run(self, lab_text: str, patient_age: Optional[int] = None,
                  patient_gender: str = "unknown", patient_conditions: Optional[list] = None,
                  image_base64: Optional[str] = None) -> dict:
        profile = f"Age: {patient_age or 'unknown'}, Gender: {patient_gender}"
        if patient_conditions:
            profile += f", Conditions: {', '.join(patient_conditions)}"

        if image_base64:
            response = self._call_claude_vision(
                SYSTEM_PROMPT, f"Patient: {profile}\n\nParse this lab report:", image_base64)
        else:
            response = self._call_claude(
                SYSTEM_PROMPT,
                f"Patient: {profile}\n\nLAB REPORT:\n{lab_text}",
                use_rag=True, rag_query=lab_text,
            )
        parsed = self._safe_json_parse(response)
        return parsed or {"error": "Could not parse lab report", "raw": response}
