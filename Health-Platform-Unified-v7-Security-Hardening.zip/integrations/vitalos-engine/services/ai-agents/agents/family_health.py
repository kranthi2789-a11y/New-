"""
agents/family_health.py
"""
from agents.base import BaseAgent


class FamilyHealthAgent(BaseAgent):
    description = "Unified family health management — members, shared records, family risk assessment"
    category = "patient"

    async def run(self, family_members: list, query: str) -> dict:
        response = self._call_claude(
            """You are a family health advisor for Indian families.
Output ONLY valid JSON:
{
  "family_summary": "string",
  "individual_alerts": [{"member":"string","alert":"string","priority":"high|medium|low"}],
  "shared_risk_factors": ["genetic or environmental risks"],
  "family_recommendations": ["actions for the whole family"],
  "vaccination_due": [{"member":"string","vaccine":"string","due_date":"string"}],
  "screening_calendar": [{"member":"string","test":"string","due":"string"}]
}
Return ONLY JSON.""",
            f"Family members:\n{family_members}\n\nQuery: {query}",
            use_rag=True, rag_query=query,
        )
        return self._safe_json_parse(response) or {"response": response}
