"""
agents/medication_reminder.py
"""
from datetime import datetime
from typing import Optional
from agents.base import BaseAgent

SYSTEM_PROMPT = """You are a clinical pharmacist building medication reminder schedules for Indian patients.
Output ONLY valid JSON:
{
  "daily_schedule": [
    {
      "time": "HH:MM",
      "label": "Morning with breakfast",
      "medications": [
        {"drug_name": "string", "dosage": "string", "instructions": "string", "critical": true}
      ]
    }
  ],
  "total_medications": 0,
  "streak_goal": "30 days",
  "whatsapp_messages": {
    "morning_reminder": "Hinglish message",
    "evening_reminder": "string",
    "missed_dose": "string",
    "streak_achieved": "string"
  },
  "food_timing_notes": ["important notes"],
  "refill_reminder_days": 7
}
AC=30min before food. PC=15min after food. HS=9-10PM. Mark cardiac/diabetes/BP as critical=true.
Return ONLY JSON."""


class MedicationReminderAgent(BaseAgent):
    description = "Build intelligent medication schedules with WhatsApp reminder templates"
    category = "patient"

    async def run(self, medications: list, patient_name: str = "Patient",
                  wake_time: str = "07:00", breakfast_time: str = "08:00",
                  lunch_time: str = "13:00", dinner_time: str = "20:00",
                  sleep_time: str = "22:00", language: str = "english") -> dict:
        med_list = "\n".join([
            f"- {m.get('drug_name','?')} {m.get('dosage','')} | {m.get('frequency_code','OD')} | "
            f"{m.get('duration_days','ongoing')}d"
            for m in medications
        ])
        response = self._call_claude(
            SYSTEM_PROMPT,
            f"Schedule for {patient_name}:\n"
            f"Wake:{wake_time} Breakfast:{breakfast_time} Lunch:{lunch_time} "
            f"Dinner:{dinner_time} Sleep:{sleep_time}\n\nMeds:\n{med_list}",
        )
        parsed = self._safe_json_parse(response)
        if parsed:
            parsed["patient_name"] = patient_name
            parsed["generated_at"] = datetime.utcnow().isoformat()
        return parsed or {"error": "Could not generate schedule", "raw": response}
