"""
services/whatsapp.py — Twilio WhatsApp service (actually called)

Used by:
  - OTP delivery (auth/router.py)
  - Medication reminders (roles/patient/prescriptions.py)
  - SOS broadcast (roles/patient/family.py)
  - Follow-up reminders (agents/followup_automation.py)
  - Lab result alerts

In development (no Twilio keys): messages are logged only.
"""

import os
import logging
from typing import Optional

logger = logging.getLogger("vitalos.whatsapp")

_twilio_client = None
_twilio_from = None


def _get_client():
    global _twilio_client, _twilio_from

    if _twilio_client:
        return _twilio_client

    sid   = os.getenv("TWILIO_ACCOUNT_SID", "")
    token = os.getenv("TWILIO_AUTH_TOKEN", "")
    _twilio_from = os.getenv("TWILIO_WHATSAPP_FROM", "whatsapp:+14155238886")

    if not sid or not token or sid.startswith("AC_YOUR"):
        logger.warning("Twilio credentials not configured — WhatsApp messages will be logged only")
        return None

    try:
        from twilio.rest import Client
        _twilio_client = Client(sid, token)
        logger.info("Twilio WhatsApp client initialised")
        return _twilio_client
    except ImportError:
        logger.error("twilio package not installed — pip install twilio")
        return None


async def send_whatsapp(to_number: str, message: str, media_url: Optional[str] = None) -> Optional[str]:
    """
    Send a WhatsApp message via Twilio.
    Returns Twilio SID on success, None on failure.
    to_number: E.164 format (+919876543210)
    """
    # Normalise number
    if not to_number.startswith("+"):
        to_number = "+91" + to_number.lstrip("0")

    client = _get_client()

    if not client:
        # Dev mode — just log
        logger.info(f"[WhatsApp DEV] To: {to_number}")
        logger.info(f"[WhatsApp DEV] Body: {message[:100]}...")
        return "DEV_SID_000"

    try:
        kwargs = {
            "from_": _twilio_from,
            "to":    f"whatsapp:{to_number}",
            "body":  message,
        }
        if media_url:
            kwargs["media_url"] = [media_url]

        msg = client.messages.create(**kwargs)
        logger.info(f"WhatsApp sent: sid={msg.sid} to={to_number[-4:].rjust(10,'*')}")
        return msg.sid
    except Exception as e:
        logger.error(f"WhatsApp send failed to {to_number}: {e}")
        raise


async def send_whatsapp_template(to_number: str, template: str, **kwargs) -> Optional[str]:
    """Send a named template message."""
    TEMPLATES = {
        "otp": "🏥 VitalOS\nYour OTP is: *{otp}*\nValid 10 minutes. Do not share.",
        "medication_reminder": (
            "⏰ *Medication Reminder — VitalOS*\n\n"
            "Dear {name}, time to take:\n"
            "💊 *{drug}* — {dosage}\n"
            "📋 Instructions: {instructions}\n\n"
            "Reply TAKEN ✅ or SKIP ❌"
        ),
        "lab_result": (
            "🔬 *Lab Report Ready — VitalOS*\n\n"
            "Dear {name}, your {report_type} results are ready.\n"
            "Status: {urgency}\n"
            "{summary}\n\n"
            "Consult your doctor at the earliest."
        ),
        "appointment_reminder": (
            "📅 *Appointment Reminder — VitalOS*\n\n"
            "Dear {name},\n"
            "Doctor: {doctor}\n"
            "Date: {date} at {time}\n"
            "Hospital: {hospital}\n\n"
            "Reply CONFIRM ✅ or CANCEL ❌"
        ),
        "sos_alert": (
            "🚨 *EMERGENCY ALERT — VitalOS*\n\n"
            "Your family member {patient_name} has triggered an SOS.\n"
            "Last known location: {location}\n"
            "Time: {timestamp}\n\n"
            "Please call them immediately or call 108."
        ),
        "followup": (
            "📋 *Follow-up Reminder — VitalOS*\n\n"
            "Dear {name},\n"
            "Your follow-up with {doctor} is due in {days} days.\n"
            "Condition: {condition}\n\n"
            "Please book your appointment or reply HELP."
        ),
        "bill_dispute": (
            "📑 *Bill Dispute Letter Ready — VitalOS*\n\n"
            "Dear {name},\n"
            "We've identified potential overcharges of ₹{amount} in your bill from {hospital}.\n"
            "A formal dispute letter has been generated.\n"
            "Open VitalOS to download and send."
        ),
    }

    template_body = TEMPLATES.get(template, "{message}")
    message = template_body.format(**kwargs)
    return await send_whatsapp(to_number, message)
