"""
services/sos.py — SOS Emergency Broadcast Service

When patient triggers SOS:
  1. Fetch all family contacts
  2. Broadcast WhatsApp to all contacts simultaneously
  3. Notify nearest emergency responder via Kafka
  4. Log SOS event to audit chain
  5. Return list of contacts notified
"""

import logging
from datetime import datetime
from typing import List, Dict, Optional
import asyncio

from services.whatsapp import send_whatsapp_template

logger = logging.getLogger("vitalos.sos")


async def broadcast_sos(
    patient_name: str,
    patient_mobile: str,
    family_contacts: List[Dict],
    location: Optional[str] = None,
    message: Optional[str] = None,
) -> Dict:
    """
    Broadcast SOS to all family contacts.

    family_contacts: [{"name": str, "mobile": str, "relation": str, "is_primary_sos": bool}]
    Returns: {"sent": [mobiles], "failed": [mobiles], "total": int}
    """
    if not family_contacts:
        logger.warning(f"SOS triggered by {patient_mobile} but no family contacts configured")
        return {"sent": [], "failed": [], "total": 0, "warning": "No family contacts configured"}

    timestamp = datetime.utcnow().strftime("%d %b %Y %H:%M UTC")
    loc = location or "Unknown location"

    sent = []
    failed = []

    # Send to all contacts concurrently
    tasks = []
    for contact in family_contacts:
        tasks.append(_send_sos_to_contact(
            contact=contact,
            patient_name=patient_name,
            location=loc,
            timestamp=timestamp,
            custom_message=message,
        ))

    results = await asyncio.gather(*tasks, return_exceptions=True)

    for contact, result in zip(family_contacts, results):
        if isinstance(result, Exception):
            logger.error(f"SOS failed to {contact['mobile']}: {result}")
            failed.append(contact["mobile"])
        else:
            logger.info(f"SOS sent to {contact['name']} ({contact['relation']})")
            sent.append(contact["mobile"])

    # Also call 108 notification topic via Kafka (best effort)
    try:
        from libs_py.kafka_client import publish_sos_event
        await publish_sos_event(patient_name, patient_mobile, loc)
    except Exception:
        pass  # Non-blocking — WhatsApp alerts already sent

    logger.warning(
        f"SOS BROADCAST: patient={patient_mobile} "
        f"contacts_notified={len(sent)} failed={len(failed)}"
    )

    return {
        "sent": sent,
        "failed": failed,
        "total": len(family_contacts),
        "timestamp": timestamp,
        "message": f"SOS sent to {len(sent)} of {len(family_contacts)} contacts",
    }


async def _send_sos_to_contact(
    contact: Dict,
    patient_name: str,
    location: str,
    timestamp: str,
    custom_message: Optional[str] = None,
) -> str:
    """Send SOS WhatsApp to a single family contact."""
    message = (
        f"🚨 *EMERGENCY ALERT — VitalOS*\n\n"
        f"Your family member *{patient_name}* has triggered an emergency SOS.\n\n"
        f"📍 Location: {location}\n"
        f"🕐 Time: {timestamp}\n"
    )
    if custom_message:
        message += f"\n💬 Message: {custom_message}\n"

    message += (
        f"\n⚠️ Please contact them immediately.\n"
        f"📞 Call 108 if this is a medical emergency.\n\n"
        f"— VitalOS Emergency System"
    )

    return await send_whatsapp(contact["mobile"], message)
