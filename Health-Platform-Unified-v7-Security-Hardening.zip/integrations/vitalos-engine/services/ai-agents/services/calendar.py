"""
services/calendar.py — iCal / calendar integration for medication schedules

Generates .ics files that patients can import into:
  - Google Calendar
  - Apple Calendar
  - Outlook
  - Any iCal-compatible app

Also generates Google Calendar deep-link for one-tap add.
"""

import uuid
from datetime import datetime, timedelta
from typing import List, Dict


def generate_ical(events: List[Dict]) -> str:
    """
    Generate an iCalendar (.ics) string from a list of events.

    Each event dict:
      {
        "title":       "💊 Metformin 500mg",
        "description": "Take with food. Before: 07:30",
        "date":        "2025-04-14",   # YYYY-MM-DD
        "time":        "07:30",         # HH:MM (IST)
        "duration_min": 5,
        "repeat":      "DAILY",         # DAILY | WEEKLY | None
        "repeat_end":  "2025-05-14",   # Optional
      }
    """
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//VitalOS//Clinical OS//EN",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        "X-WR-CALNAME:VitalOS Medications",
        "X-WR-TIMEZONE:Asia/Kolkata",
        "BEGIN:VTIMEZONE",
        "TZID:Asia/Kolkata",
        "BEGIN:STANDARD",
        "DTSTART:19700101T000000",
        "TZOFFSETFROM:+0530",
        "TZOFFSETTO:+0530",
        "TZNAME:IST",
        "END:STANDARD",
        "END:VTIMEZONE",
    ]

    for ev in events:
        dt_str = f"{ev['date'].replace('-', '')}T{ev['time'].replace(':', '')}00"
        uid = str(uuid.uuid4())
        duration = ev.get("duration_min", 5)
        start = datetime.strptime(f"{ev['date']} {ev['time']}", "%Y-%m-%d %H:%M")
        end   = start + timedelta(minutes=duration)
        end_str = end.strftime("%Y%m%dT%H%M%S")

        lines += [
            "BEGIN:VEVENT",
            f"UID:{uid}@vitalos.in",
            f"DTSTART;TZID=Asia/Kolkata:{dt_str}",
            f"DTEND;TZID=Asia/Kolkata:{end_str}",
            f"SUMMARY:{ev['title']}",
            f"DESCRIPTION:{ev.get('description', '').replace(chr(10), '\\n')}",
            "LOCATION:Home",
            "STATUS:CONFIRMED",
            "TRANSP:TRANSPARENT",
        ]

        # Recurrence
        if ev.get("repeat") == "DAILY":
            rrule = "RRULE:FREQ=DAILY"
            if ev.get("repeat_end"):
                until = ev["repeat_end"].replace("-", "") + "T235959Z"
                rrule += f";UNTIL={until}"
            lines.append(rrule)
        elif ev.get("repeat") == "WEEKLY":
            rrule = "RRULE:FREQ=WEEKLY"
            if ev.get("repeat_end"):
                until = ev["repeat_end"].replace("-", "") + "T235959Z"
                rrule += f";UNTIL={until}"
            lines.append(rrule)

        # Alarm: 5 min before
        lines += [
            "BEGIN:VALARM",
            "TRIGGER:-PT5M",
            "ACTION:DISPLAY",
            f"DESCRIPTION:Time for {ev['title']}",
            "END:VALARM",
            "END:VEVENT",
        ]

    lines.append("END:VCALENDAR")
    return "\r\n".join(lines)


def prescription_to_calendar_events(
    medications: List[Dict],
    start_date: str,
    duration_days: int = 30,
) -> List[Dict]:
    """
    Convert parsed prescription medications into calendar events.

    medications: list of {drug_name, dosage, reminder_times, instructions, duration_days}
    start_date: "YYYY-MM-DD"
    """
    events = []
    end_date_str = _add_days(start_date, min(duration_days, 90))

    for med in medications:
        drug = med.get("drug_name", "Medication")
        dosage = med.get("dosage", "")
        instructions = med.get("instructions", "As directed")
        times = med.get("reminder_times", ["08:00"])
        dur = med.get("duration_days") or duration_days

        actual_end = _add_days(start_date, min(int(dur), 90))

        for t in times:
            events.append({
                "title":        f"💊 {drug} {dosage}".strip(),
                "description":  f"Instructions: {instructions}\nDrug: {drug}\nDosage: {dosage}\nAdded by VitalOS",
                "date":         start_date,
                "time":         t,
                "duration_min": 5,
                "repeat":       "DAILY",
                "repeat_end":   actual_end,
            })

    return events


def _add_days(date_str: str, days: int) -> str:
    """Add days to YYYY-MM-DD string."""
    dt = datetime.strptime(date_str, "%Y-%m-%d") + timedelta(days=days)
    return dt.strftime("%Y-%m-%d")


def google_calendar_link(title: str, date: str, time: str, description: str = "") -> str:
    """One-tap Google Calendar add link."""
    from urllib.parse import quote
    start = f"{date.replace('-', '')}T{time.replace(':', '')}00"
    end_dt = datetime.strptime(f"{date} {time}", "%Y-%m-%d %H:%M") + timedelta(minutes=30)
    end = end_dt.strftime("%Y%m%dT%H%M%S")
    base = "https://calendar.google.com/calendar/render?action=TEMPLATE"
    return f"{base}&text={quote(title)}&dates={start}/{end}&details={quote(description)}&sf=true&output=xml"
