"""
override/override_service.py — Human Override System

Allows authorised clinicians to manually override AI agent suggestions.
Every override requires:
  - Justification (free text)
  - Approving clinician ID + role
  - Written to audit trail BEFORE applying

Override does NOT break sequence integrity — it publishes a new
VitalOS event through the normal Kafka pipeline with override_flag=True.
The Orchestrator processes it identically — the audit just captures the override.
"""

from __future__ import annotations
import logging
import uuid
import hashlib
from datetime import datetime
from typing import Optional, Dict

from fastapi import APIRouter, Depends, HTTPException, Body
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from main import verify_token

logger = logging.getLogger("vitalos.override")
override_router = APIRouter(prefix="/override", tags=["override"])

OVERRIDE_ALLOWED_ROLES = ("doctor", "admin")


class OverrideRequest(BaseModel):
    case_id: str
    current_state: str
    target_state: str
    justification: str       # Mandatory — minimum 20 chars
    clinical_basis: str      # e.g. "Clinical assessment overrides AI triage"
    risk_acknowledgement: bool = False  # Must be True for EMERGENCY downgrades


@override_router.post("/apply", summary="Manual clinical override of AI suggestion")
async def apply_override(
    req: OverrideRequest,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    # Role check
    if me["role"] not in OVERRIDE_ALLOWED_ROLES:
        raise HTTPException(403, f"Override requires role in {OVERRIDE_ALLOWED_ROLES}")

    # Justification minimum length
    if len(req.justification.strip()) < 20:
        raise HTTPException(400, "Justification must be at least 20 characters")

    # Downgrade from EMERGENCY requires explicit acknowledgement
    if "ESCALATED" in req.current_state and not req.risk_acknowledgement:
        raise HTTPException(400,
            "Downgrading an EMERGENCY/ESCALATED case requires risk_acknowledgement=true")

    override_id = str(uuid.uuid4())
    timestamp   = datetime.utcnow().isoformat()
    idempotency = hashlib.sha256(
        f"{req.case_id}:override:{timestamp}:{me['sub']}".encode()
    ).hexdigest()

    # Log override to DB before publishing
    await db.execute(text("""
        INSERT INTO override_log
        (id, case_id, overriding_user_id, overriding_role, overriding_name,
         from_state, to_state, justification, clinical_basis,
         risk_acknowledged, created_at)
        VALUES (:id, :cid, :uid, :role, :name, :from_s, :to_s,
                :just, :basis, :risk_ack, NOW())
    """), {
        "id": override_id, "cid": req.case_id,
        "uid": me["sub"], "role": me["role"], "name": me["name"],
        "from_s": req.current_state, "to_s": req.target_state,
        "just": req.justification, "basis": req.clinical_basis,
        "risk_ack": req.risk_acknowledgement,
    })
    await db.commit()

    # Publish override event to Kafka (standard pipeline — no schema change)
    try:
        from core.kafka_helper import publish_to_kafka
        event = {
            "header": {
                "event_id": str(uuid.uuid4()),
                "trace_id": f"override-{override_id}",
                "sequence_number": 999,      # Orchestrator will validate + adjust
                "idempotency_key": idempotency,
                "timestamp": int(datetime.utcnow().timestamp() * 1000),
                "origin": f"override:doctor:{me['sub']}",
                "schema_version": "1.0.0",
                "agent_version": "1.0.0",
            },
            "payload": {
                "case_id": req.case_id,
                "suggested_state": req.target_state,
                "confidence_score": 1.0,       # Human = highest confidence
                "risk_level": "MEDIUM",
                "inference_trace": f"HUMAN_OVERRIDE:{me['role']}:{override_id}",
                "data": {
                    "override_id": override_id,
                    "override_flag": True,
                    "justification": req.justification,
                    "clinical_basis": req.clinical_basis,
                    "approved_by": me["name"],
                    "override_timestamp": timestamp,
                },
            },
            "priority": 8,
        }
        await publish_to_kafka("vitalos.case.events", req.case_id, event)
    except Exception as e:
        logger.warning(f"Override Kafka publish failed (DB log exists): {e}")

    logger.warning(
        f"HUMAN OVERRIDE: case={req.case_id} "
        f"{req.current_state}→{req.target_state} "
        f"by={me['name']} ({me['role']}) "
        f"justification='{req.justification[:50]}'"
    )

    return {
        "override_id": override_id,
        "case_id": req.case_id,
        "from_state": req.current_state,
        "to_state": req.target_state,
        "approved_by": me["name"],
        "approved_at": timestamp,
        "audit_logged": True,
        "kafka_published": True,
        "message": "Override submitted. Orchestrator will process through normal pipeline with override flag.",
    }


@override_router.get("/log/{case_id}", summary="View override history for a case")
async def override_log(
    case_id: str,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if me["role"] not in ("doctor", "admin"):
        raise HTTPException(403, "Doctor/Admin only")

    result = await db.execute(text(
        "SELECT * FROM override_log WHERE case_id=:cid ORDER BY created_at DESC"
    ), {"cid": case_id})
    rows = result.fetchall()
    return {"case_id": case_id, "overrides": [dict(r._mapping) for r in rows]}
