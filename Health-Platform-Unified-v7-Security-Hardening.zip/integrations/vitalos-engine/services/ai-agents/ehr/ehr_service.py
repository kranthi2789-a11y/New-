"""
ehr/ehr_service.py — Longitudinal Electronic Health Record

Patient timeline view aggregating:
  - All visits / cases
  - Prescriptions
  - Lab reports
  - Vitals trends
  - Diagnoses history
  - Allergies + alerts
  - Clinical summaries

This is a READ layer — it does not write to the audit chain.
All writes continue through existing roles/* routers.
"""

from __future__ import annotations
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from main import verify_token

logger = logging.getLogger("vitalos.ehr")
ehr_router = APIRouter(prefix="/ehr", tags=["ehr"])


def _role_can_view_ehr(role: str, patient_id: str, user_id: str) -> bool:
    """Patients see own EHR. Doctors/Nurses/Admin see all."""
    if role in ("doctor", "nurse", "admin", "emergency_responder"):
        return True
    if role == "patient" and user_id == patient_id:
        return True
    return False


# ── FULL PATIENT TIMELINE ─────────────────────────────────────

@ehr_router.get("/patient/{patient_id}/timeline", summary="Full patient health timeline")
async def patient_timeline(
    patient_id: str,
    limit: int = 50,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if not _role_can_view_ehr(me["role"], patient_id, me["sub"]):
        raise HTTPException(403, "Access denied")

    timeline_events = []

    # 1. Clinical cases
    cases = await db.execute(text("""
        SELECT case_id, current_state, risk_level, created_at, updated_at
        FROM case_state_machine
        WHERE case_id IN (
            SELECT DISTINCT case_id FROM global_audit_trail
            WHERE payload::text LIKE :pid_pattern
        )
        ORDER BY created_at DESC LIMIT 20
    """), {"pid_pattern": f"%{patient_id}%"})
    for r in cases.fetchall():
        timeline_events.append({
            "type": "CASE",
            "date": str(r.created_at),
            "title": f"Clinical Case — {r.current_state.replace('_',' ')}",
            "detail": {"case_id": r.case_id, "risk": r.risk_level, "state": r.current_state},
            "icon": "🏥",
        })

    # 2. Prescriptions
    rx_result = await db.execute(text("""
        SELECT id, doctor_name, diagnosis, medications, created_at
        FROM prescriptions WHERE patient_mobile=(
            SELECT mobile FROM users WHERE id=:pid LIMIT 1
        )
        ORDER BY created_at DESC LIMIT 10
    """), {"pid": patient_id})
    for r in rx_result.fetchall():
        timeline_events.append({
            "type": "PRESCRIPTION",
            "date": str(r.created_at),
            "title": f"Prescription — {r.diagnosis or 'General'}",
            "detail": {"doctor": r.doctor_name, "medications": r.medications},
            "icon": "💊",
        })

    # 3. Lab reports
    lab_result = await db.execute(text("""
        SELECT id, report_type, flags, follow_up_urgency, created_at
        FROM lab_reports WHERE patient_mobile=(
            SELECT mobile FROM users WHERE id=:pid LIMIT 1
        )
        ORDER BY created_at DESC LIMIT 10
    """), {"pid": patient_id})
    for r in lab_result.fetchall():
        timeline_events.append({
            "type": "LAB_REPORT",
            "date": str(r.created_at),
            "title": f"Lab Report — {r.report_type}",
            "detail": {"flags": r.flags, "urgency": r.follow_up_urgency},
            "icon": "🔬",
        })

    # 4. Vitals entries
    vitals_result = await db.execute(text("""
        SELECT systolic_bp, diastolic_bp, heart_rate, spo2,
               temperature, blood_glucose, recorded_at
        FROM vitals WHERE patient_id=:pid
        ORDER BY recorded_at DESC LIMIT 10
    """), {"pid": patient_id})
    for r in vitals_result.fetchall():
        timeline_events.append({
            "type": "VITALS",
            "date": str(r.recorded_at),
            "title": f"Vitals Recorded",
            "detail": {
                "bp": f"{r.systolic_bp}/{r.diastolic_bp}" if r.systolic_bp else None,
                "hr": r.heart_rate, "spo2": r.spo2,
                "temp": str(r.temperature), "glucose": r.blood_glucose,
            },
            "icon": "📊",
        })

    # 5. Appointments
    appt_result = await db.execute(text("""
        SELECT id, scheduled_at, status, notes FROM appointments
        WHERE patient_id=:pid ORDER BY scheduled_at DESC LIMIT 10
    """), {"pid": patient_id})
    for r in appt_result.fetchall():
        timeline_events.append({
            "type": "APPOINTMENT",
            "date": str(r.scheduled_at),
            "title": f"Appointment — {r.status.upper()}",
            "detail": {"notes": r.notes},
            "icon": "📅",
        })

    # Sort by date descending
    timeline_events.sort(key=lambda x: x.get("date") or "", reverse=True)

    return {
        "patient_id": patient_id,
        "timeline": timeline_events[:limit],
        "total_events": len(timeline_events),
        "generated_at": datetime.utcnow().isoformat(),
    }


# ── VITALS TREND ──────────────────────────────────────────────

@ehr_router.get("/patient/{patient_id}/vitals-trend", summary="Vitals trend over time")
async def vitals_trend(
    patient_id: str,
    days: int = 90,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if not _role_can_view_ehr(me["role"], patient_id, me["sub"]):
        raise HTTPException(403, "Access denied")

    result = await db.execute(text("""
        SELECT systolic_bp, diastolic_bp, heart_rate, spo2,
               temperature, blood_glucose, weight_kg, recorded_at
        FROM vitals
        WHERE patient_id=:pid
          AND recorded_at > NOW() - INTERVAL ':days days'
        ORDER BY recorded_at ASC
    """.replace(":days days", f"{days} days")), {"pid": patient_id})
    rows = result.fetchall()

    return {
        "patient_id": patient_id,
        "period_days": days,
        "data_points": len(rows),
        "vitals": [dict(r._mapping) for r in rows],
        "summary": _compute_vitals_summary(rows),
    }


def _compute_vitals_summary(rows) -> Dict:
    if not rows:
        return {}
    sbp_vals = [r.systolic_bp for r in rows if r.systolic_bp]
    hr_vals  = [r.heart_rate for r in rows if r.heart_rate]
    spo2_vals = [r.spo2 for r in rows if r.spo2]
    summary = {}
    if sbp_vals:
        summary["bp"] = {"min": min(sbp_vals), "max": max(sbp_vals),
                         "avg": round(sum(sbp_vals)/len(sbp_vals), 1)}
    if hr_vals:
        summary["hr"] = {"min": min(hr_vals), "max": max(hr_vals),
                         "avg": round(sum(hr_vals)/len(hr_vals), 1)}
    if spo2_vals:
        summary["spo2"] = {"min": min(spo2_vals), "max": max(spo2_vals),
                           "avg": round(sum(spo2_vals)/len(spo2_vals), 1)}
    return summary


# ── CLINICAL SUMMARY ──────────────────────────────────────────

@ehr_router.get("/patient/{patient_id}/summary", summary="AI clinical summary")
async def clinical_summary(
    patient_id: str,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if not _role_can_view_ehr(me["role"], patient_id, me["sub"]):
        raise HTTPException(403, "Access denied")

    user_result = await db.execute(text(
        "SELECT name, mobile, abha_id, created_at FROM users WHERE id=:pid"
    ), {"pid": patient_id})
    user = user_result.fetchone()

    patient_result = await db.execute(text(
        "SELECT conditions, allergies, blood_group, medications FROM patients WHERE mobile=:m LIMIT 1"
    ), {"m": user.mobile if user else ""})
    patient = patient_result.fetchone()

    # Latest vitals
    vitals_result = await db.execute(text(
        "SELECT * FROM vitals WHERE patient_id=:pid ORDER BY recorded_at DESC LIMIT 1"
    ), {"pid": patient_id})
    latest_vitals = vitals_result.fetchone()

    # Count events
    rx_count = (await db.execute(text(
        "SELECT COUNT(*) FROM prescriptions WHERE patient_mobile=:m"
    ), {"m": user.mobile if user else ""})).scalar() or 0

    lab_count = (await db.execute(text(
        "SELECT COUNT(*) FROM lab_reports WHERE patient_mobile=:m"
    ), {"m": user.mobile if user else ""})).scalar() or 0

    return {
        "patient_id": patient_id,
        "name": user.name if user else "Unknown",
        "abha_id": user.abha_id if user else None,
        "registered_since": str(user.created_at) if user else None,
        "conditions": patient.conditions if patient else [],
        "allergies": patient.allergies if patient else [],
        "blood_group": patient.blood_group if patient else None,
        "current_medications": patient.medications if patient else [],
        "latest_vitals": dict(latest_vitals._mapping) if latest_vitals else None,
        "summary_stats": {
            "total_prescriptions": rx_count,
            "total_lab_reports": lab_count,
        },
        "generated_at": datetime.utcnow().isoformat(),
        "data_source": "VitalOS EHR Layer v4.0",
    }


# ── ALLERGY + ALERT REGISTER ──────────────────────────────────

@ehr_router.get("/patient/{patient_id}/alerts", summary="Allergy and clinical alerts")
async def patient_alerts(
    patient_id: str,
    me=Depends(verify_token),
    db: AsyncSession = Depends(get_db),
):
    if not _role_can_view_ehr(me["role"], patient_id, me["sub"]):
        raise HTTPException(403, "Access denied")

    result = await db.execute(text(
        "SELECT conditions, allergies, medications FROM patients WHERE mobile=("
        "SELECT mobile FROM users WHERE id=:pid LIMIT 1)"
    ), {"pid": patient_id})
    row = result.fetchone()

    alerts = []
    if row:
        for allergy in (row.allergies or []):
            alerts.append({
                "type": "ALLERGY", "severity": "HIGH",
                "message": f"Allergy: {allergy}", "action": "Avoid prescribing"
            })
        for cond in (row.conditions or []):
            if any(x in cond.lower() for x in ["diabetes", "hypertension", "cardiac"]):
                alerts.append({
                    "type": "CHRONIC_CONDITION", "severity": "MEDIUM",
                    "message": f"Known: {cond}", "action": "Consider drug interactions"
                })

    return {"patient_id": patient_id, "alerts": alerts, "total": len(alerts)}
