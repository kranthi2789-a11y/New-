"""
analytics/analytics_engine.py — VitalOS Analytics Engine

Tracks:
  - Escalation rates by risk level, specialty, department
  - SLA breach trends
  - Agent confidence drift over time
  - Mortality risk trends (proxy via EMERGENCY escalations)
  - System throughput and performance metrics

All analytics are AGGREGATED — no raw PII in analytics queries.
"""

from __future__ import annotations
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from main import verify_token

logger = logging.getLogger("vitalos.analytics")
analytics_router = APIRouter(prefix="/analytics", tags=["analytics"])


def analytics_access(token=Depends(verify_token)):
    if token["role"] not in ("admin", "doctor"):
        raise HTTPException(403, "Admin/Doctor only")
    return token


# ── Escalation Rate Analytics ─────────────────────────────────

@analytics_router.get("/escalation-rate", summary="Escalation rate by risk and period")
async def escalation_rate(
    days: int = 30,
    me=Depends(analytics_access),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(text("""
        SELECT
            risk_level,
            current_state,
            COUNT(*) as count,
            DATE_TRUNC('day', created_at) as day
        FROM case_state_machine
        WHERE created_at > NOW() - INTERVAL ':days days'
        GROUP BY risk_level, current_state, day
        ORDER BY day DESC
    """.replace(":days days", f"{days} days")))
    rows = result.fetchall()

    total = sum(r.count for r in rows)
    escalated = sum(r.count for r in rows if r.current_state == "ESCALATED")
    emergency = sum(r.count for r in rows if r.risk_level == "EMERGENCY")

    return {
        "period_days": days,
        "total_cases": total,
        "escalated_cases": escalated,
        "escalation_rate_pct": round(escalated / total * 100, 1) if total else 0,
        "emergency_cases": emergency,
        "emergency_rate_pct": round(emergency / total * 100, 1) if total else 0,
        "by_risk": {
            risk: sum(r.count for r in rows if r.risk_level == risk)
            for risk in ("EMERGENCY", "HIGH", "MEDIUM", "LOW")
        },
        "by_state": {
            state: sum(r.count for r in rows if r.current_state == state)
            for state in ("TRIAGE_PENDING", "TRIAGE_COMPLETED",
                          "DOCTOR_REVIEW_PENDING", "ROUTING_PENDING",
                          "CLOSED", "ESCALATED")
        },
    }


# ── SLA Breach Trends ─────────────────────────────────────────

@analytics_router.get("/sla-breaches", summary="SLA breach trends")
async def sla_breach_trends(
    days: int = 30,
    me=Depends(analytics_access),
    db: AsyncSession = Depends(get_db),
):
    try:
        result = await db.execute(text("""
            SELECT
                state, risk_level,
                COUNT(*) as breach_count,
                AVG(breach_seconds) as avg_breach_secs,
                MAX(breach_seconds) as max_breach_secs
            FROM sla_breaches
            WHERE detected_at > NOW() - INTERVAL ':days days'
            GROUP BY state, risk_level
            ORDER BY breach_count DESC
        """.replace(":days days", f"{days} days")))
        rows = result.fetchall()
        return {
            "period_days": days,
            "total_breaches": sum(r.breach_count for r in rows),
            "by_state_risk": [dict(r._mapping) for r in rows],
        }
    except Exception:
        return {"period_days": days, "total_breaches": 0, "by_state_risk": [],
                "note": "sla_breaches table may not exist yet — run setup.sh to apply migrations"}


# ── Agent Confidence Drift ────────────────────────────────────

@analytics_router.get("/confidence-drift", summary="Agent confidence score drift over time")
async def confidence_drift(
    days: int = 30,
    me=Depends(analytics_access),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(text("""
        SELECT
            agent_name,
            AVG(confidence_score) as avg_confidence,
            MIN(confidence_score) as min_confidence,
            COUNT(*) as total_calls,
            COUNT(*) FILTER (WHERE confidence_score < 0.7) as low_confidence_calls,
            DATE_TRUNC('week', created_at) as week
        FROM agent_logs
        WHERE created_at > NOW() - INTERVAL ':days days'
        GROUP BY agent_name, week
        ORDER BY week DESC
    """.replace(":days days", f"{days} days")))
    rows = result.fetchall()

    agents_at_risk = [
        r.agent_name for r in rows
        if r.avg_confidence and r.avg_confidence < 0.75
    ]

    return {
        "period_days": days,
        "agents_with_low_confidence": list(set(agents_at_risk)),
        "confidence_data": [dict(r._mapping) for r in rows[:100]],
        "alert": (
            f"⚠ {len(agents_at_risk)} agent(s) showing confidence below 0.75"
            if agents_at_risk else "✅ All agents confidence nominal"
        ),
    }


# ── Clinical Outcome Metrics ──────────────────────────────────

@analytics_router.get("/outcomes", summary="Clinical outcome metrics")
async def clinical_outcomes(
    days: int = 30,
    me=Depends(analytics_access),
    db: AsyncSession = Depends(get_db),
):
    closed = (await db.execute(text(f"""
        SELECT COUNT(*) FROM case_state_machine
        WHERE current_state='CLOSED'
        AND updated_at > NOW() - INTERVAL '{days} days'
    """))).scalar() or 0

    escalated = (await db.execute(text(f"""
        SELECT COUNT(*) FROM case_state_machine
        WHERE current_state='ESCALATED'
        AND updated_at > NOW() - INTERVAL '{days} days'
    """))).scalar() or 0

    total = closed + escalated + 1

    vitals_critical = (await db.execute(text(f"""
        SELECT COUNT(*) FROM vitals
        WHERE (spo2 < 90 OR systolic_bp > 180 OR systolic_bp < 80)
        AND recorded_at > NOW() - INTERVAL '{days} days'
    """))).scalar() or 0

    no_shows = (await db.execute(text(f"""
        SELECT COUNT(*) FROM appointments
        WHERE status='no_show'
        AND scheduled_at > NOW() - INTERVAL '{days} days'
    """))).scalar() or 0

    total_appts = (await db.execute(text(f"""
        SELECT COUNT(*) FROM appointments
        WHERE scheduled_at > NOW() - INTERVAL '{days} days'
    """))).scalar() or 1

    return {
        "period_days": days,
        "cases": {"closed": closed, "escalated": escalated},
        "closure_rate_pct": round(closed / total * 100, 1),
        "critical_vitals_events": vitals_critical,
        "appointment_no_show_rate_pct": round(no_shows / total_appts * 100, 1),
        "generated_at": datetime.utcnow().isoformat(),
    }


# ── System Performance ────────────────────────────────────────

@analytics_router.get("/system-performance", summary="System throughput and agent performance")
async def system_performance(
    hours: int = 24,
    me=Depends(analytics_access),
    db: AsyncSession = Depends(get_db),
):
    audit_count = (await db.execute(text(f"""
        SELECT COUNT(*) FROM global_audit_trail
        WHERE created_at > NOW() - INTERVAL '{hours} hours'
    """))).scalar() or 0

    agent_calls = (await db.execute(text(f"""
        SELECT COUNT(*), AVG(latency_ms) as avg_latency
        FROM agent_logs
        WHERE created_at > NOW() - INTERVAL '{hours} hours'
    """))).fetchone()

    return {
        "period_hours": hours,
        "audit_entries": audit_count,
        "agent_calls": agent_calls[0] if agent_calls else 0,
        "avg_agent_latency_ms": round(agent_calls[1] or 0, 1) if agent_calls else 0,
        "events_per_hour": round(audit_count / hours, 1),
        "system_mode": "NORMAL",
        "generated_at": datetime.utcnow().isoformat(),
    }
