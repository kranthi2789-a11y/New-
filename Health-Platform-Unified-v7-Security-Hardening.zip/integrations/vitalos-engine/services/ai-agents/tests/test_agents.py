"""
tests/test_agents.py — VitalOS AI Agents full test suite
Run: pytest tests/ -v --asyncio-mode=auto
"""

import pytest
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


# ── 1. All 16 agents import correctly ─────────────────────────

def test_all_16_agents_import():
    from agents.chat_companion import ChatCompanionAgent
    from agents.prescription_intel import PrescriptionIntelAgent
    from agents.medication_reminder import MedicationReminderAgent
    from agents.lab_interpreter import LabInterpreterAgent
    from agents.insurance_policy import InsurancePolicyAgent
    from agents.health_risk import HealthRiskAgent
    from agents.hospital_discovery import HospitalDiscoveryAgent
    from agents.doctor_productivity import DoctorProductivityAgent
    from agents.emergency_response import EmergencyResponseAgent
    from agents.family_health import FamilyHealthAgent
    from agents.cost_optimizer import CostOptimizerAgent
    from agents.pharmacy_availability import PharmacyAvailabilityAgent
    from agents.followup_automation import FollowUpAutomationAgent
    from agents.chronic_disease import ChronicDiseaseAgent
    from agents.preventive_health import PreventiveHealthAgent
    from agents.bill_analyzer import BillAnalyzerAgent
    assert True


# ── 2. Orchestrator loads exactly 16 ──────────────────────────

def test_orchestrator_initializes_16_agents():
    from agents.orchestrator import AgentOrchestrator
    AgentOrchestrator.initialize()
    agents = AgentOrchestrator.list_agents()
    assert len(agents) == 16


def test_orchestrator_raises_on_unknown_agent():
    from agents.orchestrator import AgentOrchestrator
    AgentOrchestrator.initialize()
    with pytest.raises(ValueError, match="Unknown agent"):
        AgentOrchestrator.get("nonexistent_agent_xyz")


def test_all_agents_have_description_and_category():
    from agents.orchestrator import AgentOrchestrator
    AgentOrchestrator.initialize()
    for agent in AgentOrchestrator.list_agents():
        assert agent["description"], f"Agent {agent['key']} has no description"
        assert agent["category"], f"Agent {agent['key']} has no category"
        assert agent["agent_version"] == "1.0.0"


# ── 3. Contract validation ─────────────────────────────────────

def test_agent_contract_rejects_invalid_state():
    from pydantic import ValidationError
    from contract import AgentInferenceResponse
    with pytest.raises(ValidationError):
        AgentInferenceResponse(
            case_id="test",
            suggested_state="INVALID_STATE",
            confidence_score=0.9,
            risk_level="LOW",
            metadata={},
            trace_id="t1",
            inference_trace="test",
        )


def test_agent_contract_rejects_low_confidence():
    from pydantic import ValidationError
    from contract import AgentInferenceResponse
    with pytest.raises(ValidationError, match="too low"):
        AgentInferenceResponse(
            case_id="test",
            suggested_state="TRIAGE_COMPLETED",
            confidence_score=0.3,   # Below 0.5 threshold
            risk_level="LOW",
            metadata={},
            trace_id="t1",
            inference_trace="test",
        )


def test_agent_contract_accepts_valid_response():
    from contract import AgentInferenceResponse
    r = AgentInferenceResponse(
        case_id="case-123",
        suggested_state="TRIAGE_COMPLETED",
        confidence_score=0.95,
        risk_level="HIGH",
        metadata={"source": "test"},
        trace_id="trace-abc",
        inference_trace="test_path",
    )
    assert r.suggested_state == "TRIAGE_COMPLETED"
    assert r.schema_version == "1.0.0"
    assert r.agent_version == "1.0.0"


# ── 4. JSON parsing robustness ─────────────────────────────────

def test_safe_json_parse_clean_json():
    from agents.base import BaseAgent
    result = BaseAgent._safe_json_parse('{"medications": [{"drug_name": "Metformin"}]}')
    assert result is not None
    assert "medications" in result


def test_safe_json_parse_markdown_fences():
    from agents.base import BaseAgent
    result = BaseAgent._safe_json_parse('```json\n{"value": 42}\n```')
    assert result is not None
    assert result["value"] == 42


def test_safe_json_parse_embedded_json():
    from agents.base import BaseAgent
    result = BaseAgent._safe_json_parse('Here is the result: {"status": "ok"} — done.')
    assert result is not None
    assert result["status"] == "ok"


def test_safe_json_parse_invalid_returns_none():
    from agents.base import BaseAgent
    result = BaseAgent._safe_json_parse("This is definitely not JSON at all.")
    assert result is None


# ── 5. Drug interaction rules ─────────────────────────────────

def test_warfarin_aspirin_interaction_flagged():
    from agents.prescription_intel import INTERACTION_RULES
    pair = frozenset(["warfarin", "aspirin"])
    assert pair in INTERACTION_RULES
    assert "SEVERE" in INTERACTION_RULES[pair]


def test_metformin_alcohol_interaction_flagged():
    from agents.prescription_intel import INTERACTION_RULES
    pair = frozenset(["metformin", "alcohol"])
    assert pair in INTERACTION_RULES


# ── 6. Emergency agent always returns 108 ─────────────────────

@pytest.mark.asyncio
async def test_emergency_always_returns_108_on_parse_failure():
    from agents.emergency_response import EmergencyResponseAgent
    agent = EmergencyResponseAgent()
    original = agent._call_claude
    agent._call_claude = lambda **kw: "not valid json at all"
    result = await agent.run(symptoms="chest pain and shortness of breath")
    agent._call_claude = original
    assert result.get("ambulance_number") == "108"
    assert result.get("call_ambulance") is True


# ── 7. Chat companion emergency detection ─────────────────────

@pytest.mark.asyncio
async def test_chat_companion_detects_emergency_keywords():
    from agents.chat_companion import ChatCompanionAgent
    agent = ChatCompanionAgent()
    original = agent._call_claude
    agent._call_claude = lambda **kw: "Please call 108 immediately."
    result = await agent.run(message="I have severe chest pain")
    agent._call_claude = original
    assert result["emergency_flag"] is True
    assert result["suggested_action"] == "call_emergency"


@pytest.mark.asyncio
async def test_chat_companion_no_false_emergency():
    from agents.chat_companion import ChatCompanionAgent
    agent = ChatCompanionAgent()
    original = agent._call_claude
    agent._call_claude = lambda **kw: "Drink plenty of water and rest."
    result = await agent.run(message="I have a mild headache")
    agent._call_claude = original
    assert result["emergency_flag"] is False


# ── 8. API endpoint tests ─────────────────────────────────────

@pytest.mark.asyncio
async def test_health_endpoint_returns_200():
    os.environ["ANTHROPIC_API_KEY"] = "test-key-not-real"
    from httpx import AsyncClient, ASGITransport
    from main import app
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        resp = await client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["agents"] == 16
    assert data["status"] == "healthy"
    assert data["schema_version"] == "1.0.0"
    assert data["role"] == "stateless-inference-counsel"


@pytest.mark.asyncio
async def test_emergency_triage_requires_no_auth():
    """Emergency endpoint must never require auth — life-critical."""
    os.environ["ANTHROPIC_API_KEY"] = "test-key-not-real"
    from httpx import AsyncClient, ASGITransport
    from main import app
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        resp = await client.post(
            "/api/v1/emergency/triage",
            json={"symptoms": "chest pain", "location": "Hyderabad"},
        )
    # Should not return 401 — unauthenticated emergency calls must go through
    assert resp.status_code != 401
