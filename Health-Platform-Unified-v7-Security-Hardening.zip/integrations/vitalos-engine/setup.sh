#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
#  VitalOS v3 — Hardened Production Bootstrap
#  Fixes: allexport .env, Redis wait, Kafka proper readiness,
#         virtualenv, trap ERR, health check, Redis mode seed
# ═══════════════════════════════════════════════════════════════
set -euo pipefail

# ── 0. Fail trap — clean up on any error ─────────────────────
trap 'echo ""; echo "❌ Setup failed at line $LINENO. Cleaning up..."; docker-compose -f infra/docker-compose.yml down 2>/dev/null || true; exit 1' ERR

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   VitalOS v3 — Clinical OS Bootstrap     ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── 1. Check required tools ───────────────────────────────────
echo "🔍 Checking required tools..."
for tool in docker docker-compose node npm python3 psql; do
    if ! command -v "$tool" &>/dev/null; then
        echo "❌ Required tool not found: $tool"
        exit 1
    fi
done
echo "✅ All required tools present"

# ── 2. Load .env (allexport — safe for special chars) ─────────
if [ ! -f .env ]; then
    echo "📋 Creating .env from .env.example..."
    cp .env.example .env
    echo "⚠️  Please edit .env with your real credentials before production use"
fi

set -o allexport
# shellcheck source=/dev/null
source .env
set +o allexport
echo "✅ Environment loaded"

# ── 3. Validate critical env vars ─────────────────────────────
echo "🔒 Validating environment variables..."
REQUIRED_VARS=(DATABASE_URL REDIS_URL KAFKA_BROKERS JWT_SECRET ANTHROPIC_API_KEY)
MISSING=()
for var in "${REQUIRED_VARS[@]}"; do
    if [ -z "${!var:-}" ]; then
        MISSING+=("$var")
    fi
done
if [ ${#MISSING[@]} -gt 0 ]; then
    echo "❌ Missing required environment variables: ${MISSING[*]}"
    exit 1
fi
echo "✅ All required variables set"

# ── 4. Start infrastructure ───────────────────────────────────
echo ""
echo "🐳 Starting infrastructure (Postgres, Redis, Kafka, Zookeeper)..."
docker-compose -f infra/docker-compose.yml up -d postgres redis zookeeper kafka

# ── 5. Wait for Postgres ──────────────────────────────────────
echo "⏳ Waiting for Postgres..."
until docker exec vitalos-postgres pg_isready -U vitalos -d vitalos > /dev/null 2>&1; do
    printf "."
    sleep 2
done
echo ""
echo "✅ Postgres ready"

# ── 6. Wait for Redis (proper readiness — not sleep) ─────────
echo "⏳ Waiting for Redis..."
REDIS_READY=false
for i in $(seq 1 30); do
    if docker exec vitalos-redis redis-cli ping 2>/dev/null | grep -q "PONG"; then
        REDIS_READY=true
        break
    fi
    printf "."
    sleep 2
done
echo ""
if [ "$REDIS_READY" = false ]; then
    echo "❌ Redis did not become ready within 60 seconds"
    exit 1
fi
echo "✅ Redis ready"

# ── 7. Wait for Kafka (broker-level readiness — not sleep) ────
echo "⏳ Waiting for Kafka broker..."
KAFKA_READY=false
for i in $(seq 1 60); do
    if docker exec vitalos-kafka kafka-broker-api-versions.sh \
        --bootstrap-server localhost:9092 > /dev/null 2>&1; then
        KAFKA_READY=true
        break
    fi
    printf "."
    sleep 3
done
echo ""
if [ "$KAFKA_READY" = false ]; then
    echo "❌ Kafka did not become ready within 180 seconds"
    exit 1
fi
echo "✅ Kafka ready"

# ── 8. Create Kafka topics ────────────────────────────────────
echo "📡 Creating Kafka topics..."

# NOTE: replication-factor=1 for local/dev ONLY
# For production: set KAFKA_REPLICATION_FACTOR=3 in .env
RF="${KAFKA_REPLICATION_FACTOR:-1}"

create_topic() {
    local topic="$1" partitions="${2:-3}"
    docker exec vitalos-kafka kafka-topics.sh \
        --create --if-not-exists \
        --topic "$topic" \
        --partitions "$partitions" \
        --replication-factor "$RF" \
        --bootstrap-server localhost:9092
    echo "  ✓ $topic (partitions=$partitions, rf=$RF)"
}

create_topic "vitalos.case.events"         3
create_topic "vitalos.case.state_changed"  3
create_topic "vitalos.governance.trigger"  1
create_topic "vitalos.audit.tamper_alert"  1
create_topic "vitalos.case.escalated"      2
create_topic "vitalos.case.dlq"            1
create_topic "vitalos.triage.requests"     3
create_topic "vitalos.emergency.dispatch"  1
create_topic "vitalos.clinical.alert"      2

echo "✅ All 9 Kafka topics created"

# ── 9. Verify topics created ──────────────────────────────────
echo "🔍 Verifying Kafka topics..."
TOPIC_COUNT=$(docker exec vitalos-kafka kafka-topics.sh \
    --list --bootstrap-server localhost:9092 2>/dev/null | grep "vitalos\." | wc -l)
if [ "$TOPIC_COUNT" -lt 9 ]; then
    echo "⚠️ Warning: Expected 9 topics, found $TOPIC_COUNT"
else
    echo "✅ All $TOPIC_COUNT topics verified"
fi

# ── 10. Initialize database ───────────────────────────────────
echo ""
echo "🗄️ Initialising database schema..."
docker exec -i vitalos-postgres psql -U vitalos -d vitalos < infra/init.sql
echo "✅ Database schema ready (idempotent — safe to re-run)"

# ── 11. Run migrations ────────────────────────────────────────
echo "📦 Running migrations..."
for migration in infra/migrations/*.sql; do
    echo "  Applying: $(basename $migration)..."
    docker exec -i vitalos-postgres psql -U vitalos -d vitalos < "$migration"
done
echo "✅ Migrations complete (v3 + v4 provider-grade tables)"

# ── 12. Seed Redis global mode ────────────────────────────────
echo "🔧 Seeding Redis system mode..."
docker exec vitalos-redis redis-cli set "global:system_mode" "NORMAL" > /dev/null
docker exec vitalos-redis redis-cli set "global:ema_load"   "0.0"    > /dev/null
echo "✅ Redis seeded: system_mode=NORMAL"

# ── 13. Install TypeScript dependencies ───────────────────────
echo ""
echo "📦 Installing TypeScript dependencies..."
npm ci --prefer-offline 2>/dev/null || npm install
echo "✅ Node dependencies installed"

# ── 14. Build TypeScript ──────────────────────────────────────
echo "🔨 Building TypeScript (The Judge)..."
npm run build
echo "✅ TypeScript build complete"

# ── 15. Setup Python virtualenv (isolated — no global pollution) ──
echo ""
echo "🐍 Setting up Python virtualenv (The Counsel)..."
cd services/ai-agents
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo "  ✓ Virtual environment created"
fi
# shellcheck source=/dev/null
source venv/bin/activate
pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet
echo "✅ Python dependencies installed (isolated venv)"
deactivate
cd ../..

# ── 16. Start TypeScript services ─────────────────────────────
echo ""
echo "🚀 Starting TypeScript services (The Judge)..."
nohup npm run start:gateway      > logs/gateway.log     2>&1 &
nohup npm run start:orchestrator > logs/orchestrator.log 2>&1 &
nohup npm run start:monitoring   > logs/monitoring.log   2>&1 &
nohup npm run start:governance   > logs/governance.log   2>&1 &
nohup npm run start:emergency    > logs/emergency.log    2>&1 &
nohup npm run start:triage       > logs/triage.log       2>&1 &
echo "✅ TypeScript services starting..."

sleep 3

# ── 17. Start Python AI agents ────────────────────────────────
echo "🤖 Starting Python AI Agents (The Counsel)..."
cd services/ai-agents
source venv/bin/activate
nohup uvicorn main:app --host 0.0.0.0 --port 8000 --workers 2 > ../../logs/ai-agents.log 2>&1 &
deactivate
cd ../..
echo "✅ AI Agents starting..."

sleep 5

# ── 18. Health checks ─────────────────────────────────────────
echo ""
echo "🏥 Running health checks..."

# TypeScript gateway
if curl -sf http://localhost:3000/health > /dev/null 2>&1; then
    echo "  ✅ API Gateway (port 3000) — healthy"
else
    echo "  ⚠️  API Gateway not responding yet (may need more time)"
fi

# Python agents
if curl -sf http://localhost:8000/health > /dev/null 2>&1; then
    echo "  ✅ AI Agents (port 8000) — healthy"
else
    echo "  ⚠️  AI Agents not responding yet (may need more time)"
fi

# ── 19. Print access info ─────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║           VitalOS v3 — Running                          ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║  API Gateway   → http://localhost:3000                  ║"
echo "║  AI Agents     → http://localhost:8000                  ║"
echo "║  API Docs      → http://localhost:8000/docs             ║"
echo "║  Health        → http://localhost:3000/health           ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║  Auth Flows:                                            ║"
echo "║    Patient  → POST /auth/login/otp/send                 ║"
echo "║    Staff    → POST /auth/login/password                 ║"
echo "║  Admin seed → +919999900000 / Admin@123                 ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║  Kafka     → localhost:9092 (9 topics)                  ║"
echo "║  Postgres  → localhost:5432 (db: vitalos)               ║"
echo "║  Redis     → localhost:6379                             ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║  Logs → ./logs/*.log                                    ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "🏥 VitalOS v3 Clinical OS is LIVE."
echo "   The Judge is TypeScript. The Counsel is Python."
echo "   Clinical Truth is deterministic."
echo ""
