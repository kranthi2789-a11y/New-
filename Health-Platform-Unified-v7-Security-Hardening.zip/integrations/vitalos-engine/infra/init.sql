-- ============================================================
-- VitalOS Full Database Schema v1.0.0
-- Control Plane (TypeScript Clinical Engine)
-- Run: psql -U postgres -d vitalos -f init.sql
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── CONTROL PLANE: Clinical State Machine ─────────────────────

CREATE TABLE IF NOT EXISTS valid_transitions (
    from_state   TEXT NOT NULL,
    to_state     TEXT NOT NULL,
    PRIMARY KEY (from_state, to_state)
);

INSERT INTO valid_transitions (from_state, to_state) VALUES
    ('CREATED',               'TRIAGE_PENDING'),
    ('CREATED',               'ESCALATED'),
    ('TRIAGE_PENDING',        'TRIAGE_COMPLETED'),
    ('TRIAGE_PENDING',        'ESCALATED'),
    ('TRIAGE_COMPLETED',      'DOCTOR_REVIEW_PENDING'),
    ('TRIAGE_COMPLETED',      'ROUTING_PENDING'),
    ('DOCTOR_REVIEW_PENDING', 'ROUTING_PENDING'),
    ('DOCTOR_REVIEW_PENDING', 'ESCALATED'),
    ('ROUTING_PENDING',       'CLOSED'),
    ('ROUTING_PENDING',       'ESCALATED')
ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS case_state_machine (
    case_id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    current_state        TEXT NOT NULL DEFAULT 'CREATED',
    last_sequence_number BIGINT DEFAULT 0,
    last_audit_id        UUID,
    overall_deadline     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW() + INTERVAL '24 hours',
    risk_level           TEXT NOT NULL DEFAULT 'LOW'
                         CHECK (risk_level IN ('LOW', 'MEDIUM', 'HIGH', 'EMERGENCY')),
    priority_score       FLOAT DEFAULT 0.0,
    is_locked            BOOLEAN DEFAULT FALSE,
    version              INT DEFAULT 1,
    schema_version       TEXT DEFAULT '1.0.0',
    created_at           TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at           TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_case_state ON case_state_machine (current_state);
CREATE INDEX IF NOT EXISTS ix_case_risk   ON case_state_machine (risk_level);
CREATE INDEX IF NOT EXISTS ix_case_locked ON case_state_machine (is_locked) WHERE is_locked = TRUE;

-- ── CONTROL PLANE: Cryptographic Audit Ledger ─────────────────

CREATE TABLE IF NOT EXISTS global_audit_trail (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id          UUID NOT NULL REFERENCES case_state_machine(case_id) ON DELETE RESTRICT,
    record_hash      TEXT NOT NULL,
    previous_hash    TEXT NOT NULL DEFAULT 'VITALOS_ROOT_GENESIS_V1',
    payload          JSONB NOT NULL,
    idempotency_key  TEXT UNIQUE,
    sequence_id      BIGINT GENERATED ALWAYS AS IDENTITY,
    schema_version   TEXT DEFAULT '1.0.0',
    created_at       TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_audit_case_id    ON global_audit_trail (case_id);
CREATE INDEX IF NOT EXISTS ix_audit_sequence   ON global_audit_trail (sequence_id);
CREATE INDEX IF NOT EXISTS ix_audit_idemp      ON global_audit_trail (idempotency_key);

-- ── CONTROL PLANE: Sequence Gap Buffer ────────────────────────

CREATE TABLE IF NOT EXISTS event_buffer (
    case_id         UUID NOT NULL REFERENCES case_state_machine(case_id) ON DELETE CASCADE,
    sequence_number BIGINT NOT NULL,
    payload         JSONB NOT NULL,
    schema_version  TEXT DEFAULT '1.0.0',
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    PRIMARY KEY (case_id, sequence_number)
);

CREATE INDEX IF NOT EXISTS ix_buffer_created ON event_buffer (created_at);

-- ── CONTROL PLANE: Producer Liveness (ACK tracking) ──────────

CREATE TABLE IF NOT EXISTS producer_liveness (
    producer_id           TEXT PRIMARY KEY,
    last_emitted_sequence BIGINT DEFAULT 0,
    last_acked_sequence   BIGINT DEFAULT 0,
    unacked_count         INT DEFAULT 0,
    last_heartbeat        TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ── CONTROL PLANE: Governance & Safe Mode ─────────────────────

CREATE TABLE IF NOT EXISTS global_system_state (
    id           INT PRIMARY KEY DEFAULT 1,
    mode         TEXT NOT NULL DEFAULT 'NORMAL'
                 CHECK (mode IN ('NORMAL', 'DEGRADED', 'SAFE_MODE')),
    activated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    changed_by   TEXT DEFAULT 'system',
    CONSTRAINT single_row CHECK (id = 1)
);

INSERT INTO global_system_state (id, mode) VALUES (1, 'NORMAL')
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS governor_registry (
    trigger_type      TEXT PRIMARY KEY,
    last_activated_at TIMESTAMP WITH TIME ZONE,
    cooldown_minutes  INT DEFAULT 15,
    is_suppressed     BOOLEAN DEFAULT FALSE
);

-- ── DATA PLANE: Patient Records (Python AI Agents own these) ──

CREATE TABLE IF NOT EXISTS patients (
    id             SERIAL PRIMARY KEY,
    name           VARCHAR(100) NOT NULL,
    mobile         VARCHAR(15) UNIQUE,
    age            INT DEFAULT 0,
    gender         VARCHAR(10) DEFAULT 'unknown',
    blood_group    VARCHAR(5) DEFAULT '',
    abha_id        VARCHAR(50) DEFAULT '',
    conditions     JSONB DEFAULT '[]',
    allergies      JSONB DEFAULT '[]',
    medications    JSONB DEFAULT '[]',
    schema_version VARCHAR(10) DEFAULT '1.0.0',
    created_at     TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at     TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_patients_mobile  ON patients (mobile);
CREATE INDEX IF NOT EXISTS ix_patients_abha    ON patients (abha_id);

CREATE TABLE IF NOT EXISTS prescriptions (
    id                   SERIAL PRIMARY KEY,
    patient_mobile       VARCHAR(15),
    doctor_name          VARCHAR(100) DEFAULT '',
    clinic_name          VARCHAR(100) DEFAULT '',
    raw_text             TEXT DEFAULT '',
    medications          JSONB DEFAULT '[]',
    interaction_warnings JSONB DEFAULT '[]',
    diagnosis            VARCHAR(200) DEFAULT '',
    follow_up_days       INT DEFAULT 0,
    trace_id             VARCHAR(100) DEFAULT '',
    schema_version       VARCHAR(10) DEFAULT '1.0.0',
    created_at           TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reminders (
    id             SERIAL PRIMARY KEY,
    patient_mobile VARCHAR(15),
    drug_name      VARCHAR(100) NOT NULL,
    dosage         VARCHAR(50) DEFAULT '',
    frequency      VARCHAR(50) DEFAULT '',
    schedule_times JSONB DEFAULT '[]',
    active         BOOLEAN DEFAULT TRUE,
    streak_days    INT DEFAULT 0,
    critical       BOOLEAN DEFAULT FALSE,
    created_at     TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS lab_reports (
    id                SERIAL PRIMARY KEY,
    patient_mobile    VARCHAR(15),
    report_type       VARCHAR(100) DEFAULT '',
    raw_text          TEXT DEFAULT '',
    extracted_values  JSONB DEFAULT '{}',
    flags             JSONB DEFAULT '[]',
    follow_up_urgency VARCHAR(20) DEFAULT 'routine',
    ai_explanation    TEXT DEFAULT '',
    trace_id          VARCHAR(100) DEFAULT '',
    schema_version    VARCHAR(10) DEFAULT '1.0.0',
    created_at        TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS agent_logs (
    id             SERIAL PRIMARY KEY,
    agent_name     VARCHAR(50) NOT NULL,
    session_id     VARCHAR(100),
    trace_id       VARCHAR(100) DEFAULT '',
    input_hash     VARCHAR(64) DEFAULT '',
    output_text    TEXT DEFAULT '',
    tokens_used    INT DEFAULT 0,
    latency_ms     FLOAT DEFAULT 0.0,
    success        BOOLEAN DEFAULT TRUE,
    agent_version  VARCHAR(10) DEFAULT '1.0.0',
    schema_version VARCHAR(10) DEFAULT '1.0.0',
    created_at     TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_agent_logs_trace   ON agent_logs (trace_id);
CREATE INDEX IF NOT EXISTS ix_agent_logs_name    ON agent_logs (agent_name);
CREATE INDEX IF NOT EXISTS ix_agent_logs_created ON agent_logs (created_at);

-- ── Helpful views ─────────────────────────────────────────────

CREATE OR REPLACE VIEW v_active_cases AS
SELECT
    csm.case_id,
    csm.current_state,
    csm.risk_level,
    csm.priority_score,
    csm.version,
    csm.updated_at,
    (SELECT COUNT(*) FROM event_buffer eb WHERE eb.case_id = csm.case_id) AS buffered_events
FROM case_state_machine csm
WHERE csm.current_state NOT IN ('CLOSED', 'ESCALATED')
  AND csm.is_locked = FALSE
ORDER BY csm.priority_score DESC, csm.updated_at ASC;

CREATE OR REPLACE VIEW v_audit_integrity AS
SELECT
    aud.case_id,
    COUNT(aud.id) AS audit_records,
    csm.current_state,
    csm.last_audit_id,
    MAX(aud.sequence_id) AS last_seq,
    csm.version
FROM global_audit_trail aud
JOIN case_state_machine csm ON aud.case_id = csm.case_id
GROUP BY aud.case_id, csm.current_state, csm.last_audit_id, csm.version;

-- ============================================================
-- Schema Version: 1.0.0
-- ============================================================

-- ============================================================
-- VitalOS v3 — Extended Schema (Auth + Roles + Features)
-- ============================================================

-- ── USERS (all roles) ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    mobile          VARCHAR(15) UNIQUE NOT NULL,
    email           VARCHAR(120) UNIQUE,
    name            VARCHAR(100) NOT NULL,
    role            TEXT NOT NULL CHECK (role IN ('patient','doctor','nurse','emergency_responder','admin')),
    password_hash   TEXT,
    abha_id         VARCHAR(50) UNIQUE,
    hospital_id     UUID,
    is_active       BOOLEAN DEFAULT TRUE,
    is_verified     BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_users_mobile ON users(mobile);
CREATE INDEX IF NOT EXISTS ix_users_role   ON users(role);

-- Seed admin user (password: Admin@123 — bcrypt hash)
INSERT INTO users (mobile,email,name,role,password_hash,is_active,is_verified)
VALUES ('+919999900000','admin@vitalos.in','VitalOS Admin','admin',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGX1mDfzBpIJvJP5L5pHXp4jBe2',
  TRUE,TRUE)
ON CONFLICT DO NOTHING;

-- ── OTP SESSIONS ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS otp_sessions (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    mobile      VARCHAR(15) NOT NULL,
    otp_hash    TEXT NOT NULL,
    purpose     TEXT NOT NULL DEFAULT 'login',
    expires_at  TIMESTAMP WITH TIME ZONE NOT NULL,
    used        BOOLEAN DEFAULT FALSE,
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_otp_mobile ON otp_sessions(mobile);

-- ── REFRESH TOKENS ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash  TEXT NOT NULL UNIQUE,
    expires_at  TIMESTAMP WITH TIME ZONE NOT NULL,
    revoked     BOOLEAN DEFAULT FALSE,
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ── FAMILY CONTACTS (SOS) ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS family_contacts (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name            VARCHAR(100) NOT NULL,
    mobile          VARCHAR(15) NOT NULL,
    relation        VARCHAR(50) NOT NULL,
    is_primary_sos  BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_family_patient ON family_contacts(patient_id);

-- ── APPOINTMENTS ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS appointments (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES users(id),
    doctor_id       UUID REFERENCES users(id),
    hospital_name   VARCHAR(200),
    specialty       VARCHAR(100),
    scheduled_at    TIMESTAMP WITH TIME ZONE NOT NULL,
    status          TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled','completed','cancelled','no_show')),
    notes           TEXT,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_appt_patient ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS ix_appt_doctor  ON appointments(doctor_id);
CREATE INDEX IF NOT EXISTS ix_appt_date    ON appointments(scheduled_at);

-- ── VITALS (nurse-entered) ────────────────────────────────────
CREATE TABLE IF NOT EXISTS vitals (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES users(id),
    recorded_by     UUID NOT NULL REFERENCES users(id),
    systolic_bp     INT,
    diastolic_bp    INT,
    heart_rate      INT,
    temperature     NUMERIC(4,1),
    spo2            INT,
    weight_kg       NUMERIC(5,1),
    blood_glucose   INT,
    notes           TEXT,
    recorded_at     TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_vitals_patient ON vitals(patient_id);

-- ── MEDICATION LOGS (adherence) ───────────────────────────────
CREATE TABLE IF NOT EXISTS medication_logs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reminder_id     INT REFERENCES reminders(id),
    patient_id      VARCHAR(15),
    drug_name       VARCHAR(100),
    scheduled_time  TIME NOT NULL,
    taken_at        TIMESTAMP WITH TIME ZONE,
    status          TEXT DEFAULT 'pending' CHECK (status IN ('pending','taken','skipped','late')),
    logged_date     DATE DEFAULT CURRENT_DATE
);
CREATE INDEX IF NOT EXISTS ix_medlog_patient ON medication_logs(patient_id);

-- ── SAVED INSURANCE POLICIES ──────────────────────────────────
CREATE TABLE IF NOT EXISTS insurance_policies (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES users(id),
    policy_name     VARCHAR(200) NOT NULL,
    insurer         VARCHAR(100),
    policy_number   VARCHAR(100),
    sum_insured     NUMERIC(12,2),
    premium_annual  NUMERIC(10,2),
    expiry_date     DATE,
    policy_text     TEXT,
    ai_summary      JSONB,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ── DOCUMENTS (Rx, Lab, Bills, Health Card) ───────────────────
CREATE TABLE IF NOT EXISTS documents (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES users(id),
    doc_type        TEXT NOT NULL CHECK (doc_type IN ('prescription','lab_report','bill','health_card','insurance','other')),
    file_name       VARCHAR(255),
    file_url        TEXT,
    file_base64     TEXT,
    ai_result       JSONB,
    uploaded_at     TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_docs_patient ON documents(patient_id, doc_type);

-- ── NOTIFICATIONS LOG ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications_log (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID REFERENCES users(id),
    channel         TEXT NOT NULL CHECK (channel IN ('whatsapp','sms','push')),
    to_number       VARCHAR(20) NOT NULL,
    message_type    TEXT NOT NULL,
    message_body    TEXT,
    status          TEXT DEFAULT 'sent' CHECK (status IN ('sent','delivered','failed')),
    twilio_sid      VARCHAR(100),
    sent_at         TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ── MAR (Medication Administration Record) ───────────────────
CREATE TABLE IF NOT EXISTS mar_records (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES users(id),
    nurse_id        UUID NOT NULL REFERENCES users(id),
    drug_name       VARCHAR(100) NOT NULL,
    dosage          VARCHAR(50),
    route           VARCHAR(30),
    administered_at TIMESTAMP WITH TIME ZONE NOT NULL,
    notes           TEXT
);

-- ── HOSPITAL CONFIG ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS hospital_config (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(200) NOT NULL DEFAULT 'VitalOS Hospital',
    address         TEXT,
    phone           VARCHAR(20),
    cghs_empanelled BOOLEAN DEFAULT FALSE,
    pmjay_empanelled BOOLEAN DEFAULT FALSE,
    settings        JSONB DEFAULT '{}',
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
INSERT INTO hospital_config (name) VALUES ('VitalOS Demo Hospital') ON CONFLICT DO NOTHING;

-- ── DOCTOR-PATIENT ASSIGNMENTS ────────────────────────────────
CREATE TABLE IF NOT EXISTS doctor_patient (
    doctor_id   UUID NOT NULL REFERENCES users(id),
    patient_id  UUID NOT NULL REFERENCES users(id),
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active   BOOLEAN DEFAULT TRUE,
    PRIMARY KEY (doctor_id, patient_id)
);

