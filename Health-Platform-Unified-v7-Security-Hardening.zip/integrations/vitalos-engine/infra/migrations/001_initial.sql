-- ============================================================
-- VitalOS Migration 001 — Initial Schema
-- Version: 1.0.0
-- Applied by: setup.sh on first boot
-- Idempotent: YES (all CREATE ... IF NOT EXISTS)
--
-- This file mirrors infra/init.sql exactly.
-- For schema changes, create 002_xxx.sql etc.
-- ============================================================

-- Guard: run only once
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_name = 'schema_migrations'
  ) AND EXISTS (
    SELECT 1 FROM schema_migrations WHERE version = '001'
  ) THEN
    RAISE NOTICE 'Migration 001 already applied — skipping';
    RETURN;
  END IF;
END
$$;

-- Migration tracking table
CREATE TABLE IF NOT EXISTS schema_migrations (
    version     TEXT PRIMARY KEY,
    applied_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    description TEXT
);

-- Record this migration
INSERT INTO schema_migrations (version, description)
VALUES ('001', 'Initial VitalOS schema — control + data plane')
ON CONFLICT (version) DO NOTHING;

-- ── All tables created via init.sql on first boot ─────────────
-- init.sql is applied by setup.sh before this file.
-- This migration records the baseline for future diffs.
--
-- Future migrations (002, 003...) should:
--   ALTER TABLE ... ADD COLUMN IF NOT EXISTS ...
--   CREATE INDEX IF NOT EXISTS ...
--   INSERT INTO valid_transitions ... ON CONFLICT DO NOTHING
-- ============================================================
