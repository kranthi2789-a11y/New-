-- ============================================================
-- VitalOS Migration 002 — v4 Provider-Grade Extensions
-- New tables for: orders, SLA, legal, consent, billing,
--                 override, analytics, EHR, integrations
-- All CREATE TABLE IF NOT EXISTS — fully idempotent
-- ============================================================

-- Guard
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables WHERE table_name='schema_migrations'
  ) AND EXISTS (
    SELECT 1 FROM schema_migrations WHERE version='002'
  ) THEN
    RAISE NOTICE 'Migration 002 already applied — skipping';
    RETURN;
  END IF;
END
$$;

-- ── ORDERS LOG ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders_log (
    order_id        TEXT PRIMARY KEY,
    patient_id      UUID REFERENCES users(id),
    order_type      TEXT NOT NULL CHECK (order_type IN ('LAB','RADIOLOGY','MEDICATION')),
    status          TEXT NOT NULL DEFAULT 'CREATED',
    priority        TEXT DEFAULT 'routine',
    payload         TEXT,
    result_data     TEXT,
    critical        BOOLEAN DEFAULT FALSE,
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_orders_patient ON orders_log(patient_id);
CREATE INDEX IF NOT EXISTS ix_orders_status  ON orders_log(status);

-- ── SLA BREACHES ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sla_breaches (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id             TEXT NOT NULL,
    state               TEXT NOT NULL,
    risk_level          TEXT NOT NULL,
    seconds_in_state    INT,
    threshold_seconds   INT,
    breach_seconds      INT,
    attending_doctor_id UUID,
    detected_at         TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE (case_id, state)
);
CREATE INDEX IF NOT EXISTS ix_sla_case   ON sla_breaches(case_id);
CREATE INDEX IF NOT EXISTS ix_sla_detect ON sla_breaches(detected_at);

-- ── RECORD SIGNATURES (legal) ─────────────────────────────────
CREATE TABLE IF NOT EXISTS record_signatures (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    record_id    TEXT NOT NULL,
    record_type  TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    signature    TEXT NOT NULL,
    signed_by    UUID REFERENCES users(id),
    signer_name  TEXT,
    signed_at    TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_locked    BOOLEAN DEFAULT TRUE,
    UNIQUE (record_id, record_type)
);
CREATE INDEX IF NOT EXISTS ix_sig_record ON record_signatures(record_id);

-- ── PATIENT CONSENTS (DPDP) ───────────────────────────────────
CREATE TABLE IF NOT EXISTS patient_consents (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id  UUID NOT NULL REFERENCES users(id),
    purpose     TEXT NOT NULL,
    granted     BOOLEAN DEFAULT TRUE,
    valid_until TIMESTAMP WITH TIME ZONE,
    notes       TEXT,
    revoked_at  TIMESTAMP WITH TIME ZONE,
    revoke_reason TEXT,
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE (patient_id, purpose)
);
CREATE INDEX IF NOT EXISTS ix_consent_patient  ON patient_consents(patient_id);
CREATE INDEX IF NOT EXISTS ix_consent_purpose  ON patient_consents(purpose);

-- ── BILLING RECORDS ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS billing_records (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bill_id             TEXT UNIQUE NOT NULL,
    patient_id          UUID REFERENCES users(id),
    total_charged       NUMERIC(12,2),
    total_cghs_approved NUMERIC(12,2),
    insured_amount      NUMERIC(12,2),
    patient_liability   NUMERIC(12,2),
    insurance_type      TEXT DEFAULT 'NONE',
    policy_number       TEXT,
    cghs_flags          TEXT,
    line_items_json     TEXT,
    created_by          UUID REFERENCES users(id),
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_billing_patient ON billing_records(patient_id);

-- ── OVERRIDE LOG ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS override_log (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id             TEXT NOT NULL,
    overriding_user_id  UUID REFERENCES users(id),
    overriding_role     TEXT NOT NULL,
    overriding_name     TEXT NOT NULL,
    from_state          TEXT NOT NULL,
    to_state            TEXT NOT NULL,
    justification       TEXT NOT NULL,
    clinical_basis      TEXT,
    risk_acknowledged   BOOLEAN DEFAULT FALSE,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_override_case ON override_log(case_id);

-- ── CLINICAL VALIDATION LOG ───────────────────────────────────
CREATE TABLE IF NOT EXISTS clinical_validation_log (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID,
    case_id         TEXT,
    validation_type TEXT NOT NULL,   -- 'CDSS' | 'PROTOCOL' | 'SPECIALTY'
    result          TEXT NOT NULL,   -- 'PASS' | 'WARN' | 'BLOCK'
    details         TEXT,
    validated_at    TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_val_patient ON clinical_validation_log(patient_id);
CREATE INDEX IF NOT EXISTS ix_val_case    ON clinical_validation_log(case_id);

-- ── EXTEND case_state_machine with v4 fields ──────────────────
-- attending_doctor_id: responsible clinician for every case
-- hospital_id: multi-tenant support
-- specialty: clinical specialty routing
ALTER TABLE case_state_machine
    ADD COLUMN IF NOT EXISTS attending_doctor_id UUID,
    ADD COLUMN IF NOT EXISTS hospital_id         UUID,
    ADD COLUMN IF NOT EXISTS specialty           TEXT,
    ADD COLUMN IF NOT EXISTS protocol_triggered  TEXT,
    ADD COLUMN IF NOT EXISTS override_count      INT DEFAULT 0;

-- ── EXTEND global_audit_trail with v4 fields ──────────────────
ALTER TABLE global_audit_trail
    ADD COLUMN IF NOT EXISTS attending_doctor_id UUID,
    ADD COLUMN IF NOT EXISTS hospital_id         UUID,
    ADD COLUMN IF NOT EXISTS specialty           TEXT,
    ADD COLUMN IF NOT EXISTS rule_applied        TEXT,
    ADD COLUMN IF NOT EXISTS workflow_stage      TEXT,
    ADD COLUMN IF NOT EXISTS override_flag       BOOLEAN DEFAULT FALSE;

-- Record migration
INSERT INTO schema_migrations (version, description)
VALUES ('002', 'VitalOS v4 — Provider-grade extensions: orders, SLA, legal, consent, billing, override, EHR')
ON CONFLICT (version) DO NOTHING;
