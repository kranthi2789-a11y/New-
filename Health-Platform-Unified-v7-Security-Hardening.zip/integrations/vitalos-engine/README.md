# VitalOS — India's AI-Powered Clinical Operating System

> **"The Judge is TypeScript. The Counsel is Python. Clinical Truth is deterministic."**

VitalOS is a production-grade, layered execution platform that separates **deterministic clinical governance** (TypeScript) from **probabilistic AI inference** (Python). Built for India's healthcare context.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    API GATEWAY (Port 3000)                   │
│         JWT Auth · RBAC · Safe Mode · Rate Limiting         │
│                  EMA Backpressure · Trace ID                 │
└──────────────────────────┬──────────────────────────────────┘
                           │ Kafka: vitalos.case.events
                           ▼
┌─────────────────────────────────────────────────────────────┐
│               ORCHESTRATOR — The Judge (TS)                  │
│   Lock → Idempotency → Seq Gap → SHA-256 Chain → Transition  │
│   Retry with jitter · Recursive buffer replay               │
└────────────────────────┬────────────────────────────────────┘
                         │
          ┌──────────────┴──────────────┐
          │                             │
          ▼                             ▼
┌─────────────────┐          ┌─────────────────────┐
│  GAP ESCALATION │          │  ANOMALY DETECTOR    │
│  EMERGENCY: 30s │          │  EMA → Kafka trigger │
│  HIGH: 2min     │          │  (never direct DB)   │
│  LOW: 5min      │          └─────────────────────┘
└─────────────────┘
                           │ HTTP proxy
                           ▼
┌─────────────────────────────────────────────────────────────┐
│              AI AGENTS SERVICE — The Counsel (Python)        │
│                  Port 8000 · Stateless Inference             │
│   16 Agents · Claude claude-sonnet-4-20250514 · RAG (ChromaDB)│
└─────────────────────────────────────────────────────────────┘
```

---

## Quick Start

```bash
# 1. Clone and configure
cp .env.example .env
# Edit .env: set ANTHROPIC_API_KEY and JWT_SECRET

# 2. One-click bootstrap
chmod +x setup.sh && ./setup.sh

# 3. Start TypeScript Clinical Engine
npm run start:all

# 4. Start Python AI Agents (separate terminal)
cd services/ai-agents
uvicorn main:app --host 0.0.0.0 --port 8000
```

---

## Versions

| Component | Version |
|---|---|
| Event Schema | 1.0.0 |
| Agent Contract | 1.0.0 |
| Clinical Engine | 1.0.0 |
| AI Agents Service | 1.0.0 |

---

## 16 AI Agents

| Agent | Route | Category | Description |
|---|---|---|---|
| chat | POST /api/v1/chat | patient | Multi-language health companion (EN/HI/TE/TA) |
| prescription | POST /api/v1/prescription/parse | patient | Parse Rx + interaction checks |
| prescription | POST /api/v1/prescription/upload | patient | Image OCR + parse |
| lab | POST /api/v1/lab/interpret | clinical | Lab report with India-specific context |
| reminder | POST /api/v1/reminders/schedule | patient | Daily schedule + WhatsApp templates |
| insurance | POST /api/v1/insurance/analyze | patient | PM-JAY, CGHS, TPA coverage analysis |
| risk | POST /api/v1/health/risk | clinical | 0-100 risk score + 10yr CV risk |
| hospital | POST /api/v1/hospital/find | clinical | Specialty routing + govt options |
| doctor | POST /api/v1/doctor/note | clinical | SOAP notes + ICD-10 coding |
| emergency | POST /api/v1/emergency/triage | emergency | 108 routing (no auth required) |
| family | POST /api/v1/family/health | patient | Multi-member family dashboard |
| cost | POST /api/v1/cost/optimize | finance | Generic savings + Jan Aushadhi |
| pharmacy | POST /api/v1/pharmacy/find | patient | Drug availability + PharmEasy/1mg |
| followup | POST /api/v1/followup/schedule | clinical | Post-visit WhatsApp schedule |
| chronic | POST /api/v1/chronic/monitor | clinical | Diabetes/HTN/Thyroid monitoring |
| preventive | POST /api/v1/preventive/plan | patient | Vaccines + screenings by age |
| bill | POST /api/v1/bill/analyze | finance | CGHS rate mismatch + dispute letter |

---

## Clinical State Machine

```
CREATED → TRIAGE_PENDING → TRIAGE_COMPLETED → DOCTOR_REVIEW_PENDING → ROUTING_PENDING → CLOSED
   ↓             ↓                                      ↓                    ↓
ESCALATED    ESCALATED                             ESCALATED             ESCALATED
```

---

## Security

- **JWT Auth** on all endpoints (except `/emergency/triage` and `/health`)
- **RBAC**: `patient` | `doctor` | `emergency_responder` | `admin`
- **Safe Mode**: Blocks non-clinical traffic when system is under stress
- **Rate limiting**: Standard (60/min) · AI endpoints (20/min) · Emergency (200/min)
- **Audit chain**: Every state transition SHA-256 hashed and cryptographically linked

---

## Operations

```bash
# Run forensic audit verifier
npm run verify

# Inject chaos (gap/loss/disorder/duplicate)
npm run chaos

# Run Python tests
cd services/ai-agents && pytest tests/ -v

# Manually trigger Safe Mode
curl -X POST http://localhost:3000/v1/admin/mode \
  -H "Authorization: Bearer <admin_jwt>" \
  -d '{"mode": "SAFE_MODE"}'
```

---

## Folder Structure

```
vitalos/
├── apps/
│   ├── api-gateway/         # TS: JWT, RBAC, Safe Mode, Rate Limiting
│   ├── orchestrator/        # TS: The Judge — SHA-256 chain, seq gap, retry
│   ├── monitoring/          # TS: Gap escalation (risk-tiered) + EMA anomaly
│   └── governance/          # TS: Mode sync DB↔Redis via Kafka
├── libs/
│   ├── locking/             # Striped Redis lock + Lua token validation
│   ├── events/              # Singleton Kafka idempotent producer
│   ├── audit/               # SHA-256 chain hashing
│   └── common/              # Types (event contract v1.0.0), logger
├── services/
│   └── ai-agents/           # Python FastAPI — 16 stateless inference agents
│       ├── agents/          # All 16 agents + base + orchestrator
│       ├── api/             # REST routes (19 endpoints)
│       ├── core/            # Config, DB ORM, RAG pipeline
│       └── tests/           # Full pytest suite
├── infra/
│   ├── init.sql             # Full schema: control + data plane
│   └── docker-compose.yml   # All services
├── scripts/
│   ├── audit-verifier.ts    # Forensic chain validator
│   └── chaos-simulator.ts   # Gap/loss/disorder injection
└── setup.sh                 # One-click bootstrap
```

---

## Audit Guarantees

Every accepted AI suggestion is permanently recorded in an immutable SHA-256 chain:

```
ROOT_GENESIS → hash(payload_1) → hash(hash_1 + payload_2) → ...
```

Any tampering (direct SQL edit, corrupted payload) is detected by the verifier and the case is auto-locked.

---

*VitalOS — Built for NirvanAI. India first.*
