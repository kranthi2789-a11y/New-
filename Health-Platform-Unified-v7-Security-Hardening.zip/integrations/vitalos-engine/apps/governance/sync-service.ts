/**
 * VitalOS Governance Sync Service
 * - Consumes governance.trigger events from Kafka (not direct anomaly→DB writes)
 * - Syncs DB system mode → Redis every 5s (for API Gateway safe mode guard)
 * - Uses singleton Kafka producer for mode_changed broadcast
 */

import { Pool } from 'pg';
import { Redis } from 'ioredis';
import { kafka, publishEvent } from '../../libs/events/kafka';
import { logger } from '../../libs/common/logger';
import { GovernanceTrigger, SystemMode } from '../../libs/common/types';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const redis = new Redis(process.env.REDIS_URL!);

// ── Consume governance trigger events ─────────────────────────
export async function startGovernanceConsumer(): Promise<void> {
  const consumer = kafka.consumer({ groupId: 'vitalos-governance-group' });
  await consumer.connect();
  await consumer.subscribe({ topic: 'vitalos.governance.trigger', fromBeginning: false });

  await consumer.run({
    autoCommit: true,
    eachMessage: async ({ message }) => {
      let trigger: GovernanceTrigger;
      try {
        trigger = JSON.parse(message.value!.toString());
      } catch {
        logger.error('Governance', 'Malformed governance trigger — skipping');
        return;
      }

      const client = await pool.connect();
      try {
        let newMode: SystemMode = 'NORMAL';
        if (trigger.action === 'ENABLE_SAFE_MODE') newMode = 'SAFE_MODE';
        if (trigger.action === 'ENABLE_DEGRADED')  newMode = 'DEGRADED';

        await client.query(`UPDATE global_system_state SET mode = $1, activated_at = NOW() WHERE id = 1`, [newMode]);
        await redis.set('vitalos:system_mode', newMode);

        await publishEvent('vitalos.system.mode_changed', 'governance', { mode: newMode, reason: trigger.reason, timestamp: Date.now() });
        logger.audit('Governance', 'System mode changed', { new_mode: newMode, reason: trigger.reason });
      } finally {
        client.release();
      }
    },
  });
}

// ── Periodic DB→Redis sync (catch any direct DB changes) ──────
export async function syncGovernanceMode(): Promise<void> {
  try {
    const res = await pool.query('SELECT mode FROM global_system_state WHERE id = 1');
    const dbMode: SystemMode = res.rows[0].mode;
    const cachedMode = await redis.get('vitalos:system_mode');

    if (dbMode !== cachedMode) {
      await redis.set('vitalos:system_mode', dbMode);
      await publishEvent('vitalos.system.mode_changed', 'governance-sync', { mode: dbMode, timestamp: Date.now() });
      logger.warn('Governance', 'Mode drift detected and corrected', { db_mode: dbMode, cached_mode: cachedMode });
    }
  } catch (e: any) {
    logger.error('Governance', 'Sync error', { error: e.message });
  } finally {
    setTimeout(syncGovernanceMode, 5_000);
  }
}
