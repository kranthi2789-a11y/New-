/**
 * VitalOS Governance Service Entry Point
 */
import { startGovernanceConsumer, syncGovernanceMode } from './sync-service';
import { initKafka } from '../../libs/events/kafka';
import { logger } from '../../libs/common/logger';

async function start() {
  await initKafka();
  logger.info('Governance', 'Starting governance consumer and mode sync');
  await startGovernanceConsumer();
  syncGovernanceMode();
}

start().catch(e => {
  logger.error('Governance', 'Fatal startup error', { error: String(e) });
  process.exit(1);
});
