/**
 * VitalOS Orchestrator Service Entry Point
 */
import { startConsumer, shutdownConsumer } from './consumer';
import { initKafka, shutdownKafka } from '../../libs/events/kafka';
import { logger } from '../../libs/common/logger';

async function start() {
  await initKafka();
  await startConsumer();
  logger.info('OrchestratorService', 'VitalOS Orchestrator (The Judge) is running');
}

async function shutdown() {
  logger.info('OrchestratorService', 'Shutting down...');
  await shutdownConsumer();
  await shutdownKafka();
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

start().catch(e => {
  logger.error('OrchestratorService', 'Fatal startup error', { error: String(e) });
  process.exit(1);
});
