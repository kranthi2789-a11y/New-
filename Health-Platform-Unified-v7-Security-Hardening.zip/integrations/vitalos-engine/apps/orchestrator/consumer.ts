/**
 * VitalOS Orchestrator Kafka Consumer
 * - Manual offset commit AFTER successful DB transaction
 * - Safe JSON parse — malformed messages are DLQ'd, not crashed
 * - Schema version validation before forwarding to Orchestrator
 */

import { kafka } from '../../libs/events/kafka';
import { Orchestrator } from './index';
import { logger } from '../../libs/common/logger';
import { VitalOSEvent } from '../../libs/common/types';

const orchestrator = new Orchestrator();
const consumer = kafka.consumer({ groupId: 'vitalos-orchestrator-group' });

export async function startConsumer(): Promise<void> {
  await consumer.connect();
  await consumer.subscribe({ topic: 'vitalos.case.events', fromBeginning: false });

  logger.info('OrchestratorConsumer', 'Kafka consumer started — listening on vitalos.case.events');

  await consumer.run({
    autoCommit: false,
    eachMessage: async ({ topic, partition, message }) => {
      const offset = message.offset;
      let event: VitalOSEvent | null = null;

      // Safe JSON parse — bad messages go to DLQ, never crash consumer
      try {
        event = JSON.parse(message.value!.toString()) as VitalOSEvent;
      } catch (e) {
        logger.error('OrchestratorConsumer', 'Malformed event payload — sending to DLQ', {
          offset,
          partition,
          raw: message.value?.toString().substring(0, 100),
        });
        // Commit offset so we don't reprocess poison pill
        await consumer.commitOffsets([{ topic, partition, offset: (BigInt(offset) + 1n).toString() }]);
        return;
      }

      // Schema version guard
      if (!event.header?.schema_version) {
        logger.error('OrchestratorConsumer', 'Missing schema_version — rejecting', { offset });
        await consumer.commitOffsets([{ topic, partition, offset: (BigInt(offset) + 1n).toString() }]);
        return;
      }

      try {
        await orchestrator.handleAgentResponse(event);
        // Only commit AFTER successful DB transaction
        await consumer.commitOffsets([{ topic, partition, offset: (BigInt(offset) + 1n).toString() }]);
      } catch (e: any) {
        logger.error('OrchestratorConsumer', 'Orchestrator handle error — offset NOT committed (will retry)', {
          trace_id: event.header.trace_id,
          case_id: event.payload.case_id,
          error: e.message,
        });
        // Do NOT commit — Kafka will redeliver
      }
    },
  });
}

export async function shutdownConsumer(): Promise<void> {
  await consumer.disconnect();
  logger.info('OrchestratorConsumer', 'Consumer disconnected');
}
