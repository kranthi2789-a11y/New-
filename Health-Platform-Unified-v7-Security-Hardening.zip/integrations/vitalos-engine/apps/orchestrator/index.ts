/**
 * VitalOS Orchestrator — The "Judge"
 *
 * This is the ONLY component that may mutate clinical state.
 * Python agents are stateless Counsel — they suggest, we decide.
 *
 * Guarantees:
 *   1. Distributed lock (striped, priority-aware, heartbeat-renewed)
 *   2. Idempotency check before ANY write
 *   3. Sequence gap buffering + recursive replay
 *   4. Valid transition enforcement (DB-level + in-memory)
 *   5. SHA-256 cryptographic audit chain
 *   6. Deadlock/serialization retry with jitter
 *   7. Priority aging (anti-starvation)
 */

import { Pool, PoolClient } from 'pg';
import { StripedLock } from '../../libs/locking';
import { computeAuditHash, ROOT_GENESIS } from '../../libs/audit/hash';
import { publishEvent } from '../../libs/events/kafka';
import { logger } from '../../libs/common/logger';
import { VALID_TRANSITIONS, VitalOSEvent, ClinicalState, AgentInferenceResponse } from '../../libs/common/types';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
});

const lockManager = new StripedLock(process.env.REDIS_URL!);

// ── Internal transition executor ──────────────────────────────
async function executeTransition(client: PoolClient, event: VitalOSEvent, lastAuditId: string | null): Promise<void> {
  const { case_id, suggested_state, confidence_score, data } = event.payload;
  const { trace_id, idempotency_key, sequence_number, origin, schema_version, agent_version } = event.header;

  // Validate transition against DB state machine
  const txCheck = await client.query(
    `SELECT 1 FROM valid_transitions vt
     JOIN case_state_machine csm ON vt.from_state = csm.current_state
     WHERE csm.case_id = $1 AND vt.to_state = $2`,
    [case_id, suggested_state]
  );
  if (txCheck.rowCount === 0) {
    throw new Error(`ILLEGAL_STATE_TRANSITION: ${suggested_state} — case ${case_id}`);
  }

  // Get previous hash
  let prevHash = ROOT_GENESIS;
  if (lastAuditId) {
    const prevRes = await client.query('SELECT record_hash FROM global_audit_trail WHERE id = $1', [lastAuditId]);
    prevHash = prevRes.rows[0]?.record_hash || ROOT_GENESIS;
  }

  const auditPayload = {
    case_id,
    target_state: suggested_state,
    confidence_score,
    origin,
    trace_id,
    schema_version,
    agent_version,
    data,
    committed_at: new Date().toISOString(),
  };

  const newHash = computeAuditHash(prevHash, auditPayload);

  const auditRes = await client.query(
    `INSERT INTO global_audit_trail
       (case_id, record_hash, previous_hash, payload, idempotency_key)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING id`,
    [case_id, newHash, prevHash, auditPayload, idempotency_key]
  );

  await client.query(
    `UPDATE case_state_machine
     SET current_state = $1,
         last_sequence_number = $2,
         last_audit_id = $3,
         version = version + 1,
         updated_at = NOW(),
         priority_score = priority_score + (EXTRACT(EPOCH FROM (NOW() - updated_at)) / 60)
     WHERE case_id = $4`,
    [suggested_state, sequence_number, auditRes.rows[0].id, case_id]
  );

  logger.audit('Orchestrator', 'State transition committed', {
    trace_id,
    case_id,
    sequence_number,
    new_state: suggested_state,
    audit_id: auditRes.rows[0].id,
    hash: newHash.substring(0, 16) + '...',
  });
}

// ── Out-of-band system transition (gap escalation, safe mode) ─
export async function executeSystemTransition(
  client: PoolClient,
  params: { caseId: string; targetState: ClinicalState; reason: string; idempotencyKey: string; traceId?: string }
): Promise<void> {
  const stateRes = await client.query(
    'SELECT last_audit_id, current_state FROM case_state_machine WHERE case_id = $1 FOR UPDATE',
    [params.caseId]
  );
  const { last_audit_id, current_state } = stateRes.rows[0];

  // Validate OOB transition too
  const allowed = VALID_TRANSITIONS[current_state as ClinicalState] || [];
  if (!allowed.includes(params.targetState)) {
    throw new Error(`SYSTEM_TRANSITION_ILLEGAL: ${current_state} → ${params.targetState}`);
  }

  let prevHash = ROOT_GENESIS;
  if (last_audit_id) {
    const p = await client.query('SELECT record_hash FROM global_audit_trail WHERE id = $1', [last_audit_id]);
    prevHash = p.rows[0]?.record_hash || ROOT_GENESIS;
  }

  const auditPayload = {
    system_action: true,
    reason: params.reason,
    target_state: params.targetState,
    trace_id: params.traceId || 'system',
    schema_version: '1.0.0',
    committed_at: new Date().toISOString(),
  };
  const newHash = computeAuditHash(prevHash, auditPayload);

  const auditRes = await client.query(
    `INSERT INTO global_audit_trail (case_id, record_hash, previous_hash, payload, idempotency_key)
     VALUES ($1, $2, $3, $4, $5) RETURNING id`,
    [params.caseId, newHash, prevHash, auditPayload, params.idempotencyKey]
  );

  await client.query(
    `UPDATE case_state_machine SET current_state = $1, last_audit_id = $2, updated_at = NOW() WHERE case_id = $3`,
    [params.targetState, auditRes.rows[0].id, params.caseId]
  );

  logger.audit('Orchestrator', 'System transition committed', {
    case_id: params.caseId,
    reason: params.reason,
    new_state: params.targetState,
  });
}

// ── Main entry: handle agent inference response ────────────────
export class Orchestrator {
  async handleAgentResponse(event: VitalOSEvent): Promise<void> {
    const { case_id } = event.payload;
    const { trace_id, sequence_number, idempotency_key, schema_version } = event.header;

    // Schema version guard
    if (schema_version !== '1.0.0') {
      logger.error('Orchestrator', 'Schema version mismatch — rejecting event', { trace_id, schema_version });
      return;
    }

    const MAX_RETRIES = 3;
    let retries = MAX_RETRIES;

    while (retries > 0) {
      const lockToken = await lockManager.acquire(case_id, event.priority || 1);
      if (!lockToken) {
        retries--;
        await new Promise(r => setTimeout(r, 150 + Math.random() * 100));
        logger.warn('Orchestrator', 'Lock contention — retrying', { trace_id, case_id, retries_left: retries });
        continue;
      }

      const client = await pool.connect();
      try {
        await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ');

        // 1. Idempotency check
        const idemp = await client.query(
          'SELECT 1 FROM global_audit_trail WHERE idempotency_key = $1',
          [idempotency_key]
        );
        if (idemp.rowCount! > 0) {
          logger.info('Orchestrator', 'Duplicate event — skipping (idempotent)', { trace_id, idempotency_key });
          await client.query('ROLLBACK');
          return;
        }

        // 2. Fetch state with row lock
        const stateRes = await client.query(
          `SELECT current_state, last_sequence_number, last_audit_id, is_locked
           FROM case_state_machine WHERE case_id = $1 FOR UPDATE`,
          [case_id]
        );
        const state = stateRes.rows[0];

        if (!state) {
          throw new Error(`CASE_NOT_FOUND: ${case_id}`);
        }
        if (state.is_locked) {
          logger.warn('Orchestrator', 'Case locked — skipping', { trace_id, case_id });
          await client.query('ROLLBACK');
          return;
        }
        if (state.current_state === 'ESCALATED' || state.current_state === 'CLOSED') {
          logger.info('Orchestrator', 'Terminal state — no further transitions', { trace_id, case_id, state: state.current_state });
          await client.query('ROLLBACK');
          return;
        }

        // 3. Sequence gap handling
        const lastSeq = parseInt(state.last_sequence_number);
        if (sequence_number > lastSeq + 1) {
          await client.query(
            'INSERT INTO event_buffer (case_id, sequence_number, payload) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING',
            [case_id, sequence_number, event]
          );
          await client.query('COMMIT');
          logger.info('Orchestrator', 'Event buffered (sequence gap)', { trace_id, case_id, expected: lastSeq + 1, received: sequence_number });
          return;
        }

        // 4. Execute + recursive replay from buffer
        let activeEvent: VitalOSEvent | null = event;
        let currentLastAuditId = state.last_audit_id;
        while (activeEvent) {
          await executeTransition(client, activeEvent, currentLastAuditId);

          // Fetch updated audit id for chain continuity
          const updatedState = await client.query(
            'SELECT last_audit_id FROM case_state_machine WHERE case_id = $1',
            [case_id]
          );
          currentLastAuditId = updatedState.rows[0].last_audit_id;

          const nextSeq = parseInt(activeEvent.header.sequence_number.toString()) + 1;
          const next = await client.query(
            'DELETE FROM event_buffer WHERE case_id = $1 AND sequence_number = $2 RETURNING payload',
            [case_id, nextSeq]
          );
          activeEvent = next.rows[0]?.payload || null;
        }

        await client.query('COMMIT');
        logger.info('Orchestrator', 'Event processed successfully', { trace_id, case_id, sequence_number });

        // Publish state change notification
        await publishEvent('vitalos.case.state_changed', case_id, {
          case_id,
          new_state: event.payload.suggested_state,
          trace_id,
          timestamp: Date.now(),
        });

        break; // Success — exit retry loop

      } catch (e: any) {
        await client.query('ROLLBACK');

        // Deadlock / serialization failure — retry with jitter
        if (e.code === '40001' || e.code === '40P01') {
          retries--;
          const jitter = Math.random() * 200 + 50;
          logger.warn('Orchestrator', `${e.code === '40P01' ? 'Deadlock' : 'Serialization'} — retry ${MAX_RETRIES - retries}/${MAX_RETRIES}`, { trace_id, case_id });
          await new Promise(r => setTimeout(r, jitter));
        } else {
          logger.error('Orchestrator', 'Non-retryable error', { trace_id, case_id, error: e.message });
          throw e;
        }
      } finally {
        client.release();
        await lockManager.release(case_id, lockToken);
      }
    }
  }
}
