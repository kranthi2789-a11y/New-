/**
 * VitalOS Gap Escalation Worker
 *
 * When a sequence gap is detected and times out, the case is OOB-escalated.
 * Risk tiers (from AegisCare design):
 *   EMERGENCY → 30 seconds
 *   HIGH      → 2 minutes
 *   MEDIUM    → 5 minutes
 *   LOW       → 5 minutes
 */

import { Pool } from 'pg';
import { executeSystemTransition } from '../orchestrator/index';
import { publishEvent } from '../../libs/events/kafka';
import { logger } from '../../libs/common/logger';
import { v4 as uuidv4 } from 'uuid';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export async function gapEscalationLoop(): Promise<void> {
  const client = await pool.connect();
  try {
    // Fetch stale buffered cases by risk tier — SKIP LOCKED for safe parallelism
    const staleCases = await client.query(`
      SELECT DISTINCT eb.case_id, csm.risk_level
      FROM event_buffer eb
      JOIN case_state_machine csm ON eb.case_id = csm.case_id
      WHERE (
        (csm.risk_level = 'EMERGENCY' AND eb.created_at < NOW() - INTERVAL '30 seconds') OR
        (csm.risk_level = 'HIGH'      AND eb.created_at < NOW() - INTERVAL '2 minutes')  OR
        (csm.risk_level = 'MEDIUM'    AND eb.created_at < NOW() - INTERVAL '5 minutes')  OR
        (csm.risk_level = 'LOW'       AND eb.created_at < NOW() - INTERVAL '5 minutes')
      )
      AND csm.current_state NOT IN ('ESCALATED', 'CLOSED')
      FOR UPDATE OF csm SKIP LOCKED
    `);

    for (const row of staleCases.rows) {
      // Isolated connection per iteration — one failure doesn't affect others
      const iterClient = await pool.connect();
      try {
        await iterClient.query('BEGIN');

        // Deterministic idempotency key (no Date.now() — prevents duplicates on retry)
        const idempotencyKey = `gap-esc:${row.case_id}`;
        const traceId = `gap-esc-${uuidv4()}`;

        await executeSystemTransition(iterClient, {
          caseId: row.case_id,
          targetState: 'ESCALATED',
          reason: `SEQUENCE_GAP_TIMEOUT:${row.risk_level}`,
          idempotencyKey,
          traceId,
        });

        await iterClient.query('DELETE FROM event_buffer WHERE case_id = $1', [row.case_id]);
        await iterClient.query('COMMIT');

        // Notify downstream via Kafka
        await publishEvent('vitalos.case.escalated', row.case_id, {
          case_id: row.case_id,
          reason: 'GAP_TIMEOUT',
          risk_level: row.risk_level,
          trace_id: traceId,
          timestamp: Date.now(),
        });

        logger.warn('GapEscalation', 'Case escalated due to sequence gap timeout', {
          case_id: row.case_id,
          risk_level: row.risk_level,
          trace_id: traceId,
        });
      } catch (e: any) {
        await iterClient.query('ROLLBACK');
        logger.error('GapEscalation', 'Escalation iteration failed', { case_id: row.case_id, error: e.message });
      } finally {
        iterClient.release();
      }
    }
  } catch (e: any) {
    logger.error('GapEscalation', 'Gap loop error', { error: e.message });
  } finally {
    client.release();
    // Schedule next cycle
    setTimeout(gapEscalationLoop, 5_000);
  }
}
