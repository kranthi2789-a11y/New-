/**
 * VitalOS Monitoring Service Entry Point
 */
import { gapEscalationLoop } from './gap-escalation-worker';
import { detectAnomalies } from './anomaly-detector';
import { initKafka } from '../../libs/events/kafka';
import { logger } from '../../libs/common/logger';

async function start() {
  await initKafka();
  logger.info('Monitoring', 'Starting gap escalation loop and anomaly detector');
  gapEscalationLoop();
  detectAnomalies();
}

start().catch(e => {
  logger.error('Monitoring', 'Fatal startup error', { error: String(e) });
  process.exit(1);
});
