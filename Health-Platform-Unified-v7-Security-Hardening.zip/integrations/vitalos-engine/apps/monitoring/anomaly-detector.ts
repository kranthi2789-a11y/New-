/**
 * VitalOS Anomaly Detector
 * - EMA-based spike detection on event buffer size
 * - NEVER writes directly to DB — sends governance trigger via Kafka
 *   (fixes the V3 bug where anomaly detector bypassed governance sync)
 */

import { Pool } from 'pg';
import { Redis } from 'ioredis';
import { publishEvent } from '../../libs/events/kafka';
import { logger } from '../../libs/common/logger';
import { GovernanceTrigger } from '../../libs/common/types';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const redis = new Redis(process.env.REDIS_URL!);

const EMA_ALPHA = 0.1;              // Smoothing factor
const BUFFER_ABS_THRESHOLD = 5_000; // Absolute spike threshold
const BUFFER_EMA_MULTIPLIER = 4;    // Relative spike: 4x EMA
const LOAD_SAMPLE_INTERVAL = 10_000;

export async function detectAnomalies(): Promise<void> {
  try {
    // Buffer size metric
    const bufferRes = await pool.query('SELECT COUNT(*) as count FROM event_buffer');
    const bufferSize = parseInt(bufferRes.rows[0].count);

    // Update EMA
    const currentEma = parseFloat((await redis.get('vitalos:metrics:ema_buffer_size')) || '0');
    const newEma = currentEma * (1 - EMA_ALPHA) + bufferSize * EMA_ALPHA;
    await redis.set('vitalos:metrics:ema_buffer_size', newEma.toFixed(4));

    // Update system load EMA (for backpressure guard in API Gateway)
    const activeRes = await pool.query(`SELECT COUNT(*) as count FROM case_state_machine WHERE current_state NOT IN ('CLOSED', 'ESCALATED')`);
    const activeCases = parseInt(activeRes.rows[0].count);
    const loadEma = parseFloat((await redis.get('vitalos:metrics:ema_load')) || '0');
    const newLoadEma = loadEma * (1 - EMA_ALPHA) + (activeCases / 10_000) * EMA_ALPHA; // Normalize to 0-1
    await redis.set('vitalos:metrics:ema_load', Math.min(newLoadEma, 1).toFixed(4));

    logger.debug('AnomalyDetector', 'Metrics updated', { buffer_size: bufferSize, buffer_ema: newEma.toFixed(2), load_ema: newLoadEma.toFixed(4) });

    // Spike detection
    const isAbsoluteSpike = bufferSize > BUFFER_ABS_THRESHOLD;
    const isRelativeSpike = bufferSize > newEma * BUFFER_EMA_MULTIPLIER && newEma > 10;

    if (isAbsoluteSpike || isRelativeSpike) {
      const reason = isAbsoluteSpike ? `BUFFER_SIZE_${bufferSize}_EXCEEDS_${BUFFER_ABS_THRESHOLD}` : `EMA_SPIKE_${bufferSize}_vs_EMA_${newEma.toFixed(0)}`;

      const trigger: GovernanceTrigger = {
        action: 'ENABLE_SAFE_MODE',
        reason,
        timestamp: Date.now(),
        schema_version: '1.0.0',
      };

      // FIX: Via Kafka, NOT direct DB write — governance service owns mode transitions
      await publishEvent('vitalos.governance.trigger', 'anomaly-detector', trigger);
      logger.warn('AnomalyDetector', 'Safe mode triggered via Kafka', { reason, buffer_size: bufferSize, ema: newEma.toFixed(2) });
    }
  } catch (e: any) {
    logger.error('AnomalyDetector', 'Detection cycle error', { error: e.message });
  } finally {
    setTimeout(detectAnomalies, LOAD_SAMPLE_INTERVAL);
  }
}
