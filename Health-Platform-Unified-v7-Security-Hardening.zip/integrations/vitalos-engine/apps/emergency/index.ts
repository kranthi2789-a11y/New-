/**
 * VitalOS Emergency Service
 *
 * Dedicated emergency escalation handler.
 * Responsibilities:
 *   1. Consume vitalos.case.escalated Kafka topic
 *   2. Trigger immediate OOB system transition for EMERGENCY risk cases
 *   3. Publish 108-routing alerts for life-critical events
 *   4. Bypass Safe Mode — emergency traffic is ALWAYS processed
 *
 * This service runs independently so a Safe Mode shutdown of
 * non-critical services never blocks emergency handling.
 */

import { kafka, initKafka, publishEvent, shutdownKafka } from '../../libs/events/kafka';
import { logger } from '../../libs/common/logger';
import { Pool } from 'pg';
import { executeSystemTransition } from '../orchestrator/index';
import { v4 as uuidv4 } from 'uuid';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 5,
});

const consumer = kafka.consumer({ groupId: 'vitalos-emergency-group' });

// ── Emergency escalation consumer ────────────────────────────
async function startEmergencyConsumer(): Promise<void> {
  await consumer.connect();
  await consumer.subscribe({ topic: 'vitalos.case.escalated', fromBeginning: false });

  logger.info('EmergencyService', 'Listening on vitalos.case.escalated — EMERGENCY bypass active');

  await consumer.run({
    autoCommit: false,
    eachMessage: async ({ topic, partition, message }) => {
      const offset = message.offset;
      let payload: any;

      try {
        payload = JSON.parse(message.value!.toString());
      } catch {
        logger.error('EmergencyService', 'Malformed escalation event — skipping', { offset });
        await consumer.commitOffsets([{ topic, partition, offset: (BigInt(offset) + 1n).toString() }]);
        return;
      }

      const { case_id, risk_level, reason, trace_id } = payload;

      // Only handle EMERGENCY risk level — HIGH/MEDIUM handled by gap worker
      if (risk_level !== 'EMERGENCY') {
        await consumer.commitOffsets([{ topic, partition, offset: (BigInt(offset) + 1n).toString() }]);
        return;
      }

      logger.warn('EmergencyService', '🚨 EMERGENCY case received — triggering immediate dispatch', {
        trace_id,
        case_id,
        reason,
      });

      // Publish 108 dispatch alert
      await publishEvent('vitalos.emergency.dispatch', case_id, {
        case_id,
        action: 'DISPATCH_108',
        ambulance_number: '108',
        risk_level,
        reason,
        trace_id,
        dispatched_at: new Date().toISOString(),
        schema_version: '1.0.0',
      });

      // Log to clinical alert stream for real-time monitoring
      await publishEvent('vitalos.clinical.alert', case_id, {
        case_id,
        alert_type: 'EMERGENCY_ESCALATION',
        severity: 'CRITICAL',
        message: `EMERGENCY case escalated: ${reason}`,
        trace_id,
        timestamp: Date.now(),
      });

      logger.audit('EmergencyService', '108 dispatch published', { case_id, trace_id });
      await consumer.commitOffsets([{ topic, partition, offset: (BigInt(offset) + 1n).toString() }]);
    },
  });
}

// ── Proactive EMERGENCY case scanner ─────────────────────────
// Finds EMERGENCY cases that missed the gap worker SLA (belt + suspenders)
async function emergencyScanner(): Promise<void> {
  const client = await pool.connect();
  try {
    const stale = await client.query(`
      SELECT case_id, risk_level
      FROM case_state_machine
      WHERE risk_level = 'EMERGENCY'
        AND current_state NOT IN ('ESCALATED', 'CLOSED')
        AND updated_at < NOW() - INTERVAL '45 seconds'
        AND is_locked = FALSE
      FOR UPDATE SKIP LOCKED
    `);

    for (const row of stale.rows) {
      const iterClient = await pool.connect();
      try {
        await iterClient.query('BEGIN');
        const idempKey = `emergency-scan:${row.case_id}`;
        const traceId  = `emergency-${uuidv4()}`;

        await executeSystemTransition(iterClient, {
          caseId:        row.case_id,
          targetState:   'ESCALATED',
          reason:        'EMERGENCY_SCANNER_SLA_BREACH',
          idempotencyKey: idempKey,
          traceId,
        });

        await iterClient.query('DELETE FROM event_buffer WHERE case_id = $1', [row.case_id]);
        await iterClient.query('COMMIT');

        await publishEvent('vitalos.case.escalated', row.case_id, {
          case_id:    row.case_id,
          risk_level: 'EMERGENCY',
          reason:     'EMERGENCY_SCANNER_SLA_BREACH',
          trace_id:   traceId,
          timestamp:  Date.now(),
        });

        logger.warn('EmergencyService', 'Scanner escalated stale EMERGENCY case', {
          case_id: row.case_id,
          trace_id: traceId,
        });
      } catch (e: any) {
        await iterClient.query('ROLLBACK');
        logger.error('EmergencyService', 'Scanner escalation failed', { case_id: row.case_id, error: e.message });
      } finally {
        iterClient.release();
      }
    }
  } catch (e: any) {
    logger.error('EmergencyService', 'Scanner loop error', { error: e.message });
  } finally {
    client.release();
    setTimeout(emergencyScanner, 10_000); // Every 10s — tighter than gap worker
  }
}

// ── Startup ───────────────────────────────────────────────────
async function start(): Promise<void> {
  await initKafka();
  await startEmergencyConsumer();
  emergencyScanner();
  logger.info('EmergencyService', '🚨 VitalOS Emergency Service online — 108 routing active');
}

async function shutdown(): Promise<void> {
  await consumer.disconnect();
  await shutdownKafka();
  await pool.end();
  logger.info('EmergencyService', 'Emergency service shutdown complete');
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT',  shutdown);

start().catch(e => {
  logger.error('EmergencyService', 'Fatal startup error', { error: String(e) });
  process.exit(1);
});
