/**
 * VitalOS Triage Service
 *
 * Rule-based + AI-assisted clinical triage classification.
 * Responsibilities:
 *   1. Consume vitalos.triage.requests topic
 *   2. Apply deterministic rule engine FIRST (vital signs, red flags)
 *   3. If rules inconclusive → call Python AI triage agent
 *   4. Validate AI response via AgentInferenceSchema
 *   5. Publish validated result to vitalos.case.events for Orchestrator
 *
 * The Orchestrator is STILL the Judge — this service only prepares
 * a well-formed VitalOSEvent and sends it. It never commits state.
 */

import { kafka, initKafka, publishEvent, shutdownKafka } from '../../libs/events/kafka';
import { logger } from '../../libs/common/logger';
import { VitalOSEvent, EVENT_SCHEMA_VERSION, AGENT_VERSION, RiskLevel } from '../../libs/common/types';
import { createHash } from 'crypto';
import { v4 as uuidv4 } from 'uuid';

const PYTHON_AGENTS_URL = process.env.PYTHON_AGENTS_URL || 'http://localhost:8000';
const consumer = kafka.consumer({ groupId: 'vitalos-triage-group' });

// ── Deterministic rule engine (no AI needed) ──────────────────
interface TriageInput {
  case_id:  string;
  symptoms: string;
  vitals?:  Record<string, number>;
  age?:     number;
}

interface TriageResult {
  risk_level:        RiskLevel;
  confidence:        number;
  rule_triggered?:   string;
  requires_ai:       boolean;
}

const RED_FLAG_KEYWORDS = [
  'chest pain', 'heart attack', 'stroke', 'unconscious', 'not breathing',
  'heavy bleeding', 'seizure', 'anaphylaxis', 'सीने में दर्द', 'बेहोश',
  'difficulty breathing', 'severe pain', 'paralysis', 'coughing blood',
];

const HIGH_KEYWORDS = [
  'high fever', 'vomiting blood', 'severe headache', 'diabetic', 'hypoglycemia',
  'dka', 'ketoacidosis', 'acute abdomen', 'trauma',
];

function applyRuleEngine(input: TriageInput): TriageResult {
  const text = input.symptoms.toLowerCase();

  // EMERGENCY: red-flag keywords → no AI needed
  for (const kw of RED_FLAG_KEYWORDS) {
    if (text.includes(kw)) {
      return { risk_level: 'EMERGENCY', confidence: 1.0, rule_triggered: kw, requires_ai: false };
    }
  }

  // Vital sign rules (if provided)
  const v = input.vitals ?? {};
  if (v.spo2 !== undefined && v.spo2 < 90) {
    return { risk_level: 'EMERGENCY', confidence: 0.98, rule_triggered: 'spo2<90', requires_ai: false };
  }
  if (v.systolic_bp !== undefined && v.systolic_bp > 180) {
    return { risk_level: 'HIGH', confidence: 0.95, rule_triggered: 'bp_hypertensive_crisis', requires_ai: false };
  }
  if (v.hr !== undefined && (v.hr < 40 || v.hr > 150)) {
    return { risk_level: 'HIGH', confidence: 0.92, rule_triggered: 'hr_extreme', requires_ai: false };
  }
  if (v.temp !== undefined && v.temp > 39.5) {
    return { risk_level: 'HIGH', confidence: 0.88, rule_triggered: 'high_fever', requires_ai: false };
  }

  // HIGH: known high-risk keywords
  for (const kw of HIGH_KEYWORDS) {
    if (text.includes(kw)) {
      return { risk_level: 'HIGH', confidence: 0.85, rule_triggered: kw, requires_ai: false };
    }
  }

  // Age-based escalation
  const age = input.age ?? 40;
  if (age > 70 || age < 5) {
    return { risk_level: 'HIGH', confidence: 0.75, rule_triggered: 'age_risk', requires_ai: true };
  }

  // Inconclusive — send to AI
  return { risk_level: 'MEDIUM', confidence: 0.6, requires_ai: true };
}

// ── AI triage call ────────────────────────────────────────────
async function callAITriage(input: TriageInput, traceId: string): Promise<{ risk_level: RiskLevel; confidence: number }> {
  const res = await fetch(`${PYTHON_AGENTS_URL}/api/v1/emergency/triage`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json', 'x-trace-id': traceId, 'x-clinical-priority': 'true' },
    body: JSON.stringify({ symptoms: input.symptoms, patient_profile: { age: input.age, vitals: input.vitals } }),
  });

  if (!res.ok) throw new Error(`AI triage failed: ${res.status}`);
  const data = await res.json();

  // Map severity → RiskLevel
  const sev: Record<string, RiskLevel> = {
    life_threatening: 'EMERGENCY',
    severe:           'HIGH',
    moderate:         'MEDIUM',
    minor:            'LOW',
  };

  return {
    risk_level: sev[data.severity] ?? 'MEDIUM',
    confidence: data.severity === 'life_threatening' ? 1.0 : 0.8,
  };
}

// ── Build VitalOSEvent for Orchestrator ───────────────────────
function buildTriageEvent(input: TriageInput, result: TriageResult, traceId: string, seqNum: number): VitalOSEvent {
  const idempKey = createHash('sha256')
    .update(`${input.case_id}:${seqNum}:triage-service`)
    .digest('hex');

  return {
    header: {
      event_id:         uuidv4(),
      trace_id:         traceId,
      sequence_number:  seqNum,
      idempotency_key:  idempKey,
      timestamp:        Date.now(),
      origin:           'triage-service',
      schema_version:   EVENT_SCHEMA_VERSION,
      agent_version:    AGENT_VERSION,
    },
    payload: {
      case_id:          input.case_id,
      suggested_state:  'TRIAGE_COMPLETED',
      confidence_score: result.confidence,
      risk_level:       result.risk_level,
      data: {
        symptoms:        input.symptoms,
        vitals:          input.vitals,
        rule_triggered:  result.rule_triggered,
        ai_used:         result.requires_ai,
      },
      inference_trace: result.rule_triggered
        ? `rule:${result.rule_triggered}`
        : 'ai:emergency-triage-agent',
    },
    priority: result.risk_level === 'EMERGENCY' ? 10
             : result.risk_level === 'HIGH'      ? 7
             : result.risk_level === 'MEDIUM'    ? 4 : 1,
  };
}

// ── Triage consumer ───────────────────────────────────────────
async function startTriageConsumer(): Promise<void> {
  await consumer.connect();
  await consumer.subscribe({ topic: 'vitalos.triage.requests', fromBeginning: false });

  logger.info('TriageService', 'Listening on vitalos.triage.requests');

  await consumer.run({
    autoCommit: false,
    eachMessage: async ({ topic, partition, message }) => {
      const offset = message.offset;
      let req: any;

      try {
        req = JSON.parse(message.value!.toString());
      } catch {
        logger.error('TriageService', 'Malformed triage request', { offset });
        await consumer.commitOffsets([{ topic, partition, offset: (BigInt(offset) + 1n).toString() }]);
        return;
      }

      const traceId: string = req.trace_id ?? `triage-${uuidv4()}`;
      const input: TriageInput = {
        case_id:  req.case_id,
        symptoms: req.symptoms ?? '',
        vitals:   req.vitals,
        age:      req.age,
      };

      try {
        // 1. Deterministic rules first
        let result = applyRuleEngine(input);

        // 2. AI assist if rules inconclusive
        if (result.requires_ai) {
          try {
            const aiResult = await callAITriage(input, traceId);
            // AI can only escalate, not downgrade rule result
            const levelOrder: Record<RiskLevel, number> = { EMERGENCY: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
            if (levelOrder[aiResult.risk_level] > levelOrder[result.risk_level]) {
              result = { ...result, ...aiResult, requires_ai: true };
            }
          } catch (e: any) {
            logger.warn('TriageService', 'AI triage failed — using rule result', { trace_id: traceId, error: e.message });
          }
        }

        // 3. Build and publish event to Orchestrator
        const seqNum: number = req.sequence_number ?? 1;
        const event = buildTriageEvent(input, result, traceId, seqNum);
        await publishEvent('vitalos.case.events', input.case_id, event);

        logger.info('TriageService', 'Triage complete — event published to Orchestrator', {
          trace_id:   traceId,
          case_id:    input.case_id,
          risk_level: result.risk_level,
          confidence: result.confidence,
          ai_used:    result.requires_ai,
        });

        await consumer.commitOffsets([{ topic, partition, offset: (BigInt(offset) + 1n).toString() }]);
      } catch (e: any) {
        logger.error('TriageService', 'Triage processing failed — will retry', {
          trace_id: traceId,
          case_id:  input.case_id,
          error:    e.message,
        });
        // Do NOT commit — Kafka redelivers
      }
    },
  });
}

// ── Startup ───────────────────────────────────────────────────
async function start(): Promise<void> {
  await initKafka();
  await startTriageConsumer();
  logger.info('TriageService', '🧠 VitalOS Triage Service online — Rule engine + AI hybrid active');
}

async function shutdown(): Promise<void> {
  await consumer.disconnect();
  await shutdownKafka();
  logger.info('TriageService', 'Triage service shutdown complete');
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT',  shutdown);

start().catch(e => {
  logger.error('TriageService', 'Fatal startup error', { error: String(e) });
  process.exit(1);
});
