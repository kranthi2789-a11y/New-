/**
 * VitalOS API Gateway
 *
 * Responsibilities:
 *   1. JWT authentication + RBAC enforcement
 *   2. Safe Mode guard (blocks non-clinical traffic)
 *   3. EMA-based backpressure (system saturation)
 *   4. Rate limiting per role (AI endpoints are expensive)
 *   5. Trace ID injection (propagated to all downstream services)
 *   6. Routes: case creation → Kafka; agent inference proxy → Python service
 */

import express, { Request, Response, NextFunction } from 'express';
import { Redis } from 'ioredis';
import { v4 as uuidv4 } from 'uuid';
import jwt from 'jsonwebtoken';
import rateLimit from 'express-rate-limit';
import { initKafka, publishEvent } from '../../libs/events/kafka';
import { logger } from '../../libs/common/logger';
import { VitalOSEvent, EVENT_SCHEMA_VERSION, AGENT_VERSION } from '../../libs/common/types';
import { createHash } from 'crypto';

const app = express();
const redis = new Redis(process.env.REDIS_URL!, { lazyConnect: false });

const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_THIS_IN_PRODUCTION_32_CHARS_MIN';
const PYTHON_AGENTS_URL = process.env.PYTHON_AGENTS_URL || 'http://localhost:8000';

app.use(express.json({ limit: '10mb' }));

// ── Roles ─────────────────────────────────────────────────────
export type UserRole = 'patient' | 'doctor' | 'emergency_responder' | 'admin';

export interface AuthUser {
  user_id: string;
  role: UserRole;
  name: string;
}

// ── 1. JWT Authentication ─────────────────────────────────────
const authenticate = (req: Request & { user?: AuthUser }, res: Response, next: NextFunction) => {
  const authHeader = req.headers['authorization'];
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'MISSING_AUTH_TOKEN' });
  }
  try {
    const payload = jwt.verify(authHeader.slice(7), JWT_SECRET) as AuthUser;
    req.user = payload;
    next();
  } catch {
    res.status(401).json({ error: 'INVALID_OR_EXPIRED_TOKEN' });
  }
};

// ── 2. RBAC enforcement ───────────────────────────────────────
const requireRole = (...roles: UserRole[]) => (req: Request & { user?: AuthUser }, res: Response, next: NextFunction) => {
  if (!req.user || !roles.includes(req.user.role)) {
    return res.status(403).json({ error: 'INSUFFICIENT_ROLE', required: roles, has: req.user?.role });
  }
  next();
};

// ── 3. Safe Mode Guard ────────────────────────────────────────
const safeModeGuard = async (req: Request, res: Response, next: NextFunction) => {
  const mode = (await redis.get('vitalos:system_mode')) || 'NORMAL';
  if (mode === 'SAFE_MODE') {
    const isClinical = req.headers['x-clinical-priority'] === 'true';
    const isEmergency = req.path.includes('/emergency');
    if (!isClinical && !isEmergency) {
      logger.warn('APIGateway', 'SAFE_MODE blocked non-clinical request', { path: req.path });
      return res.status(503).json({ error: 'SAFE_MODE_ACTIVE', message: 'Non-clinical requests blocked. Only emergency traffic allowed.' });
    }
  }
  next();
};

// ── 4. EMA Backpressure ───────────────────────────────────────
const backpressureGuard = async (_req: Request, res: Response, next: NextFunction) => {
  const ema = parseFloat((await redis.get('vitalos:metrics:ema_load')) || '0');
  if (ema > 0.85) {
    logger.warn('APIGateway', 'Backpressure triggered', { ema });
    return res.status(429).json({ error: 'SYSTEM_SATURATION', message: 'System under high load. Please retry shortly.', retry_after_ms: 5000 });
  }
  next();
};

// ── 5. Trace ID injection ─────────────────────────────────────
const traceInjector = (req: Request, res: Response, next: NextFunction) => {
  const traceId = (req.headers['x-trace-id'] as string) || `vos-${uuidv4()}`;
  req.headers['x-trace-id'] = traceId;
  res.setHeader('x-trace-id', traceId);
  next();
};

// ── 6. Rate Limiters by role ──────────────────────────────────
const standardLimiter = rateLimit({ windowMs: 60_000, max: 60,  message: { error: 'RATE_LIMIT_EXCEEDED' } });
const aiLimiter       = rateLimit({ windowMs: 60_000, max: 20,  message: { error: 'AI_RATE_LIMIT_EXCEEDED' } });
const emergencyLimiter = rateLimit({ windowMs: 60_000, max: 200, message: { error: 'EMERGENCY_RATE_LIMIT' } });

// Apply middleware
app.use(traceInjector);
app.use(safeModeGuard);
app.use(backpressureGuard);

// ── Health (unauthenticated) ──────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({ status: 'healthy', service: 'vitalos-api-gateway', version: '1.0.0', schema_version: EVENT_SCHEMA_VERSION });
});

// ── Create a new clinical case ────────────────────────────────
app.post('/v1/cases',
  authenticate,
  standardLimiter,
  async (req: Request & { user?: AuthUser }, res: Response) => {
    const traceId = req.headers['x-trace-id'] as string;
    const caseId = uuidv4();
    const seqNumber = 1;

    const event: VitalOSEvent = {
      header: {
        event_id: uuidv4(),
        trace_id: traceId,
        sequence_number: seqNumber,
        idempotency_key: createHash('sha256').update(`${caseId}:${seqNumber}:api-gateway`).digest('hex'),
        timestamp: Date.now(),
        origin: 'api-gateway',
        schema_version: EVENT_SCHEMA_VERSION,
        agent_version: AGENT_VERSION,
      },
      payload: {
        case_id: caseId,
        suggested_state: 'TRIAGE_PENDING',
        confidence_score: 1.0,
        risk_level: req.body.risk_level || 'LOW',
        data: req.body,
        inference_trace: 'case_creation',
      },
      priority: req.body.risk_level === 'EMERGENCY' ? 10 : 3,
    };

    await publishEvent('vitalos.case.events', caseId, event);
    logger.info('APIGateway', 'Case created and published to Kafka', { trace_id: traceId, case_id: caseId });

    res.status(202).json({ trace_id: traceId, case_id: caseId, status: 'ACCEPTED_FOR_TRIAGE', schema_version: EVENT_SCHEMA_VERSION });
  }
);

// ── Agent proxy (Gateway → Python inference → validate response) ─
app.post('/v1/cases/:caseId/agent/:agentKey',
  authenticate,
  aiLimiter,
  async (req: Request & { user?: AuthUser }, res: Response) => {
    const traceId = req.headers['x-trace-id'] as string;
    const { caseId, agentKey } = req.params;

    // Proxy to Python AI agents service
    const agentRes = await fetch(`${PYTHON_AGENTS_URL}/api/v1/${agentKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-trace-id': traceId, 'x-case-id': caseId },
      body: JSON.stringify(req.body),
    });

    if (!agentRes.ok) {
      return res.status(agentRes.status).json({ error: 'AGENT_SERVICE_ERROR', trace_id: traceId });
    }

    const agentResult = await agentRes.json();
    logger.info('APIGateway', 'Agent inference received', { trace_id: traceId, case_id: caseId, agent: agentKey });
    res.json({ ...agentResult, trace_id: traceId });
  }
);

// ── Emergency route (higher limits, bypass most guards) ──────
app.post('/v1/emergency',
  authenticate,
  emergencyLimiter,
  async (req: Request & { user?: AuthUser }, res: Response) => {
    const traceId = req.headers['x-trace-id'] as string;
    const agentRes = await fetch(`${PYTHON_AGENTS_URL}/api/v1/emergency/triage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-trace-id': traceId, 'x-clinical-priority': 'true' },
      body: JSON.stringify(req.body),
    });
    const result = await agentRes.json();
    res.json({ ...result, trace_id: traceId });
  }
);

// ── Admin: system mode control ────────────────────────────────
app.post('/v1/admin/mode',
  authenticate,
  requireRole('admin'),
  async (req: Request, res: Response) => {
    const { mode } = req.body;
    if (!['NORMAL', 'DEGRADED', 'SAFE_MODE'].includes(mode)) {
      return res.status(400).json({ error: 'INVALID_MODE' });
    }
    await redis.set('vitalos:system_mode', mode);
    logger.audit('APIGateway', 'System mode changed by admin', { mode, user: (req as any).user?.user_id });
    res.json({ mode, changed_at: new Date().toISOString() });
  }
);

// ── Start ─────────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT || '3000');

async function start(): Promise<void> {
  await initKafka();
  app.listen(PORT, () => {
    logger.info('APIGateway', `VitalOS API Gateway listening`, { port: PORT });
  });
}

start().catch(err => {
  logger.error('APIGateway', 'Fatal startup error', { error: String(err) });
  process.exit(1);
});
