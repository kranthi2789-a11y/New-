/**
 * VitalOS Forensic Audit Verifier
 *
 * Run on-demand or scheduled:  npx ts-node scripts/audit-verifier.ts
 *
 * Checks per case:
 *   1. Link integrity   — previous_hash chain is unbroken
 *   2. Content integrity — SHA-256 recompute matches stored hash
 *   3. Semantic drift   — last audit payload matches DB current_state
 *
 * On tampering detected: case is auto-locked and alert published to Kafka.
 */

import { Pool } from 'pg';
import { verifyAuditRecord, ROOT_GENESIS } from '../libs/audit/hash';
import { initKafka, publishEvent } from '../libs/events/kafka';
import { logger } from '../libs/common/logger';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function verifyCase(caseId: string): Promise<{ ok: boolean; errors: string[] }> {
  const errors: string[] = [];

  const auditRows = await pool.query(
    'SELECT id, record_hash, previous_hash, payload, sequence_id FROM global_audit_trail WHERE case_id = $1 ORDER BY sequence_id ASC',
    [caseId]
  );

  const stateRow = await pool.query(
    'SELECT current_state, last_audit_id FROM case_state_machine WHERE case_id = $1',
    [caseId]
  );

  if (auditRows.rowCount === 0) {
    return { ok: true, errors: [] }; // No audit records yet — newly created case
  }

  let expectedPrevHash = ROOT_GENESIS;

  for (const record of auditRows.rows) {
    // Check 1: Link integrity
    if (record.previous_hash !== expectedPrevHash) {
      errors.push(`CHAIN_BREAK at seq ${record.sequence_id}: expected previous_hash ${expectedPrevHash.substring(0, 16)}... got ${record.previous_hash?.substring(0, 16)}...`);
    }

    // Check 2: Content integrity
    const valid = verifyAuditRecord(record);
    if (!valid) {
      errors.push(`HASH_MISMATCH at seq ${record.sequence_id}: stored ${record.record_hash.substring(0, 16)}... is incorrect`);
    }

    expectedPrevHash = record.record_hash;
  }

  // Check 3: Semantic drift
  const lastAudit = auditRows.rows[auditRows.rows.length - 1];
  const state = stateRow.rows[0];

  if (lastAudit.id !== state.last_audit_id) {
    errors.push(`POINTER_DRIFT: case last_audit_id=${state.last_audit_id} but last audit record id=${lastAudit.id}`);
  }

  if (lastAudit.payload?.target_state !== state.current_state) {
    errors.push(`SEMANTIC_DRIFT: case current_state=${state.current_state} but last audit target_state=${lastAudit.payload?.target_state}`);
  }

  return { ok: errors.length === 0, errors };
}

async function runVerifier(): Promise<void> {
  await initKafka();
  const cases = await pool.query('SELECT case_id FROM case_state_machine WHERE is_locked = FALSE');
  const total = cases.rowCount || 0;
  let passed = 0;
  let failed = 0;

  logger.info('AuditVerifier', `Starting forensic verification of ${total} cases`);

  for (const c of cases.rows) {
    const { ok, errors } = await verifyCase(c.case_id);
    if (ok) {
      passed++;
    } else {
      failed++;
      logger.error('AuditVerifier', `TAMPERING DETECTED — case ${c.case_id}`, { errors });

      // Lock the case
      await pool.query('UPDATE case_state_machine SET is_locked = TRUE WHERE case_id = $1', [c.case_id]);

      // Alert via Kafka
      await publishEvent('vitalos.audit.tamper_alert', c.case_id, {
        case_id: c.case_id,
        errors,
        locked_at: new Date().toISOString(),
        verified_by: 'audit-verifier',
      });
    }
  }

  logger.info('AuditVerifier', `Verification complete`, { total, passed, failed });
  if (failed > 0) {
    logger.error('AuditVerifier', `${failed} case(s) had integrity violations and were locked`);
    process.exit(1);
  }

  process.exit(0);
}

runVerifier().catch(e => {
  logger.error('AuditVerifier', 'Fatal error', { error: String(e) });
  process.exit(1);
});
