/**
 * VitalOS Chaos Simulator
 *
 * Run: npx ts-node scripts/chaos-simulator.ts
 *
 * Scenarios:
 *   1. Out-of-order delivery (seq 3 arrives before seq 2)
 *   2. Message loss (random 10% drop)
 *   3. Duplicate delivery (same event twice)
 *   4. Schema version mismatch (should be rejected by Orchestrator)
 */

import { initKafka, publishEvent, shutdownKafka } from '../libs/events/kafka';
import { VitalOSEvent, EVENT_SCHEMA_VERSION, AGENT_VERSION } from '../libs/common/types';
import { v4 as uuidv4 } from 'uuid';
import { createHash } from 'crypto';
import { logger } from '../libs/common/logger';

function makeEvent(caseId: string, seq: number, state: string, traceId: string): VitalOSEvent {
  return {
    header: {
      event_id: uuidv4(),
      trace_id: traceId,
      sequence_number: seq,
      idempotency_key: createHash('sha256').update(`${caseId}:${seq}:chaos`).digest('hex'),
      timestamp: Date.now(),
      origin: 'chaos-simulator',
      schema_version: EVENT_SCHEMA_VERSION,
      agent_version: AGENT_VERSION,
    },
    payload: {
      case_id: caseId,
      suggested_state: state as any,
      confidence_score: 0.95,
      risk_level: 'HIGH',
      data: { test: true },
      inference_trace: `chaos:seq${seq}`,
    },
    priority: 5,
  };
}

async function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

async function runChaos(): Promise<void> {
  await initKafka();
  const caseId = `chaos-${uuidv4()}`;
  const traceId = `chaos-trace-${uuidv4()}`;

  logger.info('Chaos', `Starting chaos run`, { case_id: caseId });

  // Scenario 1: Out-of-order — seq 3 before seq 2
  const events = [
    makeEvent(caseId, 1, 'TRIAGE_PENDING', traceId),
    makeEvent(caseId, 3, 'ROUTING_PENDING', traceId),   // Arrives first — should be buffered
    makeEvent(caseId, 2, 'TRIAGE_COMPLETED', traceId),  // Delayed — should trigger replay
  ];

  for (const event of events) {
    if (Math.random() < 0.1) {
      logger.warn('Chaos', `Dropping event (simulated loss)`, { seq: event.header.sequence_number });
      continue;
    }
    await publishEvent('vitalos.case.events', caseId, event);
    logger.info('Chaos', `Published event`, { seq: event.header.sequence_number, state: event.payload.suggested_state });
    await sleep(Math.random() * 800 + 200);
  }

  // Scenario 2: Duplicate delivery (idempotency test)
  logger.info('Chaos', 'Sending duplicate of seq 1 (idempotency test)');
  await publishEvent('vitalos.case.events', caseId, events[0]);

  // Scenario 3: Bad schema version
  const badEvent = { ...events[0], header: { ...events[0].header, schema_version: '99.9.9', event_id: uuidv4() } };
  logger.info('Chaos', 'Sending bad schema version event (should be rejected)');
  await publishEvent('vitalos.case.events', caseId, badEvent);

  logger.info('Chaos', 'Chaos run complete', { case_id: caseId });
  await sleep(2000);
  await shutdownKafka();
  process.exit(0);
}

runChaos().catch(e => {
  logger.error('Chaos', 'Fatal error', { error: String(e) });
  process.exit(1);
});
