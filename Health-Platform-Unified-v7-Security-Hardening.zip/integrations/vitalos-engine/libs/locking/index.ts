/**
 * VitalOS Distributed Striped Lock
 * - 1024-stripe hashing for parallelism
 * - Lua script prevents "stolen lock" bugs
 * - Heartbeat auto-renew prevents TTL expiry under load
 * - Shared subscriber for preemption signals
 * - Priority preemption: higher priority cases can steal lock
 */

import { Redis } from 'ioredis';
import { v4 as uuidv4 } from 'uuid';
import { logger } from '../common/logger';

// One shared subscriber per process (avoids per-acquire connection storms)
let _sharedSub: Redis | null = null;

function getSharedSub(url: string): Redis {
  if (!_sharedSub) {
    _sharedSub = new Redis(url, { lazyConnect: false });
    _sharedSub.on('error', (e) => logger.error('StripedLock:sub', 'Redis sub error', { error: String(e) }));
  }
  return _sharedSub;
}

export class StripedLock {
  private redis: Redis;
  private heartbeats: Map<string, NodeJS.Timeout> = new Map();

  // Lua: validate token ownership before delete — prevents race condition
  private readonly releaseScript = `
    local val = redis.call("get", KEYS[1])
    if not val then return 0 end
    local ok, data = pcall(cjson.decode, val)
    if not ok then return 0 end
    if data.token == ARGV[1] then
      return redis.call("del", KEYS[1])
    else
      return 0
    end
  `;

  // Lua: atomic heartbeat renewal — only the token owner can renew
  private readonly renewScript = `
    local val = redis.call("get", KEYS[1])
    if not val then return 0 end
    local ok, data = pcall(cjson.decode, val)
    if not ok then return 0 end
    if data.token == ARGV[1] then
      return redis.call("pexpire", KEYS[1], ARGV[2])
    else
      return 0
    end
  `;

  constructor(private readonly redisUrl: string) {
    this.redis = new Redis(redisUrl, { lazyConnect: false });
    this.redis.on('error', (e) => logger.error('StripedLock', 'Redis error', { error: String(e) }));
  }

  /** Deterministic stripe key — same case always maps to same stripe */
  private getLockKey(caseId: string): string {
    let hash = 0;
    for (let i = 0; i < caseId.length; i++) {
      hash = (hash << 5) - hash + caseId.charCodeAt(i);
      hash |= 0;
    }
    return `vitalos:lock:stripe:${Math.abs(hash) % 1024}`;
  }

  /**
   * Acquire lock for caseId.
   * - Returns token string on success
   * - Returns null if lock is held by equal/higher priority
   * - Starts heartbeat to auto-renew TTL
   */
  async acquire(caseId: string, priority: number, ttlMs = 30_000): Promise<string | null> {
    const key = this.getLockKey(caseId);
    const token = uuidv4();

    // Check if existing lock can be preempted
    const existing = await this.redis.get(key);
    if (existing) {
      try {
        const data = JSON.parse(existing);
        if (data.priority >= priority) {
          logger.debug('StripedLock', 'Lock not acquired — lower priority', { caseId, existing_priority: data.priority, our_priority: priority });
          return null;
        }
        // Preempt lower-priority lock
        await this.redis.publish(`vitalos:lock:interrupt:${caseId}`, JSON.stringify({ reason: 'PREEMPTED', by_priority: priority, timestamp: Date.now() }));
        await new Promise(r => setTimeout(r, 600)); // Grace period for preempted worker to checkpoint
        await this.redis.del(key);
        logger.warn('StripedLock', 'Preempted existing lock', { caseId, old_priority: data.priority, new_priority: priority });
      } catch {
        return null;
      }
    }

    const value = JSON.stringify({ token, priority, caseId, acquired_at: Date.now() });
    const ok = await this.redis.set(key, value, 'PX', ttlMs, 'NX');

    if (!ok) return null;

    // Start heartbeat — renew at half TTL interval
    const interval = setInterval(async () => {
      const renewed = await this.redis.eval(this.renewScript, 1, key, token, String(ttlMs));
      if (!renewed) {
        logger.warn('StripedLock', 'Heartbeat renewal failed — lock lost', { caseId, token });
        clearInterval(interval);
        this.heartbeats.delete(token);
      }
    }, Math.floor(ttlMs / 2));

    this.heartbeats.set(token, interval);
    logger.debug('StripedLock', 'Lock acquired', { caseId, token, priority });
    return token;
  }

  /** Release lock — Lua script validates ownership */
  async release(caseId: string, token: string): Promise<void> {
    const key = this.getLockKey(caseId);
    const result = await this.redis.eval(this.releaseScript, 1, key, token);

    const interval = this.heartbeats.get(token);
    if (interval) {
      clearInterval(interval);
      this.heartbeats.delete(token);
    }

    if (result === 0) {
      logger.warn('StripedLock', 'Release called for non-owned lock (already expired or stolen)', { caseId, token });
    } else {
      logger.debug('StripedLock', 'Lock released', { caseId, token });
    }
  }

  /** Subscribe to preemption signals (called by long-running workers) */
  subscribeToInterrupts(caseId: string, onInterrupt: () => void): void {
    const sub = getSharedSub(this.redisUrl);
    const channel = `vitalos:lock:interrupt:${caseId}`;
    sub.subscribe(channel).catch(() => {});
    sub.on('message', (ch: string, msg: string) => {
      if (ch === channel) {
        logger.warn('StripedLock', 'Interrupt signal received', { caseId, msg });
        setTimeout(onInterrupt, 500); // Grace period
      }
    });
  }
}
