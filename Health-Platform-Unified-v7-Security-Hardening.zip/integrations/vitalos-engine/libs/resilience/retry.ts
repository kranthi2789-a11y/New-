/**
 * VitalOS Resilience — Jittered Retry Utility
 *
 * Used by Orchestrator for deadlock/serialization failure retries.
 * Full exponential backoff with random jitter to avoid thundering herd.
 */

export interface RetryOptions {
  maxAttempts: number;
  baseDelayMs: number;
  maxDelayMs: number;
  jitterFactor: number; // 0.0–1.0
  retryableErrors?: string[]; // postgres codes e.g. ['40001','40P01']
}

export const DEADLOCK_RETRY: RetryOptions = {
  maxAttempts: 3,
  baseDelayMs: 50,
  maxDelayMs: 500,
  jitterFactor: 0.5,
  retryableErrors: ['40001', '40P01'], // serialization failure + deadlock
};

export const LOCK_RETRY: RetryOptions = {
  maxAttempts: 5,
  baseDelayMs: 100,
  maxDelayMs: 1000,
  jitterFactor: 0.4,
};

/**
 * Compute jittered delay for attempt N (0-indexed).
 * Formula: min(base * 2^attempt, maxDelay) ± jitter
 */
export function computeDelay(attempt: number, opts: RetryOptions): number {
  const exponential = Math.min(
    opts.baseDelayMs * Math.pow(2, attempt),
    opts.maxDelayMs
  );
  const jitter = exponential * opts.jitterFactor * (Math.random() - 0.5) * 2;
  return Math.max(0, Math.round(exponential + jitter));
}

/**
 * Sleep for ms milliseconds.
 */
export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Is this error retryable given the options?
 */
export function isRetryable(err: any, opts: RetryOptions): boolean {
  if (!opts.retryableErrors || opts.retryableErrors.length === 0) return true;
  return opts.retryableErrors.includes(err?.code ?? '');
}

/**
 * Execute fn with automatic jittered retry.
 * Throws the last error if all attempts exhausted.
 *
 * @example
 * await withRetry(() => pool.query(...), DEADLOCK_RETRY, logger);
 */
export async function withRetry<T>(
  fn: () => Promise<T>,
  opts: RetryOptions,
  log?: { warn: (ctx: string, msg: string, meta?: any) => void }
): Promise<T> {
  let lastError: any;

  for (let attempt = 0; attempt < opts.maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (err: any) {
      lastError = err;

      if (!isRetryable(err, opts) || attempt === opts.maxAttempts - 1) {
        throw err;
      }

      const delay = computeDelay(attempt, opts);
      log?.warn('Retry', `Retryable error — attempt ${attempt + 1}/${opts.maxAttempts}`, {
        error_code: err?.code,
        error_msg: err?.message?.substring(0, 80),
        retry_in_ms: delay,
      });

      await sleep(delay);
    }
  }

  throw lastError;
}
