/**
 * VitalOS Audit Hash Utilities
 * - Deterministic SHA-256 chaining via json-stable-stringify
 * - ROOT_GENESIS is the canonical first-block sentinel
 */

import { createHash } from 'crypto';
import stringify from 'json-stable-stringify';

export const ROOT_GENESIS = 'VITALOS_ROOT_GENESIS_V1';

/**
 * Compute the next hash in the audit chain.
 * @param prevHash - Previous record's hash (or ROOT_GENESIS for first)
 * @param payload  - The payload being committed (will be stringified deterministically)
 */
export function computeAuditHash(prevHash: string, payload: unknown): string {
  return createHash('sha256')
    .update(prevHash + stringify(payload))
    .digest('hex');
}

/**
 * Verify a single audit record's hash integrity.
 */
export function verifyAuditRecord(record: {
  record_hash: string;
  previous_hash: string;
  payload: unknown;
}): boolean {
  const expected = computeAuditHash(record.previous_hash, record.payload);
  return expected === record.record_hash;
}
