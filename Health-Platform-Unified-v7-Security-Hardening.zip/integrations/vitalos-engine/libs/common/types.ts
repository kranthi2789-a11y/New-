/**
 * VitalOS Shared Event Contract v1.0
 * THE single source of truth for all events flowing between:
 *   API Gateway → Kafka → Orchestrator → Python Agents → Orchestrator
 *
 * Never break this contract without bumping EVENT_SCHEMA_VERSION.
 */

export const EVENT_SCHEMA_VERSION = '1.0.0';
export const AGENT_VERSION = '1.0.0';

// ── Clinical State Machine States ──────────────────────────────
export type ClinicalState =
  | 'CREATED'
  | 'TRIAGE_PENDING'
  | 'TRIAGE_COMPLETED'
  | 'DOCTOR_REVIEW_PENDING'
  | 'ROUTING_PENDING'
  | 'CLOSED'
  | 'ESCALATED';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'EMERGENCY';
export type SystemMode = 'NORMAL' | 'DEGRADED' | 'SAFE_MODE';

// ── Core Event Contract ────────────────────────────────────────
export interface VitalOSEventHeader {
  event_id: string;          // UUID v4 — globally unique
  trace_id: string;          // Propagated from API Gateway through to audit
  sequence_number: number;   // Monotonically increasing per case
  idempotency_key: string;   // SHA256(case_id + sequence_number + origin)
  timestamp: number;         // Unix epoch ms
  origin: string;            // 'api-gateway' | 'agent:triage' | 'system:gap-escalation'
  schema_version: string;    // Must match EVENT_SCHEMA_VERSION
  agent_version: string;     // Must match AGENT_VERSION
}

export interface VitalOSEventPayload {
  case_id: string;
  suggested_state: ClinicalState;
  confidence_score: number;   // 0.0 – 1.0; system transitions use 1.0
  risk_level: RiskLevel;
  data: Record<string, unknown>;
  inference_trace?: string;   // Debug: which agent path produced this
}

export interface VitalOSEvent {
  header: VitalOSEventHeader;
  payload: VitalOSEventPayload;
  priority: number;           // 1 (low) – 10 (EMERGENCY preemption)
}

// ── Agent Inference Response (Python → TS Orchestrator) ──────
export interface AgentInferenceResponse {
  case_id: string;
  suggested_state: ClinicalState;
  confidence_score: number;
  risk_level: RiskLevel;
  metadata: Record<string, unknown>;
  trace_id: string;
  agent_version: string;
  schema_version: string;
  inference_trace: string;
}

// ── Governance ────────────────────────────────────────────────
export interface GovernanceTrigger {
  action: 'ENABLE_SAFE_MODE' | 'DISABLE_SAFE_MODE' | 'ENABLE_DEGRADED';
  reason: string;
  timestamp: number;
  schema_version: string;
}

// ── Allowed state transitions (mirrors DB) ───────────────────
export const VALID_TRANSITIONS: Record<ClinicalState, ClinicalState[]> = {
  CREATED:               ['TRIAGE_PENDING', 'ESCALATED'],
  TRIAGE_PENDING:        ['TRIAGE_COMPLETED', 'ESCALATED'],
  TRIAGE_COMPLETED:      ['DOCTOR_REVIEW_PENDING', 'ROUTING_PENDING'],
  DOCTOR_REVIEW_PENDING: ['ROUTING_PENDING', 'ESCALATED'],
  ROUTING_PENDING:       ['CLOSED', 'ESCALATED'],
  CLOSED:                [],
  ESCALATED:             [],
};
