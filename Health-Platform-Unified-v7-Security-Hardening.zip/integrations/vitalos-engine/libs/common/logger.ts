/**
 * VitalOS Structured Logger
 * Propagates trace_id, case_id, sequence across the full stack.
 * In production: pipe stdout to Datadog / CloudWatch / GCP Logging.
 */

export type LogLevel = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR' | 'AUDIT';

export interface LogMeta {
  trace_id?: string;
  case_id?: string;
  sequence_number?: number;
  agent?: string;
  duration_ms?: number;
  [key: string]: unknown;
}

const log = (level: LogLevel, context: string, message: string, meta: LogMeta = {}) => {
  const entry = {
    timestamp: new Date().toISOString(),
    level,
    context,
    message,
    ...meta,
    env: process.env.NODE_ENV || 'development',
  };
  if (level === 'ERROR') {
    process.stderr.write(JSON.stringify(entry) + '\n');
  } else {
    process.stdout.write(JSON.stringify(entry) + '\n');
  }
};

export const logger = {
  debug: (ctx: string, msg: string, meta?: LogMeta) => log('DEBUG', ctx, msg, meta),
  info:  (ctx: string, msg: string, meta?: LogMeta) => log('INFO',  ctx, msg, meta),
  warn:  (ctx: string, msg: string, meta?: LogMeta) => log('WARN',  ctx, msg, meta),
  error: (ctx: string, msg: string, meta?: LogMeta) => log('ERROR', ctx, msg, meta),
  audit: (ctx: string, msg: string, meta?: LogMeta) => log('AUDIT', ctx, msg, meta),
};
