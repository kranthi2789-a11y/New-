/**
 * VitalOS Kafka — Singleton idempotent producer
 * - transactionalId ensures exactly-once semantics
 * - maxInFlightRequestsPerConnection=1 for strict ordering
 * - Call initKafka() once at startup; import producer everywhere else
 */

import { Kafka, Producer, CompressionTypes } from 'kafkajs';
import { logger } from '../common/logger';

const kafka = new Kafka({
  clientId: 'vitalos-core',
  brokers: (process.env.KAFKA_BROKERS || 'localhost:9092').split(','),
  retry: {
    initialRetryTime: 100,
    retries: 8,
  },
});

export const producer: Producer = kafka.producer({
  allowAutoTopicCreation: true,
  idempotent: true,
  acks: -1,          // all replicas must confirm (required when idempotent=true)
  transactionalId: 'vitalos-orchestrator-producer',
  maxInFlightRequests: 1,
});

let _initialized = false;

export async function initKafka(): Promise<void> {
  if (_initialized) return;
  await producer.connect();
  _initialized = true;
  logger.info('Kafka', 'Producer connected and ready');
}

export async function shutdownKafka(): Promise<void> {
  if (!_initialized) return;
  await producer.disconnect();
  _initialized = false;
  logger.info('Kafka', 'Producer disconnected');
}

// Convenience: send a typed VitalOS event
export async function publishEvent(topic: string, key: string, value: unknown): Promise<void> {
  await producer.send({
    topic,
    messages: [{ key, value: JSON.stringify(value), headers: { 'schema-version': '1.0.0' } }],
    compression: CompressionTypes.GZIP,
  });
}

export { kafka };
