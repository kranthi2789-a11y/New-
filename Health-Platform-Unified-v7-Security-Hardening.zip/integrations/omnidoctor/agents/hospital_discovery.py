"""
agents/hospital_discovery.py — Hospital Discovery Agent
"""
from agents.base import BaseAgent

class HospitalDiscoveryAgent(BaseAgent):
    description = "Find nearby hospitals and doctors by specialty with insurance compatibility"
    category = "clinical"

    async def run(self, symptoms: str, location: str = "Hyderabad",
                  insurance: str = None, specialty: str = None) -> dict:
        ins_note = f"Insurance: {insurance}" if insurance else "No insurance specified"
        spec_note = f"Required specialty: {specialty}" if specialty else "Determine from symptoms"

        response = self._call_claude(
            system_prompt="""You are a hospital discovery assistant for India.
Given symptoms and location, recommend appropriate hospitals and specialists.

Output JSON:
{
  "recommended_specialty": "string",
  "urgency": "routine|soon|urgent|emergency",
  "hospitals": [
    {
      "name": "string",
      "type": "government|private|charitable",
      "specialty_available": "boolean",
      "estimated_cost_range": "string",
      "insurance_accepted": ["list"],
      "contact": "string",
      "notes": "string"
    }
  ],
  "government_options": ["free/low-cost government hospitals"],
  "telemedicine_option": "string or null",
  "emergency_action": "string or null"
}
Return ONLY JSON.""",
            user_message=f"Location: {location}\nSymptoms: {symptoms}\n{ins_note}\n{spec_note}",
            use_rag=True, rag_query=f"hospital {symptoms} India"
        )
        import json, re
        text = re.sub(r"```(?:json)?\n?", "", response).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except Exception:
            return {"response": response}
