"""
agents/lab_interpreter.py — Parse lab reports and explain results in plain language
"""

import json
import re
from typing import Optional
from agents.base import BaseAgent

SYSTEM_PROMPT = """You are a clinical pathologist AI for Indian patients. Parse lab reports and explain results clearly.

Output ONLY valid JSON:
{
  "report_type": "string (CBC/LFT/KFT/Lipid Panel/Thyroid/HbA1c/Urine/etc.)",
  "lab_name": "string or null",
  "report_date": "string or null",
  "patient_summary": "2-3 sentence plain language summary for patient",
  "values": [
    {
      "test_name": "string",
      "value": "string",
      "unit": "string",
      "reference_range": "string",
      "status": "normal|low|high|critical_low|critical_high",
      "plain_explanation": "1-2 sentences in simple language what this means",
      "action_needed": "none|monitor|consult_doctor|urgent"
    }
  ],
  "flags": ["list of concerning findings"],
  "recommendations": ["list of actionable recommendations"],
  "follow_up_urgency": "routine|soon|urgent|emergency",
  "doctor_speciality_needed": "string or null",
  "lifestyle_tips": ["India-specific dietary and lifestyle advice based on results"]
}

Context for Indian patients:
- Mention specific Indian foods: avoid maida, fried foods; eat ragi, jowar, millets for diabetes
- Reference costs: "Generic atorvastatin at Jan Aushadhi is ₹10 for 10 tablets"
- Mention free services where relevant: PMJAY, e-Sanjeevani, CGHS
- Use simple terms: "blood sugar" not "glucose", "thyroid gland" not "TSH"
- For women: consider iron deficiency anemia common in India
Return ONLY JSON, no other text."""


class LabInterpreterAgent(BaseAgent):
    description = "Parse and explain lab reports with India-specific clinical context"
    category = "clinical"

    async def run(
        self,
        lab_text: str,
        patient_age: Optional[int] = None,
        patient_gender: str = "unknown",
        patient_conditions: Optional[list] = None,
        image_base64: Optional[str] = None,
    ) -> dict:
        """
        Interpret a lab report from text or image.

        Args:
            lab_text: Raw text from lab report (from OCR or manual entry)
            patient_age: Patient age for age-specific reference ranges
            patient_gender: 'male', 'female', 'unknown'
            patient_conditions: Existing conditions for context
            image_base64: Optional base64 image for vision-based parsing

        Returns:
            Structured dict with values, flags, recommendations
        """

        profile = f"Age: {patient_age or 'unknown'}, Gender: {patient_gender}"
        if patient_conditions:
            profile += f", Conditions: {', '.join(patient_conditions)}"

        if image_base64:
            # Use vision capability for image reports
            response = self._call_claude_vision(
                system_prompt=SYSTEM_PROMPT,
                user_text=f"Patient profile: {profile}\n\nParse this lab report image:",
                image_base64=image_base64,
            )
        else:
            response = self._call_claude(
                system_prompt=SYSTEM_PROMPT,
                user_message=f"Patient profile: {profile}\n\nLAB REPORT:\n{lab_text}",
                use_rag=True,
                rag_query=lab_text,
            )

        parsed = self._safe_json_parse(response)
        return parsed or {"error": "Could not parse lab report", "raw": response}

    def _call_claude_vision(
        self,
        system_prompt: str,
        user_text: str,
        image_base64: str,
    ) -> str:
        """Call Claude with vision for image-based lab reports."""
        from agents.base import get_client
        from core.rag import retrieve_medical_context

        client = get_client()
        context = retrieve_medical_context(user_text)
        full_system = f"{system_prompt}\n\n<medical_context>\n{context}\n</medical_context>"

        # Detect image type
        media_type = "image/jpeg"
        if image_base64.startswith("data:image/png"):
            media_type = "image/png"
            image_base64 = image_base64.split(",", 1)[-1]
        elif image_base64.startswith("data:"):
            image_base64 = image_base64.split(",", 1)[-1]

        response = client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            system=full_system,
            messages=[{
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": media_type,
                            "data": image_base64,
                        },
                    },
                    {"type": "text", "text": user_text},
                ],
            }],
        )
        return response.content[0].text

    @staticmethod
    def _safe_json_parse(text: str) -> Optional[dict]:
        text = re.sub(r"```(?:json)?\n?", "", text).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group())
                except Exception:
                    pass
        return None
