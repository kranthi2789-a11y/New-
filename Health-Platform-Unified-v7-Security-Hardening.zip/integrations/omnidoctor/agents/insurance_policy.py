"""
agents/insurance_policy.py — Insurance coverage analysis and claim guidance for Indian patients
"""

import json, re
from typing import Optional
from agents.base import BaseAgent

SYSTEM_PROMPT = """You are an Indian health insurance expert helping patients understand their coverage.

You know:
- Ayushman Bharat PM-JAY (₹5L coverage, government scheme)
- Star Health, HDFC Ergo, Niva Bupa, Max Bupa, Care Health, New India Assurance
- CGHS rates and empaneled hospitals
- ESI (Employee State Insurance) scheme
- TPA processes, pre-authorization, cashless claims, reimbursement

Output ONLY valid JSON:
{
  "policy_summary": "string — plain language explanation of the policy",
  "coverage_for_procedure": {
    "covered": "boolean",
    "coverage_percentage": "number (0-100) or null",
    "max_amount": "string or null",
    "pre_auth_required": "boolean",
    "waiting_period_days": "number or null",
    "sub_limits": "string or null"
  },
  "pre_auth_steps": ["step 1", "step 2", ...],
  "documents_required": ["list of documents"],
  "claim_tips": ["actionable tips for smooth claim processing"],
  "alternative_options": [
    {
      "option": "string (e.g., PM-JAY, Jan Aushadhi)",
      "benefit": "string",
      "eligibility": "string"
    }
  ],
  "cost_estimate": {
    "insured_amount": "string",
    "patient_liability": "string",
    "co_pay_percentage": "number or null"
  },
  "important_exclusions": ["list of relevant exclusions"],
  "helpline_numbers": ["TPA helpline", "Insurance company number"]
}

Always mention:
- PM-JAY if procedure cost > ₹1 lakh and patient may be eligible
- Jan Aushadhi for generic medicines
- e-Sanjeevani for free teleconsultation
Return ONLY JSON, no other text."""


class InsurancePolicyAgent(BaseAgent):
    description = "Insurance coverage analysis, pre-auth guidance, and claim tips for Indian patients"
    category = "patient"

    async def run(
        self,
        policy_details: str,
        procedure: str,
        hospital_type: str = "private",
        patient_income_category: Optional[str] = None,
        estimated_cost: Optional[str] = None,
    ) -> dict:
        """
        Analyze insurance coverage for a specific procedure.

        Args:
            policy_details: Text description or extracted text from policy document
            procedure: The medical procedure or treatment needed
            hospital_type: 'private', 'government', 'empaneled'
            patient_income_category: 'BPL', 'EWS', 'general', etc. for PM-JAY eligibility
            estimated_cost: Estimated cost of procedure

        Returns:
            Coverage analysis, pre-auth steps, claim tips
        """

        income_note = f"\nPatient income category: {patient_income_category}" if patient_income_category else ""
        cost_note = f"\nEstimated procedure cost: {estimated_cost}" if estimated_cost else ""

        user_message = f"""Analyze insurance coverage:{income_note}{cost_note}

POLICY DETAILS:
{policy_details}

REQUESTED PROCEDURE: {procedure}
HOSPITAL TYPE: {hospital_type}

Provide coverage analysis, pre-authorization steps, and practical claim guidance."""

        response = self._call_claude(
            system_prompt=SYSTEM_PROMPT,
            user_message=user_message,
            use_rag=True,
            rag_query=f"insurance coverage {procedure} India",
        )

        parsed = self._safe_json_parse(response)
        return parsed or {"error": "Could not analyze insurance", "raw": response}

    @staticmethod
    def _safe_json_parse(text: str) -> Optional[dict]:
        text = re.sub(r"```(?:json)?\n?", "", text).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group())
                except Exception:
                    pass
        return None
