"""
agents/family_health.py — Family Health Agent
"""
from agents.base import BaseAgent

class FamilyHealthAgent(BaseAgent):
    description = "Unified family health management — members, shared records, family risk assessment"
    category = "patient"

    async def run(self, family_members: list, query: str) -> dict:
        members_text = str(family_members)
        response = self._call_claude(
            system_prompt="""You are a family health advisor for Indian families.
Provide holistic health guidance considering all family members.

Output JSON:
{
  "family_summary": "string",
  "individual_alerts": [{"member": "string", "alert": "string", "priority": "string"}],
  "shared_risk_factors": ["genetic or environmental risks"],
  "family_recommendations": ["actions for the whole family"],
  "vaccination_due": [{"member": "string", "vaccine": "string", "due_date": "string"}],
  "screening_calendar": [{"member": "string", "test": "string", "due": "string"}]
}
Return ONLY JSON.""",
            user_message=f"Family members:\n{members_text}\n\nQuery: {query}",
            use_rag=True, rag_query=query
        )
        import json, re
        text = re.sub(r"```(?:json)?\n?", "", response).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except Exception:
            return {"response": response}


"""
agents/cost_optimizer.py — Cost Optimization Agent
"""
from agents.base import BaseAgent as _BaseAgent

class CostOptimizerAgent(_BaseAgent):
    description = "Find generic alternatives, cheaper pharmacies, government schemes to reduce healthcare costs"
    category = "finance"

    async def run(self, medications: list = None, procedure: str = None,
                  budget: str = None, location: str = "India") -> dict:
        med_text = str(medications or [])
        response = self._call_claude(
            system_prompt="""You are a healthcare cost reduction expert for India.
Help patients find affordable alternatives without compromising quality.

Output JSON:
{
  "total_estimated_cost": "string",
  "savings_possible": "string",
  "generic_alternatives": [
    {"brand": "string", "generic": "string", "brand_cost": "string", "generic_cost": "string", "savings": "string", "where_to_buy": "string"}
  ],
  "government_schemes": [{"scheme": "string", "benefit": "string", "eligibility": "string"}],
  "jan_aushadhi_available": ["list of drugs available at Jan Aushadhi"],
  "free_government_services": ["applicable free services"],
  "practical_tips": ["cost saving tips specific to India"]
}
Return ONLY JSON.""",
            user_message=f"Medications: {med_text}\nProcedure: {procedure or 'none'}\nBudget: {budget or 'unspecified'}\nLocation: {location}",
            use_rag=True, rag_query="generic medicines Jan Aushadhi PMJAY India"
        )
        import json, re
        text = re.sub(r"```(?:json)?\n?", "", response).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except Exception:
            return {"response": response}
