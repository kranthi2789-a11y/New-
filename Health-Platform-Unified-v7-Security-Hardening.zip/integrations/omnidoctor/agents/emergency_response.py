"""
agents/emergency_response.py — Emergency Response Agent
"""
from agents.base import BaseAgent

class EmergencyResponseAgent(BaseAgent):
    description = "Emergency triage, hospital routing, ambulance guidance, and family alert"
    category = "emergency"

    async def run(self, symptoms: str, location: str = "unknown",
                  patient_profile: dict = None) -> dict:
        profile_text = str(patient_profile or {})
        response = self._call_claude(
            system_prompt="""You are an emergency medical dispatcher for India.
Assess severity and provide immediate guidance.

Output JSON:
{
  "severity": "minor|moderate|severe|life_threatening",
  "call_ambulance": "boolean",
  "ambulance_number": "108",
  "immediate_actions": ["numbered list of immediate steps"],
  "nearest_er_type": "government|private|trauma_center",
  "do_not": ["list of what NOT to do"],
  "while_waiting": ["what to do while waiting for help"],
  "patient_stable": "boolean",
  "estimated_time_sensitivity": "minutes|hours|days"
}
Always include 108 if life-threatening. Return ONLY JSON.""",
            user_message=f"EMERGENCY: {symptoms}\nLocation: {location}\nProfile: {profile_text}"
        )
        import json, re
        text = re.sub(r"```(?:json)?\n?", "", response).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except Exception:
            return {"response": response, "call_ambulance": True, "ambulance_number": "108"}
