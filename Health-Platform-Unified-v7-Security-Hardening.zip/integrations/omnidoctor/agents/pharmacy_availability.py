"""agents/pharmacy_availability.py"""
from agents.base import BaseAgent

class PharmacyAvailabilityAgent(BaseAgent):
    description = "Find nearby pharmacies with drug availability, generics, and price comparison"
    category = "patient"

    async def run(self, drugs: list, location: str = "Hyderabad") -> dict:
        response = self._call_claude(
            system_prompt="""Help Indian patients find their medications affordably.
Output JSON:
{
  "drugs_summary": [
    {
      "drug": "string",
      "availability": "available|check_locally|order_online",
      "jan_aushadhi_available": "boolean",
      "online_sources": ["PharmEasy", "1mg", "Netmeds"],
      "estimated_price_range": "string",
      "generic_available": "boolean"
    }
  ],
  "nearest_pharmacy_tips": ["string"],
  "online_delivery_note": "string",
  "jan_aushadhi_note": "string"
}
Return ONLY JSON.""",
            user_message=f"Find these drugs near {location}: {drugs}"
        )
        import json, re
        text = re.sub(r"```(?:json)?\n?", "", response).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except Exception:
            return {"response": response}


"""agents/followup_automation.py"""
from agents.base import BaseAgent as _B2

class FollowUpAutomationAgent(_B2):
    description = "Auto-generate follow-up schedules and WhatsApp check-in messages post-visit"
    category = "clinical"

    async def run(self, diagnosis: str, visit_date: str, medications: list = None,
                  patient_name: str = "Patient", doctor_name: str = "your doctor") -> dict:
        response = self._call_claude(
            system_prompt="""Generate post-visit follow-up schedule for Indian patients.
Output JSON:
{
  "followup_schedule": [
    {
      "day": "number",
      "type": "whatsapp_checkin|appointment|lab_test|medication_review",
      "message": "string (WhatsApp message to send)",
      "action_if_unwell": "string"
    }
  ],
  "red_flag_symptoms": ["symptoms requiring immediate doctor call"],
  "whatsapp_day1_message": "string",
  "whatsapp_day7_message": "string",
  "appointment_reminder_message": "string"
}
Return ONLY JSON.""",
            user_message=f"Diagnosis: {diagnosis}\nVisit date: {visit_date}\nPatient: {patient_name}\nDoctor: {doctor_name}\nMedications: {medications or []}"
        )
        import json, re
        text = re.sub(r"```(?:json)?\n?", "", response).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except Exception:
            return {"response": response}


"""agents/chronic_disease.py"""
from agents.base import BaseAgent as _B3

class ChronicDiseaseAgent(_B3):
    description = "Long-term monitoring and management guidance for diabetes, hypertension, thyroid, asthma"
    category = "clinical"

    async def run(self, condition: str, patient_data: dict, monitoring_history: list = None) -> dict:
        response = self._call_claude(
            system_prompt="""You are a chronic disease management specialist for India.
Output JSON:
{
  "condition_status": "controlled|partially_controlled|uncontrolled",
  "key_metrics": [{"metric": "string", "current": "string", "target": "string", "status": "string"}],
  "medication_adherence_alert": "boolean",
  "lifestyle_compliance": {"diet": "string", "exercise": "string", "sleep": "string"},
  "next_actions": [{"action": "string", "priority": "high|medium|low", "by_when": "string"}],
  "doctor_escalation_needed": "boolean",
  "escalation_reason": "string or null",
  "monthly_monitoring_plan": ["what to track this month"]
}
Return ONLY JSON.""",
            user_message=f"Condition: {condition}\nData: {patient_data}\nHistory: {monitoring_history or []}",
            use_rag=True, rag_query=f"{condition} monitoring management India"
        )
        import json, re
        text = re.sub(r"```(?:json)?\n?", "", response).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except Exception:
            return {"response": response}


"""agents/preventive_health.py"""
from agents.base import BaseAgent as _B4

class PreventiveHealthAgent(_B4):
    description = "Preventive care: vaccinations, screenings, lifestyle recommendations by age and risk"
    category = "patient"

    async def run(self, age: int, gender: str, conditions: list = None, location: str = "India") -> dict:
        response = self._call_claude(
            system_prompt="""You are a preventive health advisor specializing in the Indian population.
Output JSON:
{
  "age_group_summary": "string",
  "vaccines_due": [{"vaccine": "string", "dose": "string", "due": "string", "where_free": "string"}],
  "screenings_recommended": [{"test": "string", "frequency": "string", "why": "string", "cost": "string"}],
  "lifestyle_targets": [{"area": "string", "recommendation": "string", "india_specific": "boolean"}],
  "diet_recommendations": ["India-specific dietary advice"],
  "exercise_plan": "string",
  "mental_health_tips": ["string"],
  "government_schemes": ["applicable preventive health government programs"]
}
Return ONLY JSON.""",
            user_message=f"Age: {age}, Gender: {gender}, Conditions: {conditions or []}, Location: {location}",
            use_rag=True, rag_query="preventive health screening vaccination India"
        )
        import json, re
        text = re.sub(r"```(?:json)?\n?", "", response).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except Exception:
            return {"response": response}


"""agents/bill_analyzer.py"""
from agents.base import BaseAgent as _B5

class BillAnalyzerAgent(_B5):
    description = "Analyze medical bills for overcharges, CGHS rate mismatches, and generate dispute letters"
    category = "finance"

    async def run(self, bill_text: str, hospital_type: str = "private",
                  insurance_type: str = "none") -> dict:
        response = self._call_claude(
            system_prompt="""You are a medical bill auditor for India. Identify overcharges and help patients dispute unfair billing.
Output JSON:
{
  "total_billed": "string",
  "total_reasonable": "string",
  "potential_overcharge": "string",
  "bill_items": [
    {
      "item": "string",
      "charged": "string",
      "cghs_rate": "string or null",
      "reasonable": "string",
      "flag": "ok|overcharged|query",
      "note": "string"
    }
  ],
  "major_concerns": ["string"],
  "patient_rights": ["string"],
  "dispute_letter": "string (formal letter to hospital billing department)",
  "consumer_forum_info": "string",
  "health_ombudsman_info": "string"
}
Return ONLY JSON.""",
            user_message=f"Hospital type: {hospital_type}\nInsurance: {insurance_type}\n\nBILL:\n{bill_text}",
            use_rag=True, rag_query="CGHS rates medical billing India patient rights"
        )
        import json, re
        text = re.sub(r"```(?:json)?\n?", "", response).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except Exception:
            return {"response": response}
