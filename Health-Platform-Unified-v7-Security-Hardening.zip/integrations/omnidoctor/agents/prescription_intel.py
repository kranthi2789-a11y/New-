"""
agents/prescription_intel.py — Parse prescriptions (text/image) into structured medication data
"""

import json
import re
from typing import Optional
from agents.base import BaseAgent

SYSTEM_PROMPT = """You are a clinical pharmacist AI specializing in Indian prescription parsing.

Your job: Extract structured medication information from prescription text.

Output ONLY valid JSON with this exact structure:
{
  "doctor_name": "string or null",
  "clinic_name": "string or null",
  "patient_name": "string or null",
  "date": "string or null",
  "diagnosis": "string or null",
  "medications": [
    {
      "drug_name": "string",
      "generic_name": "string or null",
      "dosage": "string",
      "frequency": "string",
      "frequency_code": "OD|BD|TDS|QID|SOS|HS|AC|PC",
      "duration_days": "number or null",
      "route": "oral|topical|inhaled|injection|drops",
      "instructions": "string or null",
      "reminder_times": ["HH:MM", ...]
    }
  ],
  "follow_up_days": "number or null",
  "special_instructions": "string or null",
  "interaction_warnings": ["string"],
  "generic_alternatives": {"brand_name": "generic_name"}
}

Frequency codes:
- OD = Once daily → reminder_times: ["08:00"]
- BD = Twice daily → reminder_times: ["08:00", "20:00"]
- TDS = Three times daily → reminder_times: ["08:00", "14:00", "20:00"]
- QID = Four times daily → reminder_times: ["07:00", "11:00", "15:00", "19:00"]
- HS = At bedtime → reminder_times: ["21:00"]
- AC = Before meals → reminder_times: ["07:30", "13:00", "19:30"]
- PC = After meals → reminder_times: ["09:00", "14:30", "21:00"]
- SOS = As needed → reminder_times: []

For common Indian brand names, always provide generic_name.
Common Indian brands: Glycomet=Metformin, Amlip=Amlodipine, Pan=Pantoprazole, Atorva=Atorvastatin.
Flag known dangerous interactions in interaction_warnings.
Return ONLY the JSON, no other text."""


INTERACTION_RULES = {
    frozenset(["warfarin", "aspirin"]): "SEVERE: Major bleeding risk. Avoid combination unless directed by cardiologist.",
    frozenset(["metformin", "alcohol"]): "MODERATE: Increased lactic acidosis risk. Avoid alcohol.",
    frozenset(["amlodipine", "simvastatin"]): "MODERATE: Amlodipine raises simvastatin levels. Maximum simvastatin 20mg/day.",
    frozenset(["ciprofloxacin", "antacid"]): "MODERATE: Antacids reduce ciprofloxacin absorption. Take 2 hours apart.",
    frozenset(["levothyroxine", "calcium"]): "MODERATE: Calcium reduces thyroid absorption. Take 4 hours apart.",
    frozenset(["ssri", "tramadol"]): "SEVERE: Serotonin syndrome risk. Avoid combination.",
    frozenset(["methotrexate", "nsaid"]): "SEVERE: NSAIDs increase methotrexate toxicity. Avoid.",
}


class PrescriptionIntelAgent(BaseAgent):
    description = "Parse prescriptions into structured medication data with interaction checks"
    category = "patient"

    async def run(
        self,
        prescription_text: str,
        patient_age: Optional[int] = None,
        patient_conditions: Optional[list] = None,
        wake_time: str = "07:00",
        breakfast_time: str = "08:00",
        dinner_time: str = "20:00",
    ) -> dict:
        """
        Parse a prescription and return structured medication data.

        Args:
            prescription_text: Raw text from OCR or manual entry
            patient_age: For dosage validation (pediatric/geriatric)
            patient_conditions: Existing conditions for interaction checks
            wake_time: Patient's wake time for reminder scheduling
            breakfast_time: Breakfast time for AC/PC reminders
            dinner_time: Dinner time for evening reminders

        Returns:
            Structured dict with medications, reminders, warnings
        """

        age_note = f"\nPatient age: {patient_age}" if patient_age else ""
        conditions_note = f"\nExisting conditions: {', '.join(patient_conditions)}" if patient_conditions else ""

        user_message = f"""Parse this prescription into structured JSON:{age_note}{conditions_note}

PRESCRIPTION TEXT:
{prescription_text}

Apply reminder times adjusted to:
- Wake: {wake_time} | Breakfast: {breakfast_time} | Dinner: {dinner_time}"""

        raw = self._call_claude(
            system_prompt=SYSTEM_PROMPT,
            user_message=user_message,
            use_rag=True,
            rag_query=prescription_text,
        )

        # Parse JSON response
        parsed = self._safe_json_parse(raw)

        # Add cross-medication interaction checks
        if parsed and "medications" in parsed:
            drug_names = [
                m.get("generic_name", m.get("drug_name", "")).lower()
                for m in parsed["medications"]
            ]
            warnings = parsed.get("interaction_warnings", [])

            for rule_pair, warning in INTERACTION_RULES.items():
                if all(drug in " ".join(drug_names) for drug in rule_pair):
                    if warning not in warnings:
                        warnings.append(warning)

            parsed["interaction_warnings"] = warnings

        return parsed or {"error": "Could not parse prescription", "raw": raw}

    @staticmethod
    def _safe_json_parse(text: str) -> Optional[dict]:
        """Extract and parse JSON from Claude response."""
        # Strip markdown code blocks if present
        text = re.sub(r"```(?:json)?\n?", "", text).strip()
        text = text.rstrip("`").strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            # Try to find JSON block within text
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group())
                except Exception:
                    pass
        return None
