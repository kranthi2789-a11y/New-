"""
agents/doctor_productivity.py — Doctor Productivity Agent (AI prescription + SOAP notes)
"""
import json, re
from agents.base import BaseAgent

SOAP_SYSTEM = """You are a clinical documentation assistant helping Indian doctors.
Generate SOAP notes and prescriptions from doctor input.

Output JSON:
{
  "soap_note": {
    "subjective": "string (chief complaint, history)",
    "objective": "string (vitals, examination findings)",
    "assessment": "string (diagnosis/impression)",
    "plan": "string (treatment plan, medications, follow-up)"
  },
  "prescription": {
    "diagnosis": "string",
    "medications": [
      {"drug": "string", "dosage": "string", "frequency": "string", "duration": "string", "instructions": "string"}
    ],
    "investigations": ["list of tests ordered"],
    "follow_up": "string",
    "referral": "string or null"
  },
  "icd10_codes": ["suggested ICD-10 codes"],
  "clinical_notes": "string",
  "patient_instructions": "string (in simple language for patient)"
}
Return ONLY JSON."""


class DoctorProductivityAgent(BaseAgent):
    description = "AI-assisted SOAP notes, prescription generation, and clinical documentation"
    category = "clinical"

    async def run(self, chief_complaint: str, history: str = "",
                  examination: str = "", diagnosis: str = "",
                  doctor_notes: str = "") -> dict:
        response = self._call_claude(
            system_prompt=SOAP_SYSTEM,
            user_message=f"Chief Complaint: {chief_complaint}\nHistory: {history}\nExamination: {examination}\nDiagnosis: {diagnosis}\nNotes: {doctor_notes}",
            use_rag=True, rag_query=f"{diagnosis} {chief_complaint} treatment India"
        )
        text = re.sub(r"```(?:json)?\n?", "", response).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except Exception:
            return {"response": response}
