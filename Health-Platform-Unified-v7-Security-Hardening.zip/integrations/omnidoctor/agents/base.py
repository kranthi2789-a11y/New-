"""
agents/base.py — Base class for all OmniDoctor agents
"""

import time
import logging
from abc import ABC, abstractmethod
from typing import Any, Optional
import anthropic

from core.config import settings
from core.rag import retrieve_medical_context

logger = logging.getLogger("omnidoctor.agent")

# Shared Anthropic client (one per process)
_client: Optional[anthropic.Anthropic] = None


def get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        _client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
    return _client


class BaseAgent(ABC):
    """
    All OmniDoctor agents inherit from this.
    Provides: Claude API access, RAG retrieval, structured output, logging.
    """

    description: str = "Base OmniDoctor agent"
    category: str = "general"
    model: str = settings.CLAUDE_MODEL
    max_tokens: int = settings.MAX_TOKENS

    def _call_claude(
        self,
        system_prompt: str,
        user_message: str,
        use_rag: bool = False,
        rag_query: Optional[str] = None,
    ) -> str:
        """
        Core Claude API call with optional RAG context injection.
        Returns text response.
        """
        client = get_client()

        # Optionally inject medical context from RAG
        if use_rag:
            query = rag_query or user_message
            context = retrieve_medical_context(query)
            system_prompt = f"{system_prompt}\n\n<medical_context>\n{context}\n</medical_context>"

        start = time.perf_counter()
        try:
            response = client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                system=system_prompt,
                messages=[{"role": "user", "content": user_message}],
            )
            text = response.content[0].text
            elapsed_ms = (time.perf_counter() - start) * 1000
            tokens = response.usage.input_tokens + response.usage.output_tokens
            logger.info(
                f"[{self.__class__.__name__}] {elapsed_ms:.0f}ms · {tokens} tokens"
            )
            return text
        except anthropic.AuthenticationError:
            logger.error("Invalid Anthropic API key")
            raise
        except anthropic.RateLimitError:
            logger.warning("Rate limited — backing off")
            raise
        except Exception as e:
            logger.error(f"Claude API error in {self.__class__.__name__}: {e}")
            raise

    @abstractmethod
    async def run(self, **kwargs) -> Any:
        """Each agent implements its own run() method."""
        pass
