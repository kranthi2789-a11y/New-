"""
agents/health_risk.py — Health Risk Analysis Agent
"""
import json, re
from typing import Optional
from agents.base import BaseAgent

SYSTEM_PROMPT = """You are a preventive health analyst for Indian patients.
Analyze patient health data and generate a risk profile.

Output ONLY valid JSON:
{
  "overall_risk_score": "number 0-100",
  "risk_category": "low|moderate|high|critical",
  "risk_factors": [{"factor": "string", "severity": "low|moderate|high", "modifiable": "boolean"}],
  "cardiovascular_risk_10yr": "percentage or null",
  "diabetes_risk": "low|moderate|high",
  "recommendations": [{"priority": "high|medium|low", "action": "string", "timeline": "string"}],
  "lifestyle_changes": ["string"],
  "screening_due": [{"test": "string", "frequency": "string", "why": "string"}],
  "predicted_conditions_risk": [{"condition": "string", "risk_level": "string"}]
}
Return ONLY JSON."""

class HealthRiskAgent(BaseAgent):
    description = "Predictive health risk scoring and preventive care recommendations"
    category = "clinical"

    async def run(self, vitals: dict = None, lab_history: list = None,
                  age: int = 40, gender: str = "male", conditions: list = None,
                  lifestyle: dict = None) -> dict:
        vitals_text = str(vitals or {})
        labs_text = str(lab_history or [])
        conditions_text = str(conditions or [])
        lifestyle_text = str(lifestyle or {})

        response = self._call_claude(
            system_prompt=SYSTEM_PROMPT,
            user_message=f"Patient: {age}yr {gender}\nVitals: {vitals_text}\nLab history: {labs_text}\nConditions: {conditions_text}\nLifestyle: {lifestyle_text}",
            use_rag=True, rag_query="health risk assessment cardiovascular diabetes"
        )
        text = re.sub(r"```(?:json)?\n?", "", response).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except Exception:
            return {"error": "Parse failed", "raw": response}
