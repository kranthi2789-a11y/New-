"""
agents/chat_companion.py — Primary patient AI chat with memory and multi-language support
"""

from typing import Optional
from agents.base import BaseAgent

SYSTEM_PROMPT = """You are OmniDoctor, India's compassionate AI health companion.

Your role:
- Help patients understand their health conditions and medications
- Triage symptoms and recommend appropriate next steps
- Support Hindi, Telugu, Tamil, Kannada, Bengali, and English
- Guide patients toward the right healthcare resources in India

Rules:
- NEVER diagnose. Say "this may suggest" not "you have"
- Always recommend consulting a doctor for serious concerns
- Mention Indian-specific resources: PMJAY, Ayushman Bharat, Jan Aushadhi pharmacies, 108 emergency
- For emergencies (chest pain, stroke, unconscious): immediately say "Call 108 now"
- Be warm, simple, and clear — many users are not medically literate
- Respond in the same language the patient writes in
- Keep responses concise for mobile screens (under 200 words unless detail is needed)

You have access to medical context to ground your answers. Use it but don't cite it verbatim.
"""


class ChatCompanionAgent(BaseAgent):
    description = "Primary patient-facing conversational AI with symptom triage and health Q&A"
    category = "patient"

    # In-memory session history (for local/demo; use Redis in production)
    _sessions: dict = {}

    async def run(
        self,
        message: str,
        session_id: str = "default",
        language: str = "english",
        patient_context: Optional[dict] = None,
    ) -> dict:
        """
        Process a patient message and return a conversational response.

        Args:
            message: Patient's input text
            session_id: Unique session identifier for memory
            language: Preferred language hint
            patient_context: Optional dict with patient age, conditions, medications

        Returns:
            dict with 'response', 'emergency_flag', 'suggested_action'
        """

        # Build patient context if available
        context_note = ""
        if patient_context:
            context_note = f"""
Patient Profile:
- Age: {patient_context.get('age', 'unknown')}
- Known conditions: {', '.join(patient_context.get('conditions', [])) or 'none'}
- Current medications: {', '.join(patient_context.get('medications', [])) or 'none'}
- Allergies: {', '.join(patient_context.get('allergies', [])) or 'none'}
"""

        # Build conversation history for context window
        history = self._sessions.get(session_id, [])
        history_text = ""
        if history:
            history_text = "\n".join([
                f"{'Patient' if h['role'] == 'user' else 'OmniDoctor'}: {h['content']}"
                for h in history[-6:]  # last 3 turns
            ])
            history_text = f"\n\nPrevious conversation:\n{history_text}\n"

        full_system = SYSTEM_PROMPT
        if context_note:
            full_system += f"\n{context_note}"

        user_message = f"{history_text}Patient: {message}"

        response = self._call_claude(
            system_prompt=full_system,
            user_message=user_message,
            use_rag=True,
            rag_query=message,
        )

        # Update session memory
        if session_id not in self._sessions:
            self._sessions[session_id] = []
        self._sessions[session_id].append({"role": "user", "content": message})
        self._sessions[session_id].append({"role": "assistant", "content": response})

        # Keep only last 20 messages
        self._sessions[session_id] = self._sessions[session_id][-20:]

        # Detect emergency keywords
        emergency_keywords = [
            "chest pain", "heart attack", "stroke", "unconscious", "not breathing",
            "heavy bleeding", "seize", "seizure", "anaphylaxis", "ambulance",
            "सीने में दर्द", "दिल का दौरा", "बेहोश"
        ]
        emergency_flag = any(kw in message.lower() for kw in emergency_keywords)

        return {
            "response": response,
            "emergency_flag": emergency_flag,
            "session_id": session_id,
            "suggested_action": "call_emergency" if emergency_flag else "continue_chat",
        }

    def clear_session(self, session_id: str):
        """Clear conversation history for a session."""
        self._sessions.pop(session_id, None)
