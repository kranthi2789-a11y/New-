"""
agents/medication_reminder.py — Build and manage medication reminder schedules
"""

import json
import re
from datetime import datetime, time
from typing import Optional
from agents.base import BaseAgent

SYSTEM_PROMPT = """You are a clinical pharmacist building medication reminder schedules for Indian patients.

Given a list of medications and patient routine, create a complete daily schedule.

Output ONLY valid JSON:
{
  "daily_schedule": [
    {
      "time": "HH:MM",
      "label": "string (e.g., Morning with breakfast)",
      "medications": [
        {
          "drug_name": "string",
          "dosage": "string",
          "instructions": "string (with food/empty stomach/etc.)",
          "critical": "boolean (true for cardiac/diabetes/BP meds)"
        }
      ]
    }
  ],
  "total_medications": "number",
  "streak_goal": "30 days",
  "whatsapp_messages": {
    "morning_reminder": "string (friendly WhatsApp message in English+Hindi)",
    "evening_reminder": "string",
    "missed_dose": "string",
    "streak_achieved": "string"
  },
  "food_timing_notes": ["list of important food/timing instructions"],
  "refill_reminder_days": "number (when to order refill based on duration)"
}

Rules:
- Group medications at same time into one reminder slot
- AC (before meals) = 30 min before food
- PC (after meals) = 15-30 min after food
- HS (bedtime) = 9-10 PM
- Separate antacids and antibiotics by 2 hours from other meds
- WhatsApp messages should be warm, in both English and Hindi (Hinglish OK)
- Mark cardiac/diabetes/BP/seizure medications as critical=true
Return ONLY JSON, no other text."""


class MedicationReminderAgent(BaseAgent):
    description = "Build intelligent medication schedules with WhatsApp reminder templates"
    category = "patient"

    async def run(
        self,
        medications: list,
        patient_name: str = "Patient",
        wake_time: str = "07:00",
        breakfast_time: str = "08:00",
        lunch_time: str = "13:00",
        dinner_time: str = "20:00",
        sleep_time: str = "22:00",
        language: str = "english",
    ) -> dict:
        """
        Generate a complete daily medication schedule with reminder messages.

        Args:
            medications: List of dicts with drug_name, dosage, frequency_code, duration_days
            patient_name: For personalized WhatsApp messages
            wake_time: HH:MM format
            breakfast_time: HH:MM
            lunch_time: HH:MM
            dinner_time: HH:MM
            sleep_time: HH:MM
            language: Preferred language for messages

        Returns:
            Complete daily schedule with WhatsApp message templates
        """

        med_list = "\n".join([
            f"- {m.get('drug_name', 'unknown')} {m.get('dosage', '')} "
            f"| Frequency: {m.get('frequency_code', 'OD')} "
            f"| Duration: {m.get('duration_days', 'ongoing')} days "
            f"| Instructions: {m.get('instructions', 'none')}"
            for m in medications
        ])

        user_message = f"""Create medication schedule for {patient_name}:

Patient Routine:
- Wake: {wake_time}
- Breakfast: {breakfast_time}
- Lunch: {lunch_time}
- Dinner: {dinner_time}
- Sleep: {sleep_time}
- Language preference: {language}

Medications:
{med_list}"""

        response = self._call_claude(
            system_prompt=SYSTEM_PROMPT,
            user_message=user_message,
        )

        parsed = self._safe_json_parse(response)

        if parsed:
            # Add metadata
            parsed["patient_name"] = patient_name
            parsed["generated_at"] = datetime.utcnow().isoformat()
            parsed["schedule_version"] = "3.0"

        return parsed or {"error": "Could not generate schedule", "raw": response}

    @staticmethod
    def _safe_json_parse(text: str) -> Optional[dict]:
        text = re.sub(r"```(?:json)?\n?", "", text).strip().rstrip("`").strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group())
                except Exception:
                    pass
        return None
