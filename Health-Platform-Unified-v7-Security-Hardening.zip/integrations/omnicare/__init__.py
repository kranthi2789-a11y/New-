"""OmniDoctor — All 20 AI Agents"""
from .chat_companion import ChatCompanionAgent
from .prescription_intelligence import PrescriptionIntelligenceAgent
from .medication_reminder import MedicationReminderAgent
from .insurance_policy import InsurancePolicyAgent
from .health_risk_analysis import HealthRiskAnalysisAgent
from .hospital_discovery import HospitalDiscoveryAgent
from .doctor_productivity import DoctorProductivityAgent
from .emergency_response import EmergencyResponseAgent
from .family_health import FamilyHealthAgent
from .cost_optimization import CostOptimizationAgent
from .lab_report_interpretation import LabReportInterpretationAgent
from .pharmacy_availability import PharmacyAvailabilityAgent
from .followup_automation import FollowUpAutomationAgent
from .chronic_disease_monitoring import ChronicDiseaseMonitoringAgent
from .preventive_health import PreventiveHealthAgent
from .medical_bill_analyzer import MedicalBillAnalyzerAgent
from .mental_health import MentalHealthAgent
from .second_opinion import SecondOpinionAgent
from .telemedicine import TelemedicineAgent
from .nutrition_diet import NutritionDietAgent

ALL_AGENTS = [
    ChatCompanionAgent, PrescriptionIntelligenceAgent, MedicationReminderAgent,
    InsurancePolicyAgent, HealthRiskAnalysisAgent, HospitalDiscoveryAgent,
    DoctorProductivityAgent, EmergencyResponseAgent, FamilyHealthAgent,
    CostOptimizationAgent, LabReportInterpretationAgent, PharmacyAvailabilityAgent,
    FollowUpAutomationAgent, ChronicDiseaseMonitoringAgent, PreventiveHealthAgent,
    MedicalBillAnalyzerAgent, MentalHealthAgent, SecondOpinionAgent,
    TelemedicineAgent, NutritionDietAgent,
]

def health_check_all():
    results = {}
    for AgentClass in ALL_AGENTS:
        try:
            agent = AgentClass()
            results[AgentClass.__name__] = agent.health_check()
        except Exception as e:
            results[AgentClass.__name__] = {"status": "error", "error": str(e)}
    return results
