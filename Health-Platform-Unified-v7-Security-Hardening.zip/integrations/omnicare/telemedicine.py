"""
OmniDoctor — Telemedicine Agent (Agent 19) ← NEW
Video consultation booking, session management, e-prescription generation.
"""
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import random, string

class TelemedicineAgent:
    """
    Manages end-to-end teleconsult flow:
    Booking → Doctor matching → Video session → E-prescription → Follow-up scheduling.
    Production: Integrates with Jitsi Meet / Zoom API / LiveKit.
    """

    SPECIALTIES = {
        "general_physician": {"avg_wait_min": 15, "fee_inr": 300, "availability": "24/7"},
        "cardiologist": {"avg_wait_min": 60, "fee_inr": 800, "availability": "9AM-8PM"},
        "dermatologist": {"avg_wait_min": 30, "fee_inr": 500, "availability": "9AM-6PM"},
        "pediatrician": {"avg_wait_min": 20, "fee_inr": 400, "availability": "8AM-10PM"},
        "gynecologist": {"avg_wait_min": 45, "fee_inr": 600, "availability": "9AM-7PM"},
        "diabetologist": {"avg_wait_min": 40, "fee_inr": 700, "availability": "10AM-6PM"},
        "psychiatrist": {"avg_wait_min": 60, "fee_inr": 900, "availability": "9AM-5PM"},
        "orthopedist": {"avg_wait_min": 50, "fee_inr": 700, "availability": "9AM-6PM"},
    }

    def __init__(self):
        self.appointments: Dict[str, Dict] = {}
        self.sessions: Dict[str, Dict] = {}

    def book_appointment(self, patient: Dict, specialty: str, preferred_datetime: str, reason: str) -> Dict:
        spec_data = self.SPECIALTIES.get(specialty.lower().replace(" ","_"), self.SPECIALTIES["general_physician"])
        appointment_id = "APPT-" + "".join(random.choices(string.digits, k=8))
        video_link = f"https://meet.omnidoctor.in/{appointment_id}"
        appointment = {
            "appointment_id": appointment_id,
            "patient_name": patient.get("name"),
            "patient_id": patient.get("id"),
            "specialty": specialty,
            "scheduled_at": preferred_datetime,
            "duration_min": 20,
            "fee_inr": spec_data["fee_inr"],
            "video_link": video_link,
            "status": "CONFIRMED",
            "reason": reason,
            "reminders_sent": False,
        }
        self.appointments[appointment_id] = appointment
        return {
            "booked": True,
            "appointment_id": appointment_id,
            "specialty": specialty,
            "scheduled_at": preferred_datetime,
            "fee": f"₹{spec_data['fee_inr']}",
            "video_link": video_link,
            "confirmation": f"Appointment confirmed. Video link: {video_link}. You will receive WhatsApp reminder 30 min before.",
        }

    def start_session(self, appointment_id: str) -> Dict:
        appt = self.appointments.get(appointment_id)
        if not appt:
            return {"error": "Appointment not found"}
        session_id = "SESS-" + appointment_id
        self.sessions[session_id] = {
            "session_id": session_id,
            "appointment_id": appointment_id,
            "started_at": datetime.utcnow().isoformat(),
            "status": "active",
            "notes": [],
            "vitals_shared": [],
        }
        appt["status"] = "IN_PROGRESS"
        return {"session_id": session_id, "status": "active", "video_link": appt["video_link"],
                "jitsi_config": {"roomName": appointment_id, "userInfo": {"displayName": appt["patient_name"]}}}

    def add_clinical_note(self, session_id: str, note: str) -> Dict:
        session = self.sessions.get(session_id, {})
        session.setdefault("notes", []).append({"note": note, "timestamp": datetime.utcnow().isoformat()})
        return {"note_added": True, "total_notes": len(session["notes"])}

    def generate_eprescription(self, session_id: str, prescription_data: Dict) -> Dict:
        session = self.sessions.get(session_id, {})
        appt = self.appointments.get(session.get("appointment_id",""), {})
        rx_id = "RX-" + "".join(random.choices(string.digits, k=10))
        rx = {
            "rx_id": rx_id,
            "patient_name": appt.get("patient_name"),
            "appointment_id": appt.get("appointment_id"),
            "date": datetime.utcnow().strftime("%d %B %Y"),
            "diagnosis": prescription_data.get("diagnosis"),
            "medications": prescription_data.get("medications", []),
            "instructions": prescription_data.get("instructions", ""),
            "follow_up_date": prescription_data.get("follow_up_date"),
            "doctor_signature": "Dr. [Name] | Reg No: [MCI Number]",
            "digital_signature": f"OmniDoctor-eSigned-{rx_id}",
            "download_link": f"https://omnidoctor.in/rx/{rx_id}.pdf",
            "valid_for_days": 30,
        }
        return {"e_prescription": rx, "rx_id": rx_id, "download_link": rx["download_link"],
                "whatsapp_sent": True, "pharmacy_share_link": f"https://omnidoctor.in/pharmacy/{rx_id}"}

    def end_session(self, session_id: str) -> Dict:
        session = self.sessions.get(session_id, {})
        session["status"] = "completed"
        session["ended_at"] = datetime.utcnow().isoformat()
        duration = 20  # mock
        return {"session_id": session_id, "status": "completed", "duration_min": duration,
                "notes_count": len(session.get("notes",[])), "follow_up_scheduled": True}

    def get_available_slots(self, specialty: str, date: str) -> List[Dict]:
        spec_data = self.SPECIALTIES.get(specialty.lower().replace(" ","_"), self.SPECIALTIES["general_physician"])
        slots = []
        for hour in [9, 10, 11, 14, 15, 16, 17]:
            slots.append({"time": f"{date} {hour:02d}:00", "available": random.random() > 0.3,
                          "fee": f"₹{spec_data['fee_inr']}", "wait_estimate": f"{spec_data['avg_wait_min']} min"})
        return [s for s in slots if s["available"]]

    def health_check(self) -> Dict:
        return {"agent": "TelemedicineAgent", "status": "healthy", "specialties": list(self.SPECIALTIES.keys()),
                "video_backend": "Jitsi Meet / LiveKit", "active_sessions": len([s for s in self.sessions.values() if s.get("status")=="active"])}
