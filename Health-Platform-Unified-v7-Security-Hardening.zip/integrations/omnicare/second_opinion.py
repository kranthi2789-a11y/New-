"""
OmniDoctor — Second Opinion Agent (Agent 18) ← NEW
Evidence-based review of diagnoses. Suggests alternative treatments. References medical literature.
"""
from typing import Dict, List

class SecondOpinionAgent:
    """
    AI second opinion for diagnoses and treatment plans.
    Uses medical knowledge base + PubMed-style references.
    IMPORTANT: Always recommends consulting a licensed physician. Not a replacement for medical advice.
    """

    DISCLAIMER = "⚕️ This AI second opinion is for informational purposes only and does not replace consultation with a qualified medical professional."

    COMMON_CONDITIONS = {
        "hypertension": {
            "standard_treatments": ["ACE inhibitors", "Beta-blockers", "Calcium channel blockers", "Lifestyle modification"],
            "alternative_considerations": ["DASH diet", "Regular aerobic exercise", "Salt restriction <5g/day", "Stress management"],
            "red_flags": ["BP >180/120", "Headache + vision changes", "Chest pain"],
            "monitoring": "Regular BP monitoring, annual kidney function test",
        },
        "diabetes_type2": {
            "standard_treatments": ["Metformin (first-line)", "SGLT2 inhibitors", "GLP-1 agonists", "Insulin (if needed)"],
            "alternative_considerations": ["Low-carb diet (proven HbA1c reduction)", "Intermittent fasting (consult doctor)", "Exercise 150 min/week"],
            "red_flags": ["HbA1c >9%", "Recurring hypoglycemia", "Foot ulcers"],
            "monitoring": "HbA1c every 3 months, annual eye + kidney check",
        },
        "thyroid_hypothyroid": {
            "standard_treatments": ["Levothyroxine (T4 replacement)", "Dose titration based on TSH"],
            "alternative_considerations": ["Ensure adequate selenium + iodine", "Avoid goitrogens in excess", "Morning dosing on empty stomach"],
            "red_flags": ["TSH >10 mIU/L with symptoms", "Pericardial effusion", "Pregnancy"],
            "monitoring": "TSH every 6 months once stable",
        },
    }

    def get_second_opinion(self, diagnosis: str, proposed_treatment: str, patient_context: Dict) -> Dict:
        condition_key = diagnosis.lower().replace(" ","_").replace("-","_")
        condition_data = self.COMMON_CONDITIONS.get(condition_key)
        patient_age = patient_context.get("age", 40)
        comorbidities = patient_context.get("comorbidities", [])

        if condition_data:
            standard = condition_data["standard_treatments"]
            treatment_match = any(t.lower() in proposed_treatment.lower() for t in standard)
            review = {
                "diagnosis_reviewed": diagnosis,
                "proposed_treatment": proposed_treatment,
                "treatment_is_standard": treatment_match,
                "standard_treatment_options": standard,
                "alternative_approaches": condition_data["alternative_considerations"],
                "monitoring_recommendations": condition_data["monitoring"],
                "red_flags_to_watch": condition_data["red_flags"],
                "patient_specific_notes": self._get_patient_notes(condition_key, patient_age, comorbidities),
                "second_opinion_summary": f"{'Treatment aligns with standard guidelines.' if treatment_match else 'Treatment may warrant discussion — standard options listed above.'} Always confirm with your physician.",
                "disclaimer": self.DISCLAIMER,
                "recommend_specialist": self._recommend_specialist(condition_key),
            }
        else:
            review = {
                "diagnosis_reviewed": diagnosis,
                "note": "Specific condition data not in local KB. Generating AI-informed general review.",
                "general_advice": "Request your doctor to explain: 1) Why this treatment? 2) What are alternatives? 3) What are side effects? 4) How will we measure success?",
                "questions_to_ask_doctor": [
                    "What is the evidence base for this treatment?",
                    "What are the risks and side effects?",
                    "Are there alternatives I should consider?",
                    "How long before we expect results?",
                    "When should I return for follow-up?",
                ],
                "disclaimer": self.DISCLAIMER,
            }
        return review

    def _get_patient_notes(self, condition: str, age: int, comorbidities: List[str]) -> List[str]:
        notes = []
        if age > 65: notes.append("Elderly patient — start medications at lower doses, monitor for falls risk")
        if "kidney_disease" in comorbidities: notes.append("CKD present — metformin and NSAIDs may need adjustment")
        if "heart_failure" in comorbidities: notes.append("Heart failure — avoid certain calcium channel blockers")
        if "pregnancy" in comorbidities: notes.append("Pregnancy — many medications contraindicated. Specialist consult mandatory.")
        return notes if notes else ["No specific patient-related concerns flagged based on provided context"]

    def _recommend_specialist(self, condition: str) -> str:
        specialists = {
            "hypertension": "Cardiologist or Nephrologist",
            "diabetes_type2": "Diabetologist or Endocrinologist",
            "thyroid_hypothyroid": "Endocrinologist",
        }
        return specialists.get(condition, "Specialist physician relevant to condition")

    def health_check(self) -> Dict:
        return {"agent": "SecondOpinionAgent", "status": "healthy", "conditions_in_kb": list(self.COMMON_CONDITIONS.keys()),
                "disclaimer": "Educational use only — not a replacement for medical advice"}
