"""
OmniDoctor — Mental Health Agent (Agent 17) ← NEW
PHQ-9 depression screening, GAD-7 anxiety screening, crisis detection, therapy resources.
"""
from typing import Dict, List

class MentalHealthAgent:
    """
    India's AI mental health companion.
    Screens for depression (PHQ-9) and anxiety (GAD-7).
    Provides crisis intervention and connects to iCall, Vandrevala, NIMHANS.
    """

    # PHQ-9 Depression Screening Questions
    PHQ9_QUESTIONS = [
        "Little interest or pleasure in doing things?",
        "Feeling down, depressed, or hopeless?",
        "Trouble falling or staying asleep, or sleeping too much?",
        "Feeling tired or having little energy?",
        "Poor appetite or overeating?",
        "Feeling bad about yourself — or that you are a failure?",
        "Trouble concentrating on things, such as reading or watching TV?",
        "Moving or speaking so slowly that others noticed? Or fidgety/restless?",
        "Thoughts that you would be better off dead or of hurting yourself?",
    ]

    # GAD-7 Anxiety Screening Questions
    GAD7_QUESTIONS = [
        "Feeling nervous, anxious, or on edge?",
        "Not being able to stop or control worrying?",
        "Worrying too much about different things?",
        "Trouble relaxing?",
        "Being so restless that it is hard to sit still?",
        "Becoming easily annoyed or irritable?",
        "Feeling afraid, as if something awful might happen?",
    ]

    RESPONSE_SCALE = {0: "Not at all", 1: "Several days", 2: "More than half the days", 3: "Nearly every day"}

    CRISIS_KEYWORDS = ["suicide", "kill myself", "end my life", "want to die", "no reason to live", "hurt myself", "self-harm"]

    INDIA_RESOURCES = {
        "iCall (TISS)": "9152987821",
        "Vandrevala Foundation": "1860-2662-345",
        "NIMHANS Helpline": "080-46110007",
        "Snehi": "044-24640050",
        "iCall Chat": "icallhelpline.org",
    }

    def screen_phq9(self, scores: List[int]) -> Dict:
        """scores: list of 9 integers, each 0-3"""
        if len(scores) != 9:
            return {"error": "PHQ-9 requires exactly 9 responses"}
        total = sum(scores)
        if total <= 4: severity = "Minimal depression"; action = "Monitor. Lifestyle support."
        elif total <= 9: severity = "Mild depression"; action = "Watchful waiting, counseling suggested."
        elif total <= 14: severity = "Moderate depression"; action = "Treatment plan — therapy + lifestyle change."
        elif total <= 19: severity = "Moderately severe depression"; action = "Active treatment — therapy + medication review."
        else: severity = "Severe depression"; action = "Immediate referral to psychiatrist."
        crisis = scores[8] >= 1
        return {
            "screening": "PHQ-9",
            "total_score": total,
            "severity": severity,
            "action_required": action,
            "crisis_risk": crisis,
            "crisis_resources": self.INDIA_RESOURCES if crisis else None,
            "recommendation": "Consult psychiatrist immediately" if total >= 15 else "Consult counselor",
        }

    def screen_gad7(self, scores: List[int]) -> Dict:
        """scores: list of 7 integers, each 0-3"""
        if len(scores) != 7:
            return {"error": "GAD-7 requires exactly 7 responses"}
        total = sum(scores)
        if total <= 4: severity = "Minimal anxiety"
        elif total <= 9: severity = "Mild anxiety"
        elif total <= 14: severity = "Moderate anxiety"
        else: severity = "Severe anxiety"
        return {
            "screening": "GAD-7",
            "total_score": total,
            "severity": severity,
            "recommendation": "Therapy recommended" if total >= 10 else "Self-care and monitoring",
            "resources": self.INDIA_RESOURCES if total >= 15 else None,
        }

    def detect_crisis(self, message: str) -> Dict:
        msg_lower = message.lower()
        is_crisis = any(kw in msg_lower for kw in self.CRISIS_KEYWORDS)
        if is_crisis:
            return {
                "crisis_detected": True,
                "immediate_response": "You matter. Please reach out right now — someone is ready to help you.",
                "emergency_resources": self.INDIA_RESOURCES,
                "action": "IMMEDIATE_INTERVENTION",
                "do_not": "Do not leave the user alone. Do not minimize feelings.",
            }
        return {"crisis_detected": False, "action": "SUPPORTIVE_CONVERSATION"}

    def get_support_response(self, mood: str, context: str = "") -> Dict:
        prompts = {
            "anxious": "You're feeling anxious. Let's try a 4-7-8 breathing exercise together. Inhale for 4 counts, hold 7, exhale 8. You're safe right now.",
            "depressed": "I hear you — things feel heavy right now, and that's okay. You're not alone. Small steps matter. What's one tiny thing you can do today that brought you comfort before?",
            "stressed": "Stress is your body signaling that something matters to you. Let's break this down together — what feels most overwhelming right now?",
            "lonely": "Feeling disconnected is painful. You reached out today, and that takes courage. Let's think about one small connection you could make this week.",
            "grief": "Grief has no timeline and no rules. Whatever you're feeling is valid. Would you like to talk about what you're going through?",
        }
        return {"mood": mood, "response": prompts.get(mood, "I'm here for you. Tell me more about how you're feeling."),
                "resources": self.INDIA_RESOURCES, "professional_help": "Consider speaking to a mental health professional — it's a sign of strength, not weakness."}

    def health_check(self) -> Dict:
        return {"agent": "MentalHealthAgent", "status": "healthy", "screenings": ["PHQ-9", "GAD-7"],
                "crisis_resources": list(self.INDIA_RESOURCES.keys()), "version": "1.0"}
