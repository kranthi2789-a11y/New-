"""
OmniDoctor — Nutrition & Diet Agent (Agent 20) ← NEW
Indian diet plans, diabetic/cardiac nutrition, BMI tracking, calorie calculator.
"""
from typing import Dict, List

class NutritionDietAgent:
    """
    Personalized Indian diet plans based on health conditions.
    Supports: Diabetic, Cardiac, Weight loss, PCOS, Thyroid, General wellness diets.
    Uses Indian food database with regional meal preferences.
    """

    BMI_CATEGORIES = {(0,18.4): "Underweight", (18.5,24.9): "Normal", (25,29.9): "Overweight", (30,34.9): "Obese Class I", (35,100): "Obese Class II+"}

    CALORIE_ACTIVITY = {"sedentary": 1.2, "lightly_active": 1.375, "moderately_active": 1.55, "very_active": 1.725}

    INDIAN_MEAL_PLANS = {
        "diabetic": {
            "breakfast": ["Oats upma with vegetables (250 cal)", "Moong dal chilla with mint chutney (200 cal)", "Ragi idli with sambar (220 cal)"],
            "lunch": ["Brown rice + dal + sabzi + salad (400 cal)", "Jowar roti + chana dal + cucumber raita (380 cal)"],
            "dinner": ["Vegetable khichdi (350 cal)", "Bajra roti + palak paneer + salad (380 cal)"],
            "snacks": ["Handful of almonds (100 cal)", "Buttermilk (60 cal)", "Roasted chana (120 cal)"],
            "avoid": ["White rice in large qty", "Maida products", "Sugary drinks", "Fried snacks", "Fruit juices"],
            "prefer": ["Low GI foods: oats, bajra, ragi", "High fiber vegetables", "Small frequent meals", "Protein at every meal"],
        },
        "cardiac": {
            "breakfast": ["Oats porridge with nuts (280 cal)", "Whole wheat toast + boiled egg white (220 cal)"],
            "lunch": ["Brown rice + fish curry + salad (420 cal)", "Multigrain roti + dal + sabzi (390 cal)"],
            "dinner": ["Grilled fish/chicken + vegetables (350 cal)", "Dal soup + multigrain roti (330 cal)"],
            "snacks": ["Walnuts (5-6 pieces)", "Fruits (apple, guava)", "Green tea"],
            "avoid": ["Saturated fats", "Trans fats (vanaspati)", "High sodium pickles/papads", "Red meat in excess"],
            "prefer": ["Omega-3 rich foods: fish, walnuts, flaxseeds", "Olive oil / mustard oil", "Fruits and vegetables", "Low sodium"],
        },
        "weight_loss": {
            "breakfast": ["Moong dal chilla (180 cal)", "Poha with vegetables (220 cal)", "Greek yogurt with fruits (200 cal)"],
            "lunch": ["Dal + 2 roti + salad (380 cal)", "Grilled chicken + rice + salad (400 cal)"],
            "dinner": ["Soup + 1 roti + sabzi (300 cal)", "Vegetable stir-fry with paneer (280 cal)"],
            "snacks": ["Cucumber + hummus (80 cal)", "Roasted makhana (100 cal)", "Coconut water (45 cal)"],
            "avoid": ["Fried foods", "Sugary beverages", "Refined carbs", "Late night eating"],
            "prefer": ["High protein meals", "High fiber foods", "Drink 3L water daily", "Eat slowly"],
        },
    }

    def calculate_bmi(self, weight_kg: float, height_cm: float) -> Dict:
        height_m = height_cm / 100
        bmi = round(weight_kg / (height_m ** 2), 1)
        category = next((cat for (lo,hi), cat in self.BMI_CATEGORIES.items() if lo <= bmi <= hi), "Unknown")
        ideal_weight_lo = round(18.5 * height_m ** 2, 1)
        ideal_weight_hi = round(24.9 * height_m ** 2, 1)
        return {
            "bmi": bmi, "category": category,
            "ideal_weight_range_kg": f"{ideal_weight_lo} – {ideal_weight_hi} kg",
            "weight_to_lose_kg": round(max(0, weight_kg - ideal_weight_hi), 1) if bmi > 24.9 else 0,
            "assessment": "Healthy weight! Maintain current lifestyle." if 18.5 <= bmi <= 24.9 else f"BMI {bmi} — {category}. Diet + exercise plan recommended.",
        }

    def calculate_daily_calories(self, weight_kg: float, height_cm: float, age: int, gender: str, activity: str) -> Dict:
        if gender.lower() == "male":
            bmr = 88.362 + (13.397 * weight_kg) + (4.799 * height_cm) - (5.677 * age)
        else:
            bmr = 447.593 + (9.247 * weight_kg) + (3.098 * height_cm) - (4.330 * age)
        tdee = bmr * self.CALORIE_ACTIVITY.get(activity, 1.375)
        return {
            "bmr": round(bmr), "tdee": round(tdee),
            "weight_loss_target": round(tdee - 500),
            "weight_gain_target": round(tdee + 300),
            "maintenance": round(tdee),
            "macro_split": {"protein_g": round(weight_kg * 1.6), "carbs_g": round(tdee * 0.45 / 4), "fat_g": round(tdee * 0.25 / 9)},
        }

    def get_meal_plan(self, condition: str, veg_preference: str = "veg", region: str = "south_indian") -> Dict:
        plan = self.INDIAN_MEAL_PLANS.get(condition.lower().replace(" ","_"), self.INDIAN_MEAL_PLANS["weight_loss"])
        return {
            "condition": condition,
            "region": region,
            "meal_plan": plan,
            "weekly_tip": f"Week 1 focus: Follow the meal plan strictly. Track every meal. Aim for 8 hours sleep.",
            "hydration": "Drink 2.5-3L water daily. No sugary drinks.",
            "exercise_suggestion": "30 min brisk walk daily. Yoga 3x/week.",
        }

    def analyze_food_intake(self, food_items: List[Dict]) -> Dict:
        """food_items: [{name, calories, protein_g, carbs_g, fat_g}]"""
        total_cal = sum(f.get("calories",0) for f in food_items)
        total_protein = sum(f.get("protein_g",0) for f in food_items)
        total_carbs = sum(f.get("carbs_g",0) for f in food_items)
        total_fat = sum(f.get("fat_g",0) for f in food_items)
        return {
            "total_calories": total_cal,
            "total_protein_g": round(total_protein,1),
            "total_carbs_g": round(total_carbs,1),
            "total_fat_g": round(total_fat,1),
            "assessment": "Within range" if 1500 <= total_cal <= 2000 else "Review calorie intake",
            "items_logged": len(food_items),
        }

    def health_check(self) -> Dict:
        return {"agent": "NutritionDietAgent", "status": "healthy",
                "diet_plans_available": list(self.INDIAN_MEAL_PLANS.keys()),
                "features": ["BMI calculator","Calorie calculator","Meal plans","Food intake analysis"]}
