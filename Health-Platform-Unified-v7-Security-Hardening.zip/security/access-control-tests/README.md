# Access-control test matrix

Every sensitive endpoint must be tested for:
1. unauthenticated access → 401
2. wrong role → 403
3. correct role → allowed
4. patient A reading patient B → 403
5. disabled user → denied
6. expired token → 401
7. malformed token → 401
8. privilege escalation through request body → denied

The executable baseline is in `tests/test_platform.py`.
