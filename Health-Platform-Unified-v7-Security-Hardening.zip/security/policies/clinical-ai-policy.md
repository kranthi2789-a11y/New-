# Clinical AI policy baseline

1. AI is an advisory component, not an authority.
2. Every patient-facing clinical result must retain patient context and evidence references where applicable.
3. High-risk/emergency outputs must expose uncertainty and human-review requirements.
4. Autonomous prescribing, diagnosis, or clinical-record mutation is disabled in the canonical MVP.
5. Deterministic safety rails may override a model suggestion.
6. Agent runs are auditable by actor, patient context, input hash, output and timestamp.
7. Production deployment requires a validated clinical evaluation set and governance approval.
