# Production security boundaries

## Required before real PHI
- Replace development JWT accounts and secrets.
- Enable OIDC/enterprise SSO and MFA.
- Enforce organization/tenant membership for every PHI resource.
- Move object storage to encrypted managed storage with private buckets and signed URLs.
- Move the transactional database to managed PostgreSQL and enable encrypted transport/backups.
- Add service-to-service authentication for workers and integrations.
- Add immutable/append-only audit export.
- Add rate limiting/WAF controls at the edge.
- Run dependency, container, SAST, DAST and penetration testing.
- Validate FHIR mappings against the target EHR/FHIR server.
- Establish clinical safety evaluation and human approval for AI outputs.
