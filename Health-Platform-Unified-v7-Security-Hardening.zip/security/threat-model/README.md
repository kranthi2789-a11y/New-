# Threat model boundary

Primary threats: broken object-level authorization, cross-hospital data access, stolen tokens, malicious document upload, prompt injection from clinical documents, unsafe tool execution, model hallucination, emergency endpoint abuse, audit tampering, secrets leakage and supply-chain vulnerabilities.

Required controls are tracked in `docs/security/PRODUCTION_CHECKLIST.md`.
