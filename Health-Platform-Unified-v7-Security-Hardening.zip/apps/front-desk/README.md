# front-desk

Role workspace: `receptionist`. The shared portal provides the authenticated shell and server-enforced permissions.
