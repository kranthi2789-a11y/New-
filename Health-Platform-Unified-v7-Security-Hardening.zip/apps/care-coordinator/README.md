# care-coordinator

Role workspace: `care_coordinator`. The shared portal provides the authenticated shell and server-enforced permissions.
