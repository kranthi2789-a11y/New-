# inventory-portal

Role workspace: `inventory`. The shared portal provides the authenticated shell and server-enforced permissions.
