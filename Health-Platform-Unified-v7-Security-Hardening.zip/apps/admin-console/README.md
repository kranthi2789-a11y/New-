# admin-console

Role workspace: `admin`. The shared portal provides the authenticated shell and server-enforced permissions.
