# finance-console

Role workspace: `finance`. The shared portal provides the authenticated shell and server-enforced permissions.
