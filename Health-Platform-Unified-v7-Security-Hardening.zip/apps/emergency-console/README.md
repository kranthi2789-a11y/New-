# emergency-console

Role workspace: `emergency_responder`. The shared portal provides the authenticated shell and server-enforced permissions.
