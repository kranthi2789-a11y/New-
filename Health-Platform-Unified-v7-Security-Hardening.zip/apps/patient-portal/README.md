# patient-portal

Role workspace: `patient`. The shared portal provides the authenticated shell and server-enforced permissions.
