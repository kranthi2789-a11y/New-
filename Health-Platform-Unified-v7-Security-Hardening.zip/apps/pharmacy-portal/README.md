# pharmacy-portal

Role workspace: `pharmacist`. The shared portal provides the authenticated shell and server-enforced permissions.
