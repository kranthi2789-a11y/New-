# medical-college

Role workspace: `dean`. The shared portal provides the authenticated shell and server-enforced permissions.
