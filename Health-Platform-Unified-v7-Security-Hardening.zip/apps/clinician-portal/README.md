# clinician-portal

Role workspace: `doctor`. The shared portal provides the authenticated shell and server-enforced permissions.
