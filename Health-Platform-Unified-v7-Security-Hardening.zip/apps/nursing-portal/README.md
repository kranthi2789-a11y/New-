# nursing-portal

Role workspace: `nurse`. The shared portal provides the authenticated shell and server-enforced permissions.
