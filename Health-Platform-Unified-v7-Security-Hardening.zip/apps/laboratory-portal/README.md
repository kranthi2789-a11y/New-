# laboratory-portal

Role workspace: `lab_technician`. The shared portal provides the authenticated shell and server-enforced permissions.
