# Source provenance

This build incorporates source code supplied by the user in uploaded packages. No external GitHub code was copied into the canonical runtime during this build.

Sources reviewed/integrated:
- VitalOS v2, v3, v4 and production packages
- OmniDoctor Agents v3
- OmniDoctor Complete / Complete Package / Site
- OmniCare Continuum v4
- NexOra OmniDoctor v3
- INMED CORE legacy claims assets
- Campus360 Nexora package (reviewed; not copied into clinical runtime because it is an education-domain product)

The canonical runtime is newly assembled under `services/api_gateway`, with source implementations preserved under `integrations/`. Review ownership/licensing of any source before external distribution.
